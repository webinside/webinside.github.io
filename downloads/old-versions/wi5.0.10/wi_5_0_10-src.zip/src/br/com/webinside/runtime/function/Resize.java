/*
 * WEBINSIDE - Ferramenta de produtividade Java
 * Copyright (c) 2011-2012 LINEWEB Solu��es Tecnol�gicas Ltda.
 * Copyright (c) 2009-2010 Inc�gnita Intelig�ncia Digital Ltda.
 *
 * Este programa � software livre; voc� pode redistribu�-lo e/ou modific�-lo 
 * sob os termos da GNU LESSER GENERAL PUBLIC LICENSE (LGPL) conforme publicada 
 * pela Free Software Foundation; vers�o 2.1 da Licen�a.
 * Este programa � distribu�do na expectativa de que seja �til, por�m, SEM 
 * NENHUMA GARANTIA; nem mesmo a garantia impl�cita de COMERCIABILIDADE OU 
 * ADEQUA��O A UMA FINALIDADE ESPEC�FICA.
 * 
 * Consulte a GNU LGPL para mais detalhes.
 * Voc� deve ter recebido uma c�pia da GNU LGPL junto com este programa; se n�o, 
 * veja em http://www.gnu.org/licenses/ 
 */

package br.com.webinside.runtime.function;

import java.awt.Image;
import java.awt.Panel;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Locale;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.plugins.jpeg.JPEGImageWriteParam;
import javax.imageio.stream.ImageOutputStream;

import br.com.webinside.runtime.core.ExecuteParams;
import br.com.webinside.runtime.integration.InterfaceConnector;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.net.FileUpload;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.StringA;
import br.com.webinside.runtime.util.WIMap;

public class Resize implements InterfaceConnector, InterfaceParameters {

	/**
     * Construtor padr�o.
     */
    public Resize() {
    }

    /**
     * M�todo chamado pelo WI.
     *
     * @param wiParams par�metros do WI.
     */
    public void execute(ExecuteParams wiParams) {
        WIMap wiMap = wiParams.getWIMap();
        String source = wiMap.get("tmp.sourcefile");
        String dest = wiMap.get("tmp.destfile");
        if (dest.trim().equals("")) {
        	dest = source;
        }
        if (!dest.endsWith(".jpg")) {
        	dest = StringA.changeChars(dest, ".", "_");
        	dest = dest + ".jpg";
        }
        String width = wiMap.get("tmp.width");
        String height = wiMap.get("tmp.height");
        String temp = wiMap.get("tmp.tempfile");
    	int w = Function.parseInt(width);
    	int h = Function.parseInt(height);
    	if (!source.trim().equals("") && (w > 0 || h >0)) {
	        try {
	            File out = new File(dest);
	    		out.delete();
	    		out.getParentFile().mkdirs();
	            BufferedImage bi = ImageIO.read(new File(source));
            	float aw = bi.getWidth();
            	float ah = bi.getHeight();
	            if (w == 0) w = (int)((aw/ah) * h);
	            if (h == 0) h = (int)((ah/aw) * w);
	            Image img = bi.getScaledInstance(w, h, Image.SCALE_SMOOTH);
	            BufferedImage bi2 = 
	            	new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
	            bi2.createGraphics().drawImage(img, 0, 0, new Panel());	            
	    		// write image
	            Iterator it = ImageIO.getImageWritersByFormatName("jpg");
	            ImageWriter writer = (ImageWriter)it.next();
	            ImageOutputStream ios = ImageIO.createImageOutputStream(out);
	            writer.setOutput(ios);
	            ImageWriteParam iwparam = 
	            	new JPEGImageWriteParam(Locale.getDefault());
	            iwparam.setCompressionMode(ImageWriteParam.MODE_EXPLICIT) ;
	            iwparam.setCompressionQuality(0.9f);
	            writer.write(null, new IIOImage(bi2, null, null), iwparam);	   
	            writer.dispose();
	            ios.close();
   	        } catch (IOException e) { }
    	}    
        if (temp.trim().equalsIgnoreCase("true")) {        	
    		FileUpload fu = wiParams.getFileUpload();
    		if (fu == null) {
    			fu = new FileUpload();
        		wiParams.setParameter(ExecuteParams.FILE_UPLOAD, fu);
    		}
    		fu.addExtraFile("resize", new File(dest));
        }
    }

    public boolean exit() {
        return false;
    }
    
    public JavaParameter[] getInputParameters() {
        JavaParameter[] params = new JavaParameter[5];
        params[0] = new JavaParameter("tmp.sourcefile", "Arquivo Origem", "");
        params[1] = new JavaParameter("tmp.destfile", "Arquivo Destino", "");
        params[2] = new JavaParameter("tmp.width", "Largura", "");
        params[3] = new JavaParameter("tmp.height", "Altura", "");
        params[4] = new JavaParameter("tmp.tempfile", "Tempor�rio", "");
        return params;
    }

    public JavaParameter[] getOutputParameters() {
        JavaParameter[] outParam = new JavaParameter[0];
        return outParam;
    }
    
}
