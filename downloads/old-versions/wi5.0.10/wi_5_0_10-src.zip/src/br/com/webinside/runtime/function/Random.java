/*
 * WEBINSIDE - Ferramenta de produtividade Java
 * Copyright (c) 2011-2012 LINEWEB Solu��es Tecnol�gicas Ltda.
 * Copyright (c) 2009-2010 Inc�gnita Intelig�ncia Digital Ltda.
 *
 * Este programa � software livre; voc� pode redistribu�-lo e/ou modific�-lo 
 * sob os termos da GNU LESSER GENERAL PUBLIC LICENSE (LGPL) conforme publicada 
 * pela Free Software Foundation; vers�o 2.1 da Licen�a.
 * Este programa � distribu�do na expectativa de que seja �til, por�m, SEM 
 * NENHUMA GARANTIA; nem mesmo a garantia impl�cita de COMERCIABILIDADE OU 
 * ADEQUA��O A UMA FINALIDADE ESPEC�FICA.
 * 
 * Consulte a GNU LGPL para mais detalhes.
 * Voc� deve ter recebido uma c�pia da GNU LGPL junto com este programa; se n�o, 
 * veja em http://www.gnu.org/licenses/ 
 */

package br.com.webinside.runtime.function;

import br.com.webinside.runtime.integration.*;

// Random(int length, boolean onlyNumbers)
public class Random extends AbstractFunction {
    private static java.util.Random random;

    /**
     * Creates a new Random object.
     */
    public Random() {
    }

    /**
     * DOCUMENT ME!
     *
     * @param args DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String execute(String[] args) {
        int max = 5;
        boolean onlynumber = true;
        if (args.length >= 1) {
            try {
                max = Integer.parseInt(args[0]);
            } catch (NumberFormatException err) {
            }
        }
        if (args.length >= 2) {
            String p2 = args[1].trim().toLowerCase();
            if (p2.equals("false")) {
                onlynumber = false;
            }
        }
        return rnd(max, onlynumber);
    }

    // Alfa - 65 to 90 = 25 options
    private String rnd(int length, boolean onlynumber) {
        if (random == null) {
            random = new java.util.Random();
        }
        String snum = "";
        for (int i = 1; i <= length; i++) {
            if (onlynumber) {
                int num = (int) (random.nextDouble() * 10);
                snum = snum + num;
            } else {
                int num = (int) (random.nextDouble() * 35);
                if (num < 10) {
                    snum = snum + num;
                } else {
                    snum = snum + (char) (num + 55);
                }
            }
        }
        return snum;
    }
}
