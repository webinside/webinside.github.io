/*
 * WEBINSIDE - Ferramenta de produtividade Java
 * Copyright (c) 2011-2012 LINEWEB Solu��es Tecnol�gicas Ltda.
 * Copyright (c) 2009-2010 Inc�gnita Intelig�ncia Digital Ltda.
 *
 * Este programa � software livre; voc� pode redistribu�-lo e/ou modific�-lo 
 * sob os termos da GNU LESSER GENERAL PUBLIC LICENSE (LGPL) conforme publicada 
 * pela Free Software Foundation; vers�o 2.1 da Licen�a.
 * Este programa � distribu�do na expectativa de que seja �til, por�m, SEM 
 * NENHUMA GARANTIA; nem mesmo a garantia impl�cita de COMERCIABILIDADE OU 
 * ADEQUA��O A UMA FINALIDADE ESPEC�FICA.
 * 
 * Consulte a GNU LGPL para mais detalhes.
 * Voc� deve ter recebido uma c�pia da GNU LGPL junto com este programa; se n�o, 
 * veja em http://www.gnu.org/licenses/ 
 */

package br.com.webinside.runtime.database;

import java.io.OutputStream;
import java.sql.ResultSetMetaData;
import java.util.Map;

/**
 * DOCUMENT ME!
 *
 * @author $author$
 * @version $Revision: 1.1 $
 */
public interface ResultSet {
    /** DOCUMENT ME! */
    public static final String binaryFilter =
        "binary,blob,image,text,longchar,longvarchar,bytea";

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int rowCount();

    /**
     * DOCUMENT ME!
     *
     * @param row DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int go(int row);

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int next();

    /**
     * DOCUMENT ME!
     *
     * @param field DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String column(String field);

    /**
     * DOCUMENT ME!
     *
     * @param field DOCUMENT ME!
     * @param binFilter DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String column(String field, boolean binFilter);

    /**
     * DOCUMENT ME!
     *
     * @param field DOCUMENT ME!
     * @param binFilter DOCUMENT ME!
     * @param showNull DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String column(String field, boolean binFilter, boolean showNull);

    /**
     * DOCUMENT ME!
     *
     * @param index DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String column(int index);

    /**
     * DOCUMENT ME!
     *
     * @param index DOCUMENT ME!
     * @param binFilter DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String column(int index, boolean binFilter);

    /**
     * DOCUMENT ME!
     *
     * @param index DOCUMENT ME!
     * @param binFilter DOCUMENT ME!
     * @param showNull DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String column(int index, boolean binFilter, boolean showNull);

    /**
     * DOCUMENT ME!
     *
     * @param field DOCUMENT ME!
     * @param restrict DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String column(String field, String restrict);

    /**
     * DOCUMENT ME!
     *
     * @param index DOCUMENT ME!
     * @param restrict DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String column(int index, String restrict);

    /**
     * DOCUMENT ME!
     *
     * @param out DOCUMENT ME!
     * @param field DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int columnBin(OutputStream out, String field);

    /**
     * DOCUMENT ME!
     *
     * @param out DOCUMENT ME!
     * @param index DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int columnBin(OutputStream out, int index);

    /**
     * DOCUMENT ME!
     *
     * @param index DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String columnName(int index);

    /**
     * DOCUMENT ME!
     *
     * @param index DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String columnType(int index);

    /**
     * DOCUMENT ME!
     *
     * @param index DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String columnTableName(int index);

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public ResultSetMetaData getMetaData();

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String[] columnNames();

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String[] columnTypes();

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String[] columnTableNames();

    /**
     * DOCUMENT ME!
     *
     * @param field DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int columnIndex(String field);

    /**
     * DOCUMENT ME!
     *
     * @param restrict DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public Map columns(String restrict);

    /**
     * DOCUMENT ME!
     */
    public void clear();

}
