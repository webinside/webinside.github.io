/*
 * WEBINSIDE - Ferramenta de produtividade Java
 * Copyright (c) 2011-2012 LINEWEB Solu��es Tecnol�gicas Ltda.
 * Copyright (c) 2009-2010 Inc�gnita Intelig�ncia Digital Ltda.
 *
 * Este programa � software livre; voc� pode redistribu�-lo e/ou modific�-lo 
 * sob os termos da GNU LESSER GENERAL PUBLIC LICENSE (LGPL) conforme publicada 
 * pela Free Software Foundation; vers�o 2.1 da Licen�a.
 * Este programa � distribu�do na expectativa de que seja �til, por�m, SEM 
 * NENHUMA GARANTIA; nem mesmo a garantia impl�cita de COMERCIABILIDADE OU 
 * ADEQUA��O A UMA FINALIDADE ESPEC�FICA.
 * 
 * Consulte a GNU LGPL para mais detalhes.
 * Voc� deve ter recebido uma c�pia da GNU LGPL junto com este programa; se n�o, 
 * veja em http://www.gnu.org/licenses/ 
 */

package br.com.webinside.runtime.core;

import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import br.com.webinside.runtime.component.AbstractProject;
import br.com.webinside.runtime.database.*;
import br.com.webinside.runtime.integration.*;
import br.com.webinside.runtime.util.*;

/**
 * DOCUMENT ME!
 *
 * @author $author$
 * @version $Revision: 1.2 $
 */
public class ExecuteLogin {
    private ExecuteParams wiParams;
    /** DOCUMENT ME! */
    AbstractProject project;

    /**
     * Creates a new ExecuteLogin object.
     *
     * @param wiParams DOCUMENT ME!
     */
    public ExecuteLogin(ExecuteParams wiParams) {
        this.wiParams = wiParams;
        this.project = wiParams.getProject();
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public boolean execute(boolean doLogin) {
        WIMap wiMap = wiParams.getWIMap();
        wiMap.put("wi.login.accept", doLogin + "");
        String keyMD5 = wiMap.get("wi.pwd.md5");
        if (project.getLoginMD5().equals("ON")) {
        	wiMap.remove("wi.pwd.md5");
        }
        // pagina de login sempre � valida 
        String loginPage = StringA.piece(project.getLoginPage(), ".wsp", 1);
        if (wiParams.getPage().getId().equals(loginPage)) {
            return true;
        }
        if (wiParams.isJspInclude()) {
        	return true;
        }
        String addr = wiParams.getHttpRequest().getRemoteAddr();
        checkSingleSignOn(wiMap, addr);
        String logip = wiMap.get("pvt.wilogin");
        if (logip.equals(addr)) {
            return true;
        }
        if (!doLogin) {
        	if (!wiParams.getPage().getNoLogin().equals("ON")) {
                invalidLogin();
                return false;
        	} else {
        		return true;
        	}
        }
        // tenta efetuar o login
        if (project.getLoginType().equals("DBUSER")) {
            return loginDBUser();
        }

        // Abaixo segue o login convencional
        String pjsql = StringA.changeChars(project.getLoginSql(), "\r\n", "  ");
        if (pjsql.trim().equals("")) {
            invalidLogin();
            return false;
        }
        String dbalias = project.getLoginDatabase();
        DatabaseHandler db = wiParams.getDatabaseAliases().get(dbalias);
        if ((db == null) || (!db.isConnected())) {
            EngFunction.databaseError(wiParams, dbalias);
            return false;
        }
        db.setCharFilter(project.getLoginSqlFilter(), "");
        ResultSet rs = null;
        try {
            rs = db.execute(project.getLoginSql(), wiMap, 1, 1);
        } catch (Exception err) {
        	// pode ser desconsiderado
        }
        if (rs != null) {
            boolean ok = false;
            int pos = rs.next();
            if (pos == 1) {
            	int validPos = 1;
                if (project.getLoginMD5().equals("ON")) {
                    String dbpass = rs.column(validPos);
                    String encoded = Crypto.encodeMD5(dbpass + keyMD5);
                    if (encoded.equals(wiMap.get("tmp.pass"))) {
                        ok = true;
                    }
                } else {
                	validPos = 0;
                    ok = true;
                }
                if (ok) {
                    addr = wiParams.getHttpRequest().getRemoteAddr();
                    wiMap.put("pvt.wilogin", addr);
                    wiMap.remove("pvt.login.accept");
                    // populando colunas adicionais
                    String[] names = rs.columnNames();
                    for (int i=validPos; i< names.length; i++) {
                    	String name = names[i];
                    	wiMap.put("pvt.login." + name, rs.column(i+1));
                    }
                	loginRoles(wiMap);
                }
            }
            if (!ok) {
                invalidLogin();
                return false;
            }
        } else {
            wiMap.put("wi.sql.query", db.getExecutedSQL());
            String sqlmsg = db.getErrorMessage();
            wiMap.put("wi.sql.error", sqlmsg.toString());
            wiMap.put("wi.sql.msg", StringA.piece(sqlmsg, ")", 2, 0).trim());
            invalidLogin();
            return false;
        }
        return true;
    }

    private boolean loginDBUser() {
        String dbalias = project.getLoginDatabase();
        ProducerParam prod = new ProducerParam();
        prod.setWIMap(wiParams.getWIMap());
        DatabaseHandler db = wiParams.getDatabaseAliases().get(dbalias);
        if (db == null) {
            EngFunction.databaseError(wiParams, dbalias);
            return false;
        }
        if (!db.isConnected()) {
            invalidLogin();
            return false;
        }
        WIMap wiMap = wiParams.getWIMap();
        wiMap.put("pvt.wilogin", wiParams.getHttpRequest().getRemoteAddr());
        wiMap.remove("pvt.login.accept");
        loginRoles(wiMap);
        return true;
    }

    private void invalidLogin() {
        ProducerParam prod = new ProducerParam();
        prod.setWIMap(wiParams.getWIMap());
        prod.setInput(project.getLoginMessage());
        wiParams.getProducer().setParam(prod);
        wiParams.getProducer().execute();
        String resp = prod.getOutput();
        if (!wiParams.getWIMap().get("wi.login.accept").equals("true")) {
        	resp = "Login Expirado";
        }
        if (!resp.equals("")) {
        	wiParams.getWIMap().put("tmp.msglogin", resp);
        }	
        String loginPage = project.getLoginPage();
        if (!loginPage.trim().equals("")) {
            prod.setInput(loginPage);
            wiParams.getProducer().setParam(prod);
            wiParams.getProducer().execute();
            wiParams.sendRedirect(prod.getOutput(), wiParams.getWIMap(), true);
        } else {
            new Export(wiParams).showMessage(i18n("Login Inv�lido"));
        }
    }

    private String i18n(String text) {
        return new I18N().get(text);
    }
    
    private void checkSingleSignOn(WIMap wiMap, String addr) {
        String ssoId = EngFunction.getSingleSignOnId(wiParams); 
        if (!ssoId.equals("")) {
        	String ssoVar = wiMap.get("pvt.wilogin.singlesignon");
        	Map map = SingleSignOnRepository.getToken(ssoId + "-" + addr);
        	if (map != null) {
        		wiMap.put("pvt.wilogin", addr);
        		wiMap.put("pvt.wilogin.singlesignon", "true");
        		wiMap.putAll(map);
            	loginRoles(wiMap);
        	} else if (ssoVar.equalsIgnoreCase("true")) {
        		removeLogin(wiMap);
        	}	
        }
    }
    
    protected static void removeLogin(WIMap wiMap) {
    	wiMap.remove("pvt.wilogin");
		wiMap.remove("pvt.wilogin.singlesignon");
		wiMap.remove("pvt.login.");
    }
    
    private void loginRoles(WIMap wiMap) {
    	if (project.getLoginRolesSql().equals("")) return;
        String dbalias = project.getLoginRolesDatabase();
        DatabaseHandler db = wiParams.getDatabaseAliases().get(dbalias);
        if ((db == null) || (!db.isConnected())) {
            EngFunction.databaseError(wiParams, dbalias);
            return;
        }
        db.setCharFilter(project.getLoginRolesSqlFilter(), "");
        ResultSet rs = null;
        try {
            rs = db.execute(project.getLoginRolesSql(), wiMap);
        } catch (Exception err) {
        	// pode ser desconsiderado
        }
        if (rs != null) {
        	Set<String> roles = new LinkedHashSet();
            if (rs.next() > 0) {
            	roles.add(rs.column(1));
            }
            int i = 1;
            for (String role : roles) {
				wiMap.put("pvt.login.role[" + i + "].name", role);
			}
        } else {
            wiMap.put("wi.sql.query", db.getExecutedSQL());
            String sqlmsg = db.getErrorMessage();
            wiMap.put("wi.sql.error", sqlmsg.toString());
            wiMap.put("wi.sql.msg", StringA.piece(sqlmsg, ")", 2, 0).trim());
        }
    }
    
}
