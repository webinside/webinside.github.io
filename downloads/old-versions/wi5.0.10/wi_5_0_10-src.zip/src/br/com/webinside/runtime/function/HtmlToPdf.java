package br.com.webinside.runtime.function;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.w3c.dom.Document;
import org.w3c.tidy.Tidy;
import org.xhtmlrenderer.pdf.ITextRenderer;

import br.com.webinside.runtime.core.EngFunction;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.WIMap;

import com.lowagie.text.pdf.BaseFont;

public class HtmlToPdf extends AbstractConnector implements InterfaceParameters {
	
	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases,
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		try {
			HttpServletResponse response = getParams().getHttpResponse();
	        response.setContentType("application/octetstream");
	        String name = wiMap.get("tmp.pdf_name").trim();
	        if (name.equals("")) name = "report";
	        String dispname = "attachment; filename=\"" + name + ".pdf\"";
	        response.setHeader("Content-disposition", dispname);
		    ITextRenderer renderer = getRenderer(wiMap);
	        String url = getURL(wiMap, wiMap.get("tmp.pdf_page"));
			renderer.setDocument(getDocument(url), url);
			renderer.layout();
			renderer.createPDF(getOutputStream());
		} catch (Exception err) {
			err.printStackTrace();
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
	
	private Document getDocument(String url) throws Exception {
		Tidy tidy = new Tidy();
		tidy.setQuiet(true);
//		tidy.setShowWarnings(false);
		tidy.setBreakBeforeBR(true);
		HttpClient httpclient = new HttpClient();
		GetMethod httpget = new GetMethod(url);
	    int status = httpclient.executeMethod(httpget);
		if (status != HttpStatus.SC_OK) {
			throw new HttpException("Erro ao ler url " + url);
		}
		InputStream in = httpget.getResponseBodyAsStream();
		String charset = httpget.getResponseCharSet();
	    Reader reader = new InputStreamReader(in, charset); 
		Document document = tidy.parseDOM(reader, null);
	    httpget.releaseConnection();
		return document;
	}

	private String getURL(WIMap wiMap, String page) {
		if (page.startsWith("http")) return page;
        int port = EngFunction.getServerPort(getParams().getHttpRequest());
        String prot = (port == 443) ? "https://" : "http://";
        String url = prot + "localhost:" + port + "/";
		if (!page.startsWith("/")) page = "/" + page;
		if (!page.endsWith(".wsp")) page += ".wsp";
		return url + wiMap.get("wi.proj.id") + page; 
	}

	private ITextRenderer getRenderer(WIMap wiMap) throws Exception {
		ITextRenderer renderer = new ITextRenderer();
		String path = wiMap.get("wi.proj.path");
		File[] fonts = new File(path, "WEB-INF/fonts").listFiles();
		for (int i = 0; i < fonts.length; i++) {
			if (fonts[i].getName().endsWith(".ttf")) {
				String font = fonts[i].getAbsolutePath();
				renderer.getFontResolver().addFont(font, BaseFont.EMBEDDED);
			}
		}
		return renderer;
	}
	
    @Override
	public boolean exit() {
    	return true;
	}

	public JavaParameter[] getInputParameters() {
        JavaParameter[] params = new JavaParameter[2];
        params[0] = new JavaParameter("tmp.pdf_page", "Pagina WSP");
        params[1] = new JavaParameter("tmp.pdf_name", "Nome ao salvar");
        return params;
    }

    public JavaParameter[] getOutputParameters() {
        JavaParameter[] outParam = new JavaParameter[1];
        outParam[0] = new JavaParameter("tmp.pdf_xhtml", "Conte�do XHTML"); 
        return outParam;
    }
	   
}
