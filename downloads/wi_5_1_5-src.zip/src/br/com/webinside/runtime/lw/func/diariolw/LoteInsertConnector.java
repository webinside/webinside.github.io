package br.com.webinside.runtime.lw.func.diariolw;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;

import org.apache.commons.fileupload.FileItem;

import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.net.FileUpload;
import br.com.webinside.runtime.util.ErrorLog;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class LoteInsertConnector extends AbstractConnector {
	
	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers)
			throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";     
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
	    	String priv = wiMap.get("pvt.lwpath.priv");
			String key = Function.randomKey(10, false);
	    	File loteDir = new File(priv, "/diario/lote/" + key);
	    	loteDir.mkdirs();
	    	wiMap.put("tmp.obj.id_cont_lote", key);
	        FileUpload fileUpload = getParams().getFileUpload();
	        List<FileItem> itens = fileUpload.getMultFileField("tmp.doc");
	        for (FileItem item : itens) {
	        	Map<String,String> fnameMap = fileUpload.getItemNameMap(item);
	        	int seq = itens.indexOf(item) + 1;
		    	wiMap.put("tmp.id_cont_seq", seq);
	        	String fname = seq + "." + fnameMap.get("ext");
	        	FileOutputStream fout = new FileOutputStream(new File(loteDir, fname));
	        	Function.copyStream(item.getInputStream(), fout);
	        	fout.close();
		    	wiMap.put("tmp.ts_arquivo", fnameMap.get("name").replace("_", " ").trim());
		    	wiMap.put("tmp.ts_extensao", fnameMap.get("ext"));
		    	String insert = "insert into tb_cont_lote values (?|tmp.obj.id_cont_lote|, "
		    			+ "?|tmp.id_cont_seq|, now(), ?|tmp.ts_arquivo|, ?|tmp.ts_extensao|)";
		    	dh.executeUpdate(insert, wiMap);
			}        
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			ErrorLog errorLog = getParams().getErrorLog();
			if (errorLog != null) {
				errorLog.write(className, "Page: " + pageId, err);
			}
		}
	}
	
}
