package br.com.webinside.runtime.lw.func.diario;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Base64;
import java.util.List;

import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.lw.img.ImgEnum;
import br.com.webinside.runtime.lw.img.ImgUtil;
import br.com.webinside.runtime.util.CmdUtil;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class CapaDoc extends AbstractConnector implements InterfaceParameters {
		
	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "principal";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			String capaFolder = wiMap.get("pvt.lwpath.priv") + "/diario/capa";
			String doc = "capa-" + wiMap.get("tmp.diario.tipo_capa");
			CmdUtil.execute(capaFolder, CmdUtil.cmdConvertFile(doc + ".doc","pdf"));
			List<String> cmd = ImgUtil.cmdPdfToImg("", ImgEnum.PNG_GRAY, 250, "", null);
			ImgUtil.execute(cmd, capaFolder, doc, doc, false);
			File first = new File(capaFolder, doc + "-0.png");
			if (first.isFile()) first.renameTo(new File(capaFolder, doc + ".png"));
			FileInputStream in = new FileInputStream(new File(capaFolder, doc + ".png"));
            FileOutputStream out = new FileOutputStream(new File(capaFolder, doc + ".b64"));
            Function.copyStream(in, Base64.getEncoder().wrap(out));
            in.close();
            out.close();
			in = new FileInputStream(new File(capaFolder, doc + ".b64"));
			String col = "tx_diario_capa_reg";
			if (wiMap.get("tmp.diario.tipo_capa").equals("E")) {
				col = "tx_diario_capa_ext";
			}
			String update = "update tb_adm_parametro set " + col + " = ?" +
					" where id_parametro = ?|pvt.id_empresa|";
			dh.executeUpdate(in, update, wiMap);
			in.close();
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
	
	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[1];
		in[0] = new JavaParameter("tmp.diario.tipo_capa", "Tipo Capa");
		return in;
	}

	public JavaParameter[] getOutputParameters() {
		return new JavaParameter[0];
	}
	
}
