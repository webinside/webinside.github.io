package br.com.webinside.runtime.lw.juris;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base32;

import com.itextpdf.text.pdf.BarcodeQRCode;

import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.CryptoAES;
import br.com.webinside.runtime.util.WIMap;
import de.taimos.totp.TOTP;
import de.taimos.totp.TOTPData;

public class GoogleAuth extends AbstractConnector implements InterfaceParameters {
		
	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) throws UserException {
		try {
			CryptoAES aes = new CryptoAES(getClass().getSimpleName(), 128);
			String op = wiMap.get("tmp.googleauth.op");
			if (op.equals("check") && !wiMap.get("tmp.user").equals("")) {
				String token = wiMap.get("tmp.ga_token");
				String secret = aes.decode(wiMap.get("tmp.ts_secret"));
				boolean local = wiMap.get("wi.server.host").equals("localhost") && token.equals("lw1234");
				if (!token.equals(getCode(secret)) && !local) {
					wiMap.put("tmp.captcha_error","true");
					wiMap.put("tmp.msglogin","Google Token Inv�lido");
				}
			} else if (op.equals("image")) {
				String newSecret = genSecret();
				DatabaseHandler dh = databases.get("principal");
				wiMap.put("tmp.secret", aes.encode(newSecret));
				String update = "update tb_usuario set ts_secret = ?|tmp.secret| where id_usuario = ?|tmp.sid_usuario|";
				dh.executeUpdate(update, wiMap);
				// Gerando URL
				String email = wiMap.get("tmp.obj.ts_email");
				String mask = "otpauth://totp/%s?secret=%s&issuer=%s";
			    String otpauth = String.format(mask, email, newSecret, "LegalManager");
			    // Enviando imagem
			    HttpServletResponse response = getParams().getHttpResponse();
				response.setContentType("image/png");
			    response.setHeader("Content-disposition", "inline; filename='qrcode.png'");			    
			    BarcodeQRCode qrCode = new BarcodeQRCode(otpauth, 200, 200, null);
			    Image image = qrCode.createAwtImage(Color.BLACK, Color.WHITE);
			    BufferedImage bi = new BufferedImage(200, 200, BufferedImage.TYPE_3BYTE_BGR);
			    Graphics g = bi.getGraphics(); 
		        g.drawImage(image, 0, 0, null);
			    ImageIO.write(bi, "png", getOutputStream());
			}
		} catch (Exception e) {
			throw new UserException(e);
		}
	}	
	 
	public String genSecret() throws Exception {
		return TOTPData.create().getSecretAsBase32();
	}

	public String getCode(String secret) throws Exception {
		if (secret == null) return null;
		Base32 base32 = new Base32(); 
	    byte[] bytes = base32.decode(secret); 
	    String hexKey = new TOTPData(bytes).getSecretAsHex(); 
	    return TOTP.getOTP(hexKey); 
	}
		
	@Override
	public boolean exit() {
		String op = getParams().getWIMap().get("tmp.googleauth.op");
		if (op.equals("image")) return true;
		return false;
	}

	@Override
	public JavaParameter[] getInputParameters() {
		JavaParameter[] param = new JavaParameter[1]; 
		param[0] = new JavaParameter("tmp.googleauth.op","Opera��o (check/image)");
		return param;
	}

	@Override
	public JavaParameter[] getOutputParameters() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
