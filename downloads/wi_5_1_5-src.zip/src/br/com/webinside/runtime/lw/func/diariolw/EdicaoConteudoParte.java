package br.com.webinside.runtime.lw.func.diariolw;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.Splitter;

import br.com.webinside.runtime.core.RtmExport;
import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class EdicaoConteudoParte extends AbstractConnector {

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) 
	throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		File pdfTemp = null;
		try {
			String database = "diariolw";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			String query = "SELECT nr_edicao, tp_edicao, nr_edi_ini, nr_edi_fin"
					+ " FROM tb_conteudo c"
					+ " INNER JOIN tb_edicao e ON (e.id_edicao = c.fk_edicao)"
					+ " WHERE e.st_finalizada = 1 AND c.st_removido = 0 and nr_edi_ini > 0"
					+ " AND ts_cont_key = ?|tmp.key|";
			ResultSet rs = dh.execute(query, wiMap);
			if (rs.next() > 0) {
		    	String priv = wiMap.get("pvt.lwpath.priv");
				String nrEdicao = rs.column("nr_edicao");
				String tpEdicao = rs.column("tp_edicao");
		    	File pdfFile = new File(priv, "/diario/concluido/" + nrEdicao + tpEdicao + ".pdf");
		    	if (!pdfFile.isFile()) return;
		    	pdfTemp = new File(Function.rndTmpFile("recorte", "pdf"));
		    	Function.copyFile(pdfFile.getAbsolutePath(), pdfTemp.getAbsolutePath());
		    	int nrIni = Function.parseInt(rs.column("nr_edi_ini"));
		    	int nrFin = Function.parseInt(rs.column("nr_edi_fin"));
				PDDocument doc = PDDocument.load(pdfTemp);
				Splitter splitter = new Splitter();
				splitter.setStartPage(nrIni);
				splitter.setEndPage(nrFin);
				splitter.setSplitAtPage(nrFin);
				List<PDDocument> list = splitter.split(doc);
				PDDocument part = list.get(0);
				File pdfPart = new File(pdfTemp.getAbsolutePath().replace(".pdf", "_part.pdf"));
				part.save(pdfPart);
				part.close();
				doc.close();
				pdfTemp.delete();
				pdfTemp = pdfPart;
				// Enviando Recorte
				HttpServletResponse response = getParams().getHttpResponse();
				response.setContentType("application/pdf");
				response.setHeader("Content-disposition", "inline; filename=\"conteudo_na_edicao.pdf\"");
				response.setContentLength((int) pdfTemp.length());
				try {
					response.flushBuffer();
				} catch (IOException err) {}  
				new RtmExport(getParams()).sendFile(wiMap, pdfTemp.getAbsolutePath(), false);
			}
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		} finally {
			if (pdfTemp != null) pdfTemp.delete();
		}
	}
	
	@Override
	public boolean exit() {
		return true;
	}

}
