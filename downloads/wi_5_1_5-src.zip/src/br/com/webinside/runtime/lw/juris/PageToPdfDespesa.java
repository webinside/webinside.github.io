package br.com.webinside.runtime.lw.juris;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfCopy;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfReader;

import br.com.webinside.runtime.component.AbstractProject;
import br.com.webinside.runtime.component.GridSql;
import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class PageToPdfDespesa extends PageToPdf {

	@Override
	public void afterPdfGenerated(WIMap wiMap, DatabaseAliases databases, File tmpPdf) {
		try {
			if (!wiMap.get("tmp.incluir_doc").equals("1")) return;
			AbstractProject prj = getParams().getProject();
	        if (!prj.getGrids().containsKey("rel_fin_despesa")) {
	            getParams().includeCode("/grids/rel_fin_despesa/grid.jsp");
	        }
			GridSql grid = (GridSql) prj.getGrids().getElement("rel_fin_despesa");
			DatabaseHandler dh = databases.get("principal");
			ResultSet rs = dh.execute(grid.getSql(), wiMap);
			int pos = 0;
			while ((pos = rs.next()) > 0) {
				String id = rs.column("id_despesa");
				String storage = wiMap.get("wi.proj.path") + "/WEB-INF/storage";
				if (rs.column("st_desp_doc").equals("1")) {
					File file = new File(storage,"/fin_boleto/d" + id + ".pdf");
					appendToPdf(tmpPdf, file, "Seq. " + pos + " - Documento para pagamento");
				}
				float pagto = Function.parseFloat(rs.column("vl_pagto"));
				if (pagto > 0) {
					File file = new File(storage,"/fin_pagto/d" + id + ".pdf");
					appendToPdf(tmpPdf, file, "Seq. " + pos + " - Comprovante de pagamento");
				}
				String comp = rs.column("tp_comp_doc");
				if (comp.equals("N") || comp.equals("R")) {
					File file = new File(storage,"/fin_recibo/d" + id + ".pdf");
					String txt = comp.equals("N") ? "Nota Fiscal" : "Recibo";
					appendToPdf(tmpPdf, file, "Seq. " + pos + " - " + txt);
				}
			}
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write("PageToPdfDespesa", "Page: " + pageId, err);
		}
	}

	private void appendToPdf(File tmpPdf, File docPdf, String title) throws Exception {
		File auxPdf = new File(tmpPdf.getAbsolutePath().replace(".pdf", "_aux.pdf"));
		PdfReader pdfReader = new PdfReader(tmpPdf.getAbsolutePath());
		Document document = new Document();
		OutputStream outFile = new FileOutputStream(auxPdf);
		PdfCopy copy = new PdfCopy(document, outFile);
		copy.setStrictImageSequence(true);
		document.open();
        copy.addDocument(pdfReader);
		try {
			FileInputStream in = new FileInputStream(docPdf);
			PdfReader reader = new PdfReader(in);
			PdfReader.unethicalreading = true;
			for (int i = 1; i <= reader.getNumberOfPages(); i++) {
				try {
					PdfImportedPage page = copy.getImportedPage(reader, i);
					PdfCopy.PageStamp ps = copy.createPageStamp(page);
					PdfContentByte over = ps.getOverContent();
					over.beginText();
					over.setFontAndSize(BaseFont.createFont(), 12);
					over.setTextMatrix(10, page.getHeight() - 24);
					over.showText(title);
					over.endText();
					ps.alterContents();
//					ps.addAnnotation(PdfAnnotation.createText(copy, new Rectangle(50, 180, 70, 200), "Hello", "No Thanks", true, "Comment"));
					copy.addPage(page);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			copy.freeReader(reader);
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
        document.close();
        copy.close();
        pdfReader.close();
        tmpPdf.delete();
        auxPdf.renameTo(tmpPdf);
	}

}
