package br.com.webinside.runtime.lw.juris;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import org.apache.commons.fileupload.FileItem;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfCopy;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfWriter;

import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.function.database.AbstractConnectorDB;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.net.FileUpload;
import br.com.webinside.runtime.util.WIMap;

public class UploadJoinPdfs extends AbstractConnectorDB implements InterfaceParameters {

	private WIMap wiMap = null;

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) 
	throws UserException {
		this.wiMap = wiMap;
		String className = getClass().getName();
		try {
			execute(databases.get("principal"));
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
	
	private void execute(DatabaseHandler dh) throws Exception {
		String folder = wiMap.get("tmp.upd_folder");
		String file = wiMap.get("tmp.upd_file");
		String var = wiMap.get("tmp.upd_var");
		if (var.equals("")) var = "tmp.mult_arq";
        File destfile = new File(folder, file);
        destfile.getParentFile().mkdirs();
        OutputStream outFile = new FileOutputStream(destfile);
        Document document = new Document();
        PdfCopy copy = new PdfCopy(document, outFile);        
        document.open();
        int pages = 0;
        FileUpload fileUpload = getParams().getFileUpload();
        List<FileItem> itens = fileUpload.getMultFileField(var);
        for (FileItem item : itens) {
        	Map<String,String> fnameMap = fileUpload.getItemNameMap(item);
            String ext = fnameMap.get("ext");
            if (ext.toLowerCase().trim().equals("pdf")) {
                try {
					PdfReader reader = new PdfReader(item.getInputStream());
					PdfReader.unethicalreading = true;
					for (int i = 1; i <= reader.getNumberOfPages(); i++) {
						try {
					    	copy.addPage(copy.getImportedPage(reader, i));
					    	pages++;
						} catch (Exception e) { }	
					}
					copy.freeReader(reader);
					reader.close();
				} catch (IOException e) {
					new Exception("PDF corrompido ignorado", e).printStackTrace();
				}                
            }
		}        
        if (pages == 0) {
        	ByteArrayOutputStream baos = new ByteArrayOutputStream();
        	Document docAux = new Document();
            PdfWriter.getInstance(docAux, baos);
        	docAux.open();
        	docAux.add(new Paragraph("O arquivo enviado n�o tinha nenhuma p�gina ou estava corrompido."));
        	docAux.close();
            PdfReader reader = new PdfReader(baos.toByteArray());
        	copy.addDocument(reader);
            copy.freeReader(reader);
            reader.close();         
        }
        document.close();
        outFile.close();
	}	
		
	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[3];
		in[0] = new JavaParameter("tmp.upd_folder", "Diret�rio");
		in[1] = new JavaParameter("tmp.upd_file", "Arquivo");
		in[2] = new JavaParameter("tmp.upd_var", "Vari�vel");
		return in;
	}

	public JavaParameter[] getOutputParameters() {
		return new JavaParameter[0];
	}

}
