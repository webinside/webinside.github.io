package br.com.webinside.runtime.lw.juris;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletResponse;

import org.docx4j.XmlUtils;
import org.docx4j.jaxb.Context;
import org.docx4j.model.datastorage.migration.VariablePrepare;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.WordprocessingML.MainDocumentPart;
import org.docx4j.wml.Br;
import org.docx4j.wml.ContentAccessor;
import org.docx4j.wml.ObjectFactory;
import org.docx4j.wml.P;
import org.docx4j.wml.R;
import org.docx4j.wml.Tc;
import org.docx4j.wml.Text;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.CmdUtil;
import br.com.webinside.runtime.util.CurrencyWriter;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.StringA;
import br.com.webinside.runtime.util.WIMap;

public class Docx4jProducer extends AbstractConnector implements InterfaceParameters {

	public static boolean DEBUG = false;
	
	private Map<String, String> map = new HashMap<String, String>();
	private Properties docxProps = null;
	private WIMap wiMap = null;
	
	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) 
	throws UserException {
		this.wiMap = wiMap;
		String className = getClass().getName();
		try {
			populate();
			execute();
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}

	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[3];
		in[0] = new JavaParameter("tmp.id_mod_docx", "ID do Mod Docx");
		in[1] = new JavaParameter("tmp.id_contrato", "ID do contrato");
		in[2] = new JavaParameter("tmp.id_adv_substab", "ID do advogado no substabelecimento");
		return in;
	}

	public JavaParameter[] getOutputParameters() {
		return new JavaParameter[0];
	}
	
	private void execute() throws Exception {
		String idMod = wiMap.get("tmp.id_mod_docx");
		String path = wiMap.get("wi.proj.path");
		File file = new File(path + "/WEB-INF/storage/mod_docx/m" + idMod + ".docx");
		
		WordprocessingMLPackage wordMLPackage = WordprocessingMLPackage.load(file);
		MainDocumentPart docPart = wordMLPackage.getMainDocumentPart();
		if (DEBUG) {
			writeXml(docPart, new File(file.getAbsolutePath().replace(".docx", ".xml")));
		}	
				
		VariablePrepare.prepare(wordMLPackage);
		docPart.pipe(new Docx4jStAXHandler(map));
		boolean usarConj = map.get("cnt_st_usar_conj").equals("1") && map.get("socio_qtd").equals("0");
		paragrafo(docPart, "cliente_pf", map.get("cli_tp_cliente").equals("F"));
		paragrafo(docPart, "cliente_pj", map.get("cli_tp_cliente").equals("J"));
		paragrafo(docPart, "conjuge", usarConj);
		paragrafo(docPart, "adic_perc", !map.get("cnt_vl_perc_adic").equals("0.00"));
		paragrafo(docPart, "minimo", map.get("cnt_st_omit_min").equals("0"));
		boolean hasParcela = !map.get("cnt_qt_parcelas").equals("0");
		paragrafo(docPart, "parcela", hasParcela);
		boolean hasHonorarios = !map.get("cnt_tx_honorarios").trim().equals("");
		if (hasHonorarios) textHonorarios(docPart);
		paragrafo(docPart, "obs_hono", hasHonorarios);
		anexo(docPart, "anexo", hasParcela || hasHonorarios);
		celula(docPart, "conjuge_cell", usarConj);
		celula(docPart, "adv_resp_cell", !map.get("adv2_id_advogado").equals(map.get("adv1_id_advogado")));
		celula(docPart, "adv3_cell", !map.get("adv3_id_advogado").equals(map.get("adv2_id_advogado")));

		String type = "pdf";
		if (wiMap.get("tmp.type").equals("docx")) type = "docx";
		String filename = wiMap.get("tmp.contrato.titulo");
		filename = StringA.getUsAscii(filename).toUpperCase().replace(" ", "_");
		filename = StringA.changeChars(filename, ".,", "");
		filename = filename.replace("_-_", "-");

		HttpServletResponse response = getParams().getHttpResponse();
		if (type.equals("docx")) {
			response.setContentType("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
			response.setHeader("Content-Disposition", "attachment; filename=" + filename + ".docx");
			wordMLPackage.save(response.getOutputStream());		
		} else {
			File tmpDocx = new File(Function.rndTmpFile("c", "docx"));
			if (DEBUG) tmpDocx = new File("/temp/docx4j_debug.docx");
			wordMLPackage.save(tmpDocx);		
			CmdUtil.execute(tmpDocx.getParent(), CmdUtil.cmdConvertFile(tmpDocx.getName(),"pdf"));
			if (!DEBUG) tmpDocx.delete();
			File tmpPdf = new File(tmpDocx.getAbsolutePath().replace(".docx", ".pdf"));
			response.setContentType("application/pdf");
			response.setHeader("Content-Disposition", "attachment; filename=" + filename + ".pdf");
			response.setContentLength((int) tmpPdf.length());
			Function.sendFile(tmpPdf, response.getOutputStream());
			if (!DEBUG) tmpPdf.delete();
		}
	}
	
	private void paragrafo(MainDocumentPart docPart, String key, boolean cond) 
	throws Exception {
		List<Object> rList = findR(docPart, "[" + key + "]");
		for (int i = 0; i < rList.size(); i++) {
			R r = (R) rList.get(i);
			if (!cond) {
				docPart.getContent().remove((P)r.getParent());
			} else {
				((P)r.getParent()).getContent().remove(r);	
			}
		}
	}

	private void textHonorarios(MainDocumentPart docPart) throws Exception {
		ObjectFactory factory = Context.getWmlObjectFactory();
		List<Object> rList = findR(docPart, "[tx_honorarios]");
		if (rList.size() > 0) {
			R r = (R) rList.get(0);
			P p = (P)r.getParent();
			ContentAccessor ca = (ContentAccessor) p.getParent();
			int pos = ca.getContent().indexOf(p);
			ca.getContent().remove(pos);
			ca.getContent().remove(pos); // remover o paragrafo vazio posterior
			P p2 = factory.createP();
			ca.getContent().add(pos, p2);
			String[] fulltext = map.get("cnt_tx_honorarios").trim().replace("\r", "").split("\n");
			for (int i = 0; i < fulltext.length; i++) {
				String parag = fulltext[i];
				R r2 = factory.createR();
				Text t = factory.createText();				
				t.setSpace("preserve");
				t.setValue(parag);
				r2.getContent().add(t);
				r2.setRPr(r.getRPr());
				p2.getContent().add(r2);
				if (i < fulltext.length - 1) {
					R r3 = factory.createR();
					Br br = factory.createBr();
					r3.getContent().add(br);
					p2.getContent().add(r3);
				}	
			}
		}
	}
	
	private void anexo(MainDocumentPart docPart, String key, boolean cond) 
	throws Exception {
		List<Object> rList = findR(docPart, "[" + key + "]");
		if (rList.size() > 0) {
			R r = (R) rList.get(0);
			if (!cond) {
				boolean remove = false;
				List<Object> pList = new ArrayList<Object>(docPart.getContent());
				for (Object o : pList) {
					if (o == r.getParent() || remove) {
						docPart.getContent().remove(o);
						remove = true;
					}
				}
			} else {
				((P)r.getParent()).getContent().remove(r);	
			}
		}
	}
	
	private void celula(MainDocumentPart docPart, String key, boolean cond) 
	throws Exception {
		List<Object> rList = findR(docPart, "[" + key + "]");
		for (int i = 0; i < rList.size(); i++) {
			R r = (R) rList.get(i);
			Tc tc = (Tc)((P)r.getParent()).getParent();
			if (!cond) {
				int pos = 0;
				for (Object o : new ArrayList(tc.getContent())) {
					if (o instanceof P) {
						pos++;
						if (pos>1) {
							tc.getContent().remove(o);
						} else {
							((P)o).getContent().remove(r);
						}
					}
				}
			} else {
				tc.getContent().remove(r.getParent());	
			}
		}
	}
	
	private List<Object> findR(MainDocumentPart docPart, String key) throws Exception {
		String xpath = "//w:r[w:t[contains(text(),'" + key + "')]]";
		List<Object> list = docPart.getJAXBNodesViaXPath(xpath, false);
		if (list == null) list = new ArrayList<Object>();
		return list;
	}
	
	private void populate() throws Exception {
		// recupera o cliente
		String query = "select vw.tp_cliente, ts_nome, ts_doc, ts_est_civil, "
				+ "cli.*, n1.ts_nacio, n2.ts_nacio as ts_conj_nacio "
				+ "from tb_contrato con "
				+ "inner join vw_cliente vw on (con.fk_cliente = vw.id_cliente) "
				+ "inner join tb_cliente cli on (vw.id_cliente = cli.id_cliente) "
				+ "left join tb_est_civil ec on (cli.fk_pf_est_civil = ec.id_est_civil) "
				+ "left join tb_nacio n1 on (cli.tp_pf_nacio = n1.id_nacio) "
				+ "left join tb_nacio n2 on (cli.tp_pf_conj_nacio = n2.id_nacio) "
				+ "where id_contrato = ?|tmp.id_contrato| ";
		populateMap(query, "cli");
		String dtNasc = map.get("cli_dd_pf_nasc");
		if (dtNasc != null && !dtNasc.equals("")) map.put("cli_ts_pf_nasc", fmtDt(dtNasc));
		else map.put("cli_ts_pf_nasc", "n�o informada");
		// recupera o endereco
		wiMap.put("tmp.id_endereco", map.get("cli_fk_endereco"));
		query = "select e.*, ts_cidade, ts_estado from tb_endereco e "
				+ "inner join tb_cidade c on (c.id_cidade = e.fk_cidade) "
				+ "inner join tb_estado es on (es.id_estado = c.fk_estado) "
				+ "where e.id_endereco = ?|tmp.id_endereco|";
		populateMap(query, "end");
		String endCompl = map.get("end_ts_compl");
		if (endCompl != null) endCompl = endCompl.trim();
		if (!endCompl.equals("")) map.put("end_ts_compl", " " + endCompl + ",");
		// recupera o contrato
		query = "select c.*, ts_area_juridica, ts_area_sigla, tp_regra_calc, "
				+ "concat(lpad(nr_contrato,4,'0'),'/',nr_ano) as lbl_contrato, ts_grp_cont, "
				+ "(select count(*) from tb_parcela where fk_contrato = c.id_contrato) qt_parcelas "
				+ "from tb_contrato c "
				+ "inner join tb_area_juridica a on (a.id_area_juridica = c.fk_area_juridica) "
				+ "inner join tb_tipo_contrato tc on (tc.id_tipo_contrato = c.fk_tipo_contrato)"
				+ "left join tb_grp_cont gc on (gc.id_grp_cont = c.fk_grp_cont)"
				+ "where c.id_contrato = ?|tmp.id_contrato|";
		populateMap(query, "cnt");
		String grpCont = map.get("cnt_ts_grp_cont").trim();   
		if (!grpCont.equals("")) grpCont += " - "; 
		map.put("cnt_lbl_grp_cont", grpCont);
		// recupera os advogados
		query = "select * from tb_advogado a "
				+ "inner join tb_est_civil c on (c.id_est_civil = a.fk_est_civil)"
				+ "where id_advogado = (select ts_parametro from tb_parametro where id_parametro = 'id_adv_socio')";
		populateMap(query, "adv1");
		wiMap.put("tmp.id_adv_dono", map.get("cli_fk_adv_dono"));
		query = "select * from tb_advogado a "
				+ "inner join tb_est_civil c on (c.id_est_civil = a.fk_est_civil)"
				+ "where id_advogado = ?|tmp.id_adv_dono|";
		populateMap(query, "adv2");
		map.put("adv2_ts_nr_oab_full", "");
		if (!map.get("adv2_tp_vinculo").equals("C")) {
			map.put("adv2_ts_nr_oab_full", "OAB/" + map.get("adv2_ts_nr_oab"));
		}
		wiMap.put("tmp.id_adv_resp", map.get("cnt_fk_adv_resp"));
		query = "select * from tb_advogado a "
				+ "inner join tb_est_civil c on (c.id_est_civil = a.fk_est_civil)";
		if (wiMap.get("tmp.id_adv_substab").trim().equals("")) {
			query += "where id_advogado = ?|tmp.id_adv_resp|";
		} else {
			query += "where id_advogado = ?|tmp.id_adv_substab|";
		}
		populateMap(query, "adv3");
		filterMap();
	}
	
	private void populateMap(String query, String prefix) throws Exception {
		DatabaseHandler dh = getParams().getDatabaseAliases().get("principal");
		ResultSet rs = dh.execute(query, wiMap);
		if (rs.next() > 0) {
			String[] names = rs.columnNames();
			for (int i = 0; i < names.length; i++) {
				String name = names[i];
				String value = rs.column(name);
				map.put(prefix + "_" + name, value);
			}
		}
	}
	
	private List<Map> socioList() throws Exception {
		List<Map> list = new ArrayList<Map>();
		DatabaseHandler dh = getParams().getDatabaseAliases().get("principal");
		String query = "select soc.*, ts_est_civil, n1.ts_nacio, n2.ts_nacio as ts_conj_nacio "
				+ "from tb_contrato con "
				+ "inner join tb_cliente cli on (cli.id_cliente = con.fk_cliente) "
				+ "inner join tb_socio soc on (soc.fk_cliente = cli.id_cliente) "
				+ "left join tb_est_civil ec on (soc.fk_est_civil = ec.id_est_civil) "
				+ "left join tb_nacio n1 on (soc.tp_nacio = n1.id_nacio) "
				+ "left join tb_nacio n2 on (soc.tp_conj_nacio = n2.id_nacio) "
				+ "where id_contrato = ?|tmp.id_contrato| and tp_cliente = 'J' "
				+ "and soc.st_removido = 0 "
				+ "order by soc.ts_nome";
		ResultSet rs = dh.execute(query, wiMap);
		while (rs.next() > 0) {
			Map<String, String> auxMap = new HashMap<String, String>();
			String[] names = rs.columnNames();
			for (int i = 0; i < names.length; i++) {
				String name = names[i];
				String value = rs.column(name);
				name = name.replace("ts_conj", "ts_pf_conj");
				name = name.replace("ts_pf_conj_nacio", "ts_conj_nacio");
				auxMap.put("cli_" + name, value);
			}
			String dtNasc = auxMap.get("cli_dd_pf_nasc");
			if (dtNasc != null && !dtNasc.equals("")) auxMap.put("cli_ts_pf_nasc", fmtDt(dtNasc));
			else auxMap.put("cli_ts_pf_nasc", "n�o informada");
			list.add(auxMap);
		}
		return list;
	}
	
	private String parcelas() throws Exception {
		StringBuilder resp = new StringBuilder();
		DatabaseHandler dh = getParams().getDatabaseAliases().get("principal");
		String id = map.get("cnt_id_contrato");
		ResultSet rs = dh.execute("select * from tb_parcela where fk_contrato = 0" + id 
				+ " order by dd_parcela", wiMap);
		float total = 0;
		while (rs.next() > 0) {
			if (!resp.toString().equals("")) resp.append(", ");
			Float parc = Function.parseFloat(rs.column("vl_parcela"));
			String parcTxt = new CurrencyWriter(false).write(new BigDecimal(parc));
			String txt = "R$ " + fmtNr(rs.column("vl_parcela")) + " (" + parcTxt + " reais) "
					+ "em " + fmtDt(rs.column("dd_parcela"));
			resp.append(txt);
			total = total + parc;
		}
		String totTxt = new CurrencyWriter(false).write(new BigDecimal(total));
		if (rs.rowCount() > 1) {
			resp.append(", totalizando o valor de R$ " + fmtNr(total+"") + " (" + totTxt + " reais)");
		}
		map.put("parcela_total", "R$ " + fmtNr(total+"") + " (" + totTxt + " reais)");
		return resp.toString();
	}
	
	private void filterMap() throws Exception {
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat sdf3 = new SimpleDateFormat("dd 'de' MMMM 'de' yyyy");
		String  dtcontrato = map.get("cnt_dt_contrato");
		map.put("cnt_dt_contrato", sdf2.format(sdf1.parse(dtcontrato)));
		map.put("cnt_dt_contrato_extenso", sdf3.format(sdf1.parse(dtcontrato)));
		String doc = map.get("cli_ts_doc");
		if (map.get("cli_tp_cliente").equals("F")) map.put("cli_ts_doc", "CPF " + doc);
		if (map.get("cli_tp_cliente").equals("J")) map.put("cli_ts_doc", "CNPJ " + doc);
		createvariables();
	}

	private void createvariables() throws Exception {
		String compId = "complemento_pf";
		if (map.get("cli_ts_pf_rg").trim().equals("")) compId = "complemento_pf_doc";
		if (map.get("cli_tp_cliente").equals("J")) {
			compId = "complemento_pj";
			if (map.get("cli_ts_pf_rg").trim().equals("")) compId = "complemento_pj_doc";
		}
		map.put("complemento", getPropValue(compId, ""));
		map.put("endereco", getPropValue("endereco", ""));
		map.put("endereco_proc", getPropValue("endereco_proc", ""));
		String conjuge = "";
		if (map.get("cnt_st_usar_conj").equals("1")) {
			String conjuId = "conjuge";
			if (map.get("cli_ts_pf_conj_rg").trim().equals("")) conjuId = "conjuge_doc";
			conjuge = getPropValue(conjuId, "");
		}
		map.put("conjuge", conjuge);
		// Se PJ verifica socios
		List<Map> socioList = socioList();
		map.put("socio_qtd", socioList.size() + "");
		if (socioList.size() > 0) {
			Map origMap = map;
			String comp = map.get("complemento") + map.get("conjuge");
			map.put("conjuge", "");
			for (Map<String, String> socioMap : socioList) {
				map = socioMap;
				compId = "socio_pj";
				if (map.get("cli_ts_rg").trim().equals("")) compId = "socio_pj_doc";
				String auxComp = getPropValue(compId, "");
				if (origMap.get("cnt_st_usar_conj").equals("1")) {
					String conjuId = "conjuge";
					if (map.get("cli_ts_pf_conj_rg").trim().equals("")) conjuId = "conjuge_doc";
					conjuge = getPropValue(conjuId, "");
					auxComp += conjuge;
				}
				comp += (socioList.indexOf(socioMap) + 1 < socioList.size()) ? ", " : " e ";
				comp += auxComp;
			}
			map = origMap;
			map.put("complemento", comp);
		}
		// Advogados
		String advogados = getPropValue("advogado", "adv1");
		if (!map.get("adv2_id_advogado").equals(map.get("adv1_id_advogado"))) {
			String key = "advogado";
			if (map.get("adv2_tp_vinculo").equals("C")) key = "consultor";
			advogados += ", " + getPropValue(key, "adv2");
		}
		//if (!map.get("adv3_id_advogado").equals(map.get("adv1_id_advogado")) && 
		//	!map.get("adv3_id_advogado").equals(map.get("adv2_id_advogado"))) {	
		//		advogados += ", " + getPropValue("advogado", "adv3");
		//}
		map.put("advogados", advogados);
		String adv_proc = "";
		if (!map.get("adv2_id_advogado").equals(map.get("adv1_id_advogado")) 
				&& !map.get("adv2_tp_vinculo").equals("C")) {
			adv_proc = getPropValue("advogado", "adv2") + "; ";
		}
		if (map.get("cnt_fk_area_juridica").equals("3")) {
			if (!map.get("adv3_id_advogado").equals(map.get("adv1_id_advogado"))
					&& !map.get("adv3_id_advogado").equals(map.get("adv2_id_advogado"))
					&& !map.get("adv3_tp_vinculo").equals("C")) {
				adv_proc += getPropValue("advogado", "adv3") + "; ";
			}
		}
		map.put("advogados_proc", adv_proc);
		String subsPai = "adv2";
		if (map.get("adv2_tp_vinculo").equals("C")) subsPai = "adv1";
		map.put("adv_substab_pai",getPropValue("advogado", subsPai));
		map.put("adv_substab",getPropValue("advogado", "adv3"));
		map.put("adv_subs_ts_nome", map.get(subsPai + "_ts_nome"));
		map.put("adv_subs_ts_nr_oab_full", "OAB/" + map.get(subsPai + "_ts_nr_oab"));
		String instancias = ", em primeira inst�ncia";
		if (map.get("cnt_nr_instancias").equals("2")) instancias = ", em segunda inst�ncia";
		if (map.get("cnt_nr_instancias").equals("12")) instancias = ", em primeira e segunda inst�ncias";
		if (map.get("cnt_nr_instancias").equals("3")) instancias = ", em Tribunal Superior";
		if (map.get("cnt_nr_instancias").equals("123")) instancias = ", em todas as inst�ncias";
		if (map.get("cnt_fk_tipo_vinculo").equals("CON")) instancias = "";
		map.put("instancias", instancias);
		// valor percentual inicial
		Float fl = Function.parseFloat(map.get("cnt_vl_perc_inic"));
		String extenso = new CurrencyWriter(false).write(new BigDecimal(fl));
		map.put("percentual", map.get("cnt_vl_perc_inic") + "% (" + extenso + " por cento)");
		// valor percentual adicional
		fl = Function.parseFloat(map.get("cnt_vl_perc_adic"));
		extenso = new CurrencyWriter(false).write(new BigDecimal(fl));
		map.put("percentual_adic", map.get("cnt_vl_perc_adic") + "% (" + extenso + " por cento)");
		String adic1 = "";
		String adic2 = "";
		if (!map.get("cnt_vl_perc_adic").equals("0.00")) {
			adic1 = getPropValue("adic1", "");
			adic2 = getPropValue("adic2", "");
		}
		map.put("adic1", adic1);
		map.put("adic2", adic2);
		// negacao de entrada e parcelado
		map.put("naoParcela", "");
		if (map.get("cnt_st_desc_pago").equals("0")) {
			map.put("naoParcela", "N�O");
		}
		// valor parcela
		boolean bPerc = map.get("cnt_tp_regra_calc").equalsIgnoreCase("PERC");
		Float fixo = Function.parseFloat(map.get("cnt_vl_fixo_final"));
		String parcMod = bPerc ? "parcela1" : "parcela2";
		if (!bPerc) {
			if (fixo == 0) parcMod = "parcela4";
			else if (map.get("cnt_st_fixo_exito").equals("0")) {
				parcMod = "parcela3";
			}
		}
		String pFull = getPropValue(parcMod,"") + " " + parcelas();
		map.put("parcela_full", pFull);
		// valor minimo final
		if (map.get("cnt_vl_min_final").equals("0.00")) {
			map.put("minimo", "um sal�rio m�nimo vigente � �poca");
		} else {
			Float fmin = Function.parseFloat(map.get("cnt_vl_min_final"));
			String minTxt = new CurrencyWriter(false).write(new BigDecimal(fmin));
			map.put("minimo", "R$ " + fmtNr(map.get("cnt_vl_min_final")) + " (" + minTxt + " reais)");
		}
		// valor fixo
		String fixoTxt = new CurrencyWriter(false).write(new BigDecimal(fixo));
		map.put("fixo_final", "R$ " + fmtNr(map.get("cnt_vl_fixo_final")) + " (" + fixoTxt + " reais)");
		String fixoExito = "";
		if (map.get("cnt_st_fixo_exito").equals("1")) {
			fixoExito = ", em caso de �xito, ";
		}
		map.put("fixo_exito", fixoExito);
		String fullParcTxt = "";
		int nrFixoParc = Function.parseInt(map.get("cnt_nr_fixo_parc"));
		if (nrFixoParc > 1) {
			Float vlParc = fixo / nrFixoParc;
			String parcTxt = new CurrencyWriter(false).write(new BigDecimal(vlParc));
			fullParcTxt = "em " + nrFixoParc + " parcelas iguais e sucessivas de"
					+ " R$ " + fmtNr(vlParc+"") + " (" + parcTxt + " reais), ";
		}
		String fixoFinal = map.get("cnt_tx_fixo_final").trim();
		if (fixoFinal.equals("")) fixoFinal = getPropValue("final_txt","");
		map.put("final_detalhe", fullParcTxt + fixoFinal);
		String fixoFull = getPropValue(fixo>0?"fixo1":"fixo2","");
		map.put("fixo_full", fixoFull);
	}

	private String getPropValue(String key, String replace) throws Exception {
		if (docxProps == null) {
			String projPath = wiMap.get("wi.proj.path");
			docxProps = new Properties();
	    	InputStream is = new FileInputStream(projPath + "/WEB-INF/docx.properties");
	    	docxProps.load(is);
	        is.close();
		}
		String value = docxProps.getProperty(key);
		if (value == null) value = "";
		return prodProperty(value, replace);
	}
	
	private String prodProperty(String text, String replace) throws Exception {
		StringBuilder resp = new StringBuilder();
		int from = 0, pos = 0;
		while ((pos = text.indexOf("${", from)) > -1) {
			int pos2 = text.indexOf("}",pos);
			if (pos2 == -1) pos2 = text.length();
			String var = text.substring(pos+2,pos2);
			if (replace.startsWith("adv")) {
				var = var.replace("adv_", replace + "_");
			}
			resp.append(text.substring(from, pos));
			resp.append(map.get(var));
			from = pos2 + 1;
		}
		if (from < text.length()) {
			resp.append(text.substring(from, text.length()));
		}
		return resp.toString();
	}
	
	private void writeXml(MainDocumentPart docPart, File file) throws Exception {
		String docXml = XmlUtils.marshaltoString(docPart.getContents(), true, true);
		Files.write(Paths.get(file.getAbsolutePath()), docXml.getBytes("UTF-8"));
	}
	
    private String fmtDt(String date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdfOld = new SimpleDateFormat("yyyy-MM-dd");
        Date d = sdfOld.parse(date, new ParsePosition(0));
        if (d != null) {
            return sdf.format(d);
        } else {
        	return "";
        }
    }

    private String fmtNr(String number) {
    	Locale locale = new Locale("pt", "br");
        DecimalFormat df = (DecimalFormat) NumberFormat.getCurrencyInstance(locale);
    	df.setPositivePrefix("");
    	df.setNegativePrefix("-");
        df.setDecimalSeparatorAlwaysShown(true);
        df.setMinimumFractionDigits(2);
        df.setMaximumFractionDigits(2);
    	if (number.trim().equals("")) number = "0";
        char sep = df.getDecimalFormatSymbols().getDecimalSeparator();
        if (number.indexOf(sep) > -1) return number;
        return (df.format(Double.parseDouble(number)));    	
    }
    
	@Override
	public boolean exit() {
		return true;
	}

}
