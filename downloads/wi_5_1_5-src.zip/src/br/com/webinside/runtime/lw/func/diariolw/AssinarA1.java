package br.com.webinside.runtime.lw.func.diariolw;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class AssinarA1 extends AbstractConnector implements InterfaceParameters {

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers)
	throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			String op = wiMap.get("tmp.tp_operacao").toLowerCase().trim(); 
			if (op.equals("assinar")) {
				assinar(dh, wiMap);
			} else if (op.equals("info")) {
				info(dh, wiMap);
			}
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}

	private void info(DatabaseHandler dh, WIMap wiMap) throws Exception {
		String tmpFolder = Function.rndTmpFolder("assinador");
		new File(tmpFolder).mkdirs();
		String pfx = tmpFolder + "/certificado.pfx";
		getParams().getFileUpload().saveFile("tmp.pfx", pfx);
		Properties props = new Properties();
		props.setProperty("cert_info", "true");
		FileWriter writer = new FileWriter(tmpFolder + "/assinador.props");
		props.store(writer,"Propriedades");
		writer.close();
		runJava(wiMap, tmpFolder);
		FileReader reader = new FileReader(tmpFolder + "/resultado.props");
		props.load(reader);
		reader.close();
		String resultado = props.getProperty("resultado");
		if (!resultado.equals("OK")) {
			wiMap.put("tmp.msg_error", resultado);
			dh.executeUpdate("delete from tb_certificado"
					+ " where id_certificado = ?|tmp.obj.id_certificado|", wiMap);
		} else {
			wiMap.put("tmp.obj.dt_expira", props.getProperty("cert_expire"));
			dh.executeUpdate("update tb_certificado"
					+ " set dt_expira = ?|tmp.obj.dt_expira|"
					+ " where id_certificado = ?|tmp.obj.id_certificado|", wiMap);
			String path = wiMap.get("pvt.lwpath.priv");
			String cert = "c" + wiMap.get("tmp.obj.id_certificado");
			File pfxDest = new File(path,"/diario/certificado/" + cert + ".pfx");
			Function.copyFile(pfx, pfxDest.getAbsolutePath(), true);
		}
		Function.removeDir(tmpFolder);
	}

	private void assinar(DatabaseHandler dh, WIMap wiMap) throws Exception {
		String query = "SELECT * FROM tb_edicao e "
				+ "INNER JOIN tb_assinatura a ON (a.id_assinatura = e.fk_assinatura) "
				+ "where id_assinatura = ?|tmp.obj.id_assinatura|";
		ResultSet rs = dh.execute(query, wiMap);
		rs.next();
		String idEdi = rs.column("id_edicao");
		String dtAss = rs.column("dt_assinatura");
		String tsChave = rs.column("ts_chave");
		if (!dtAss.trim().equals("")) {
			wiMap.put("tmp.msg_error", "Edi��o j� assinada");
			return;
		}
		String tmpFolder = Function.rndTmpFolder("assinador");
		new File(tmpFolder).mkdirs();
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		wiMap.put("tmp.data", sdf1.format(new Date()));
		wiMap.put("tmp.nome", wiMap.get("pvt.login.ts_nome"));
		wiMap.put("tmp.cpf", wiMap.get("pvt.login.ts_cpf"));
		wiMap.put("tmp.id_assinatura", rs.column("id_assinatura"));
		String path = wiMap.get("pvt.lwpath.priv");
		String keyEdicao = rs.column("nr_edicao") + rs.column("tp_edicao");
		File pdf = new File(path,"/diario/concluido/" + keyEdicao + ".pdf");
		Function.copyFile(pdf.getAbsolutePath(), tmpFolder + "/diario.pdf");
		File pdfSigned = new File(path,"/diario/concluido/" + keyEdicao + "-signed.pdf");
		String cert = "c" + wiMap.get("tmp.id_certificado");
		File pfxFrom = new File(path,"/diario/certificado/" + cert + ".pfx");
		String pfx = tmpFolder + "/certificado.pfx";
		Function.copyFile(pfxFrom.getAbsolutePath(), pfx);
		Properties props = new Properties();
		props.setProperty("data", wiMap.get("tmp.data"));
		props.setProperty("nome", wiMap.get("tmp.nome"));
		props.setProperty("cpf", wiMap.get("tmp.cpf"));
		props.setProperty("chave", tsChave);
		FileWriter writer = new FileWriter(tmpFolder + "/assinador.props");
		props.store(writer,"Propriedades");
		writer.close();
		runJava(wiMap, tmpFolder);
		FileReader reader = new FileReader(tmpFolder + "/resultado.props");
		props.load(reader);
		reader.close();
		if (new File(tmpFolder + "/diario-signed.pdf").length() > 0) {
			Function.copyFile(tmpFolder + "/diario-signed.pdf", pdfSigned.getAbsolutePath());
		}
		Function.removeDir(tmpFolder);
		String resultado = props.getProperty("resultado");
		if (!resultado.equals("OK")) {
			wiMap.put("tmp.msg_error", resultado);
			return;
		}
		String update = "update tb_assinatura "
				+ "set dt_assinatura = ?|tmp.data|, ts_nome = ?|tmp.nome|, ts_cpf = ?|tmp.cpf| "
				+ "where id_assinatura = ?|tmp.id_assinatura|";
		dh.executeUpdate(update, wiMap);
		update = "update tb_edicao set st_publicada = 1 where id_edicao = 0" + idEdi;
		dh.executeUpdate(update, wiMap);
		new EbookThread(pdfSigned).start();
	}

	private void runJava(WIMap wiMap, String tmpFolder) throws Exception {
		File cp = new File(wiMap.get("wi.proj.path"),"/WEB-INF/assinador/*");
		String javaHome = System.getProperty("java.home");
		String javaExec = javaHome + "/bin/java";
		if (System.getProperty("os.name").startsWith("Windows")) { 
			javaExec += ".exe";
		}            
		List<String> cmd = new ArrayList<>();
		cmd.add(javaExec);
		cmd.add("-cp");
		cmd.add(cp.getAbsolutePath());
		cmd.add("br.com.lineweb.AssinadorAppA1");
		cmd.add(tmpFolder);
		cmd.add(wiMap.get("tmp.pass_a1"));
		ProcessBuilder pb = new ProcessBuilder(cmd);
		pb.directory(new File(tmpFolder));
		pb.start().waitFor();
	}
	
	@Override
	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[1];
		in[0] = new JavaParameter("tmp.tp_operacao", "Tipo Opera��o (Assinar/Info)");
		return in;
	}

	@Override
	public JavaParameter[] getOutputParameters() {
		return null;
	}

}
