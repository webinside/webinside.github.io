/*
 * WEBINSIDE - Ferramenta de produtividade Java
 * Copyright (c) 2011-2012 LINEWEB Solu��es Tecnol�gicas Ltda.
 * Copyright (c) 2009-2010 Inc�gnita Intelig�ncia Digital Ltda.
 *
 * Este programa � software livre; voc� pode redistribu�-lo e/ou modific�-lo 
 * sob os termos da GNU LESSER GENERAL PUBLIC LICENSE (LGPL) conforme publicada 
 * pela Free Software Foundation; vers�o 2.1 da Licen�a.
 * Este programa � distribu�do na expectativa de que seja �til, por�m, SEM 
 * NENHUMA GARANTIA; nem mesmo a garantia impl�cita de COMERCIABILIDADE OU 
 * ADEQUA��O A UMA FINALIDADE ESPEC�FICA.
 * 
 * Consulte a GNU LGPL para mais detalhes.
 * Voc� deve ter recebido uma c�pia da GNU LGPL junto com este programa; se n�o, 
 * veja em http://www.gnu.org/licenses/ 
 */

package br.com.webinside.runtime.lw.juris;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import br.com.webinside.runtime.core.ExecuteParams;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.InterfaceGrid;
import br.com.webinside.runtime.util.ElasticUtil;
import br.com.webinside.runtime.util.WIMap;

public class JurisprudSearch implements InterfaceGrid {

	private int returntype;

    public Map[] execute(WIMap wiMap, DatabaseAliases dbAliases) {
        returntype = HAS_MORE_ROWS;
        int from = 1;
        int limit = 0;
        try {
        	limit = Integer.parseInt(wiMap.get("grid.limit"));
            String next = "grid." + wiMap.get("grid.id") + ".next";
            from = Integer.parseInt(wiMap.get(next));
        } catch (NumberFormatException err) {
        	// ignorado.
        }

        long total = 0;
        List completa = new ArrayList();

		ElasticUtil.INDEX = "/jurisprud";

		String className = getClass().getName();
		try {
            JSONObject rootQuery = new JSONObject();
            rootQuery.put("from", from-1);
            rootQuery.put("size", limit);

            if (!wiMap.get("tmp.search").equals("")) {
            	ElasticUtil.jsonArr(rootQuery, "sort", "st_importante", "desc");
	            ElasticUtil.jsonArr(rootQuery, "sort", "dd_jurisprud", "desc");
            }
            ElasticUtil.jsonArr(rootQuery, "sort", "id_jurisprud", "desc");
            
            JSONObject source = ElasticUtil.jsonObj(rootQuery, "_source");
            ElasticUtil.jsonArr(source, "excludes", "tx_html", null);
            ElasticUtil.jsonArr(source, "excludes", "base64", null);
            ElasticUtil.jsonArr(source, "excludes", "attachment.content", null);
            
            JSONObject query = ElasticUtil.jsonObj(rootQuery, "query");
            JSONObject bool = ElasticUtil.jsonObj(query, "bool");
            JSONObject must = ElasticUtil.jsonObj(bool, "must");
            
            if (!wiMap.get("tmp.search").equals("")) {
	            JSONObject squery = ElasticUtil.jsonObj(must, "simple_query_string");
	            ElasticUtil.jsonArr(squery, "fields", "ts_jurisprud", null);
	            ElasticUtil.jsonArr(squery, "fields", "tx_keywords", null);
	            ElasticUtil.jsonArr(squery, "fields", "tx_html", null);
	            ElasticUtil.jsonArr(squery, "fields", "attachment.content", null);
	            squery.put("query", wiMap.get("tmp.search").trim());
	            squery.put("default_operator", "and");
            } else {
                JSONObject term = ElasticUtil.jsonObj(must, "term");
                term.put("type", "doc");
            }
            
            String importante = wiMap.get("tmp.st_importante");
            if (importante.equals("1")) {
                JSONObject obj = new JSONObject();
                obj.put("st_importante", "1");
                ElasticUtil.jsonArr(bool, "filter", "term", obj);
            }
            
            String categoria = wiMap.get("tmp.fk_cat_jrsprd");
            if (!categoria.equals("")) {
                JSONObject obj = new JSONObject();
                obj.put("fk_cat_jrsprd", categoria);
                ElasticUtil.jsonArr(bool, "filter", "term", obj);
            }

            String usuario = wiMap.get("tmp.fk_usuario");
            if (!usuario.equals("")) {
                JSONObject obj = new JSONObject();
                obj.put("fk_usuario", usuario);
                ElasticUtil.jsonArr(bool, "filter", "term", obj);
            }
            
            if (!wiMap.get("tmp.buscar").equals("")) {
                JSONObject obj = new JSONObject();
                obj.put("type", wiMap.get("tmp.buscar"));
                ElasticUtil.jsonArr(bool, "filter", "term", obj);
            }
            
            if (!wiMap.get("tmp.search").equals("")) {
	            JSONObject high = ElasticUtil.jsonObj(rootQuery, "highlight");
	            high.put("fragment_size", "150");
	            JSONObject fields = ElasticUtil.jsonObj(high, "fields");
	            fields.put("ts_jurisprud", new JSONObject());
	            fields.put("tx_keywords", new JSONObject());
	            fields.put("tx_html", new JSONObject());
	            fields.put("attachment.content", new JSONObject());
            }    

            // PROCESSAR
            JSONObject respJson = ElasticUtil.sendHttp(ElasticUtil.POST, "/_search", rootQuery);
            JSONObject hitsObj = (JSONObject)respJson.get("hits");
            JSONObject totalObj = (JSONObject)hitsObj.get("total"); 
            total = (long) totalObj.get("value");
            JSONArray array = (JSONArray)hitsObj.get("hits");
            for (int i = 0; i < array.size(); i++) {
            	JSONObject doc = (JSONObject) array.get(i);
                Map aux = new HashMap();
                aux.put("id", doc.get("_id"));
            	JSONObject respSource = (JSONObject) doc.get("_source");
                for (Object key : respSource.keySet()) {
                    aux.put(key, respSource.get(key));
				}
            	JSONObject respHigh = (JSONObject) doc.get("highlight");
            	if (respHigh != null) {
	                for (Object key : respHigh.keySet()) {
	                	String strKey = (String)key;
	                	StringBuilder value = new StringBuilder();
	                	JSONArray arr = (JSONArray) respHigh.get(key);
	                	for (int j = 0; j < arr.size(); j++) {
	                		if (value.length() > 0) value.append("<br/>\n");
	                		value.append(arr.get(j));
						}
	                	if (strKey.equals("tx_html") || strKey.equals("attachment.content")) {
	                        aux.put("highlight", value.toString());
	                	} else {
	                		aux.put("hl_" + strKey, value.toString());
	                	}
					}
            	}
                completa.add(aux);
			}
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			ExecuteParams.get().getErrorLog().write(className, "Page: " + pageId, err);
			wiMap.put("tmp.msg_error", "Falha de acesso ao ElasticSearch");
		}
        
        wiMap.put("grid.jurisprud_json.rowcount", total + "");
        if (from + limit > completa.size()) {
            returntype = NO_MORE_ROWS;
        }
        return (Map[])completa.toArray(new Map[0]);
    }

    public int returnType() {
        return returntype;
    }

}
