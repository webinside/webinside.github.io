package br.com.webinside.runtime.lw.juris;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.StringA;
import br.com.webinside.runtime.util.WIMap;

public class DownloadContratoPdfs extends AbstractConnector implements InterfaceParameters {

	private WIMap wiMap = null;

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) 
	throws UserException {
		this.wiMap = wiMap;
		String className = getClass().getName();
		try {
			execute(databases.get("principal"));
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
	
	private void execute(DatabaseHandler dh) throws Exception {
		String idCont = wiMap.get("tmp.id_contrato");
        File tmpFolder = new File(Function.rndTmpFolder("dow")); 
        tmpFolder.mkdirs();
		String path = wiMap.get("wi.proj.path");
		String sql = "SELECT * FROM tb_cont_doc WHERE fk_contrato = " + idCont + " AND st_removido = 0";
		ResultSet rs = dh.execute(sql, wiMap);
		while (rs.next() > 0) {
			String filename = rs.column("ts_cont_doc");
			filename = StringA.getForFile(filename).toUpperCase();
			String idDoc = rs.column("id_cont_doc");
			File source = new File(path + "/WEB-INF/storage/documento/d" + idDoc + ".pdf");
			Function.copyFile(source.getAbsolutePath(), tmpFolder + "/" + filename + ".pdf");
		}
		sql = "SELECT r.id_reuniao, ts_reuniao FROM tb_cont_reuniao cr "
				+ "INNER JOIN tb_reuniao r ON (r.id_reuniao= cr.id_reuniao) "
				+ "WHERE id_contrato = " + idCont + " AND st_removido = 0";
		rs = dh.execute(sql, wiMap);
		while (rs.next() > 0) {
			String filename = rs.column("ts_reuniao");
			filename = StringA.getUsAscii(filename).toUpperCase().replace(" ", "_");
			String idDoc = rs.column("id_reuniao");
			File source = new File(path + "/WEB-INF/storage/reuniao/r" + idDoc + ".pdf");
			Function.copyFile(source.getAbsolutePath(), tmpFolder + "/" + filename + ".pdf");
		}
        File zipFile = new File(tmpFolder + "/documentos.zip");
        zipFile.getParentFile().mkdirs();
		FileOutputStream fos = new FileOutputStream(zipFile);
		ZipOutputStream zos = new ZipOutputStream(fos);
		List<String> exclude = new ArrayList();
		exclude.add("documentos.zip");
		Function.doZIPFile(tmpFolder.getAbsolutePath(), tmpFolder, zos, exclude);
		zos.close();
		fos.close();
		HttpServletResponse response = getParams().getHttpResponse();
		response.setContentType("application/zip");
		response.setHeader("Content-Disposition", "attachment; filename=" + zipFile.getName());
		response.setContentLength((int) zipFile.length());
		Function.sendFile(zipFile, response.getOutputStream());
		FileUtils.deleteDirectory(tmpFolder);
		// Limpando documentos removidos
		String sqlRemove = "SELECT id_cont_doc FROM tb_cont_doc WHERE st_removido = 1";
		ResultSet rsRemove = dh.execute(sqlRemove, wiMap);
		while (rsRemove.next() > 0) {
			String idDoc = rsRemove.column("id_cont_doc");
			File pdf = new File(path + "/WEB-INF/storage/documento/d" + idDoc + ".pdf");
			if (pdf.isFile()) pdf.delete();
		}
	}	

	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[1];
		in[0] = new JavaParameter("tmp.id_contrato", "ID do contrato");
		return in;
	}

	public JavaParameter[] getOutputParameters() {
		return new JavaParameter[0];
	}

	@Override
	public boolean exit() {
		return true;
	}

}
