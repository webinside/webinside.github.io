package br.com.webinside.runtime.lw.juris.smtp;

import java.io.File;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;

public class EmailAttach {

	private String name;
	private File file;

	public EmailAttach(String name, File file) {
		super();
		this.name = name;
		this.file = file;
	}

	public MimeBodyPart getMimeBodyPart() throws MessagingException {
        MimeBodyPart att = new MimeBodyPart();
        DataSource source = new FileDataSource(file);
        att.setDataHandler(new DataHandler(source));
        att.setFileName(name);
        att.setContentID("<" + file.getName() + ">");
		return att;
	}
	
}
