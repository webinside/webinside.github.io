package br.com.webinside.runtime.lw.func.diariolw;

import java.io.File;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.util.WIMap;

public class LimparImgB64 extends AbstractConnector {

	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			String query = "select * from tb_conteudo_img im "
					+ "inner join tb_conteudo co on (co.id_conteudo = im.id_conteudo) "
					+ "where im.id_conteudo = ?|tmp.obj.id_conteudo| order by id_img_seq";
			ResultSet rs = dh.execute(query, wiMap);
			while (rs.next() > 0) {
				int idSeq = Integer.parseInt(rs.column("id_img_seq"));
				String oldMS = rs.column("nr_marg_sup");
				String newMS = wiMap.get("tmp.pdf[" + idSeq + "].nr_marg_sup");
				if (!oldMS.equals(newMS)) {
					String idCont = rs.column("id_conteudo");
					String key = rs.column("ts_cont_key");
					String pngFolder = wiMap.get("pvt.lwpath.pub") + "/diario/doc-img";
					String imgFolder = pngFolder + "/c" + idCont + "-" + key;
					new File(imgFolder + "/pg-" + (idSeq-1) + ".html").delete();
				}
			}
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}

}
