package br.com.webinside.runtime.lw.func.diariolw;

import java.io.BufferedReader;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.ElasticUtil;
import br.com.webinside.runtime.util.WIMap;

public class PesquisaPageDownload extends AbstractConnector implements InterfaceParameters {

	private boolean exit = true;
	
	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) 
	throws UserException {
		String className = getClass().getName();
		try {
			ElasticUtil.INDEX = "/diariolw";
			String pgId = wiMap.get("tmp.sid_pdf");
			if (!wiMap.get("tmp.pdf_page_type").equalsIgnoreCase("text")) {
				ElasticUtil.exportPdf(getParams().getHttpResponse(), pgId);		
			} else {
				exit = false;
				String search = wiMap.get("pvt.pesquisa_search").trim();
	            JSONObject rootQuery = new JSONObject();
	            JSONObject query = ElasticUtil.jsonObj(rootQuery, "query");
	            JSONObject bool = ElasticUtil.jsonObj(query, "bool");
	            JSONObject must = ElasticUtil.jsonObj(bool, "must");
	            if (!search.equals("")) {
		            JSONObject squery = ElasticUtil.jsonObj(must, "simple_query_string");
		            ElasticUtil.jsonArr(squery, "fields", "attachment.content", null);
		            squery.put("query", search);
		            squery.put("analyze_wildcard", "true");
		            squery.put("default_operator", "and");
		            JSONObject high = ElasticUtil.jsonObj(rootQuery, "highlight");
		            high.put("number_of_fragments", "0");
		            JSONObject fields = ElasticUtil.jsonObj(high, "fields");
		            fields.put("attachment.content", new JSONObject());      
	                JSONObject obj = new JSONObject();
	                obj.put("_id", pgId);
	                ElasticUtil.jsonArr(bool, "filter", "term", obj);
	            } else {
	                JSONObject term = ElasticUtil.jsonObj(must, "term");
	                term.put("_id", pgId);
	            }
	            // PROCESSAR
	            JSONObject respJson = ElasticUtil.sendHttp(ElasticUtil.POST, "/_search", rootQuery);
	            JSONObject hitsObj = (JSONObject) respJson.get("hits");
	            if (hitsObj == null) return;
	            JSONArray array = (JSONArray) hitsObj.get("hits");
	            if (array == null) return;
            	JSONObject doc = (JSONObject) array.get(0);	            
				JSONObject source = (JSONObject) doc.get("_source");
				JSONObject attach = (JSONObject) source.get("attachment");
				String content = (String) attach.get("content");
            	JSONObject respHigh = (JSONObject) doc.get("highlight");
            	if (respHigh != null) {
	            	StringBuilder value = new StringBuilder();
	            	JSONArray arr = (JSONArray) respHigh.get("attachment.content");
	            	for (int j = 0; j < arr.size(); j++) {
	            		if (value.length() > 0) value.append("<br/>\n");
	            		value.append(arr.get(j));
					}
	            	content = value.toString();
            	}	
				String resp = "";
				String line = "";
				BufferedReader r = new BufferedReader(new StringReader(content));
				while ((line = r.readLine()) != null) {
					if (!line.trim().equals("")) {
						resp += line + "<br/>\n"; 
					}
				}
				SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
				SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy");
				String ed = (String)source.get("nr_pdf");
				String tp = (String)source.get("tp_pdf");
				Date dd = sdf1.parse((String)source.get("dd_pdf"));
				if (tp.equals("R")) ed += " (Regular)";
				if (tp.equals("S")) ed += " (Suplementar)";
				if (tp.equals("E")) ed += " (Extra)";
				String pg = (String)source.get("id_pdf_page");
				wiMap.put("tmp.title", "Edi��o " + ed + " - " + sdf2.format(dd) + " - Texto da p�gina " + pg);
				wiMap.put("tmp.content", resp);
			}			
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
			wiMap.put("tmp.msg_error", "Falha de acesso ao ElasticSearch");
		}
	}
	
	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[1];
		in[0] = new JavaParameter("tmp.sid_pdf", "ID da url para baixar o pdf");
		return in;
	}

	public JavaParameter[] getOutputParameters() {
		return new JavaParameter[0];
	}

	@Override
	public boolean exit() {
		return exit;
	}

}
