/*
 * WEBINSIDE - Ferramenta de produtividade Java
 * Copyright (c) 2011-2012 LINEWEB Solu��es Tecnol�gicas Ltda.
 * Copyright (c) 2009-2010 Inc�gnita Intelig�ncia Digital Ltda.
 *
 * Este programa � software livre; voc� pode redistribu�-lo e/ou modific�-lo 
 * sob os termos da GNU LESSER GENERAL PUBLIC LICENSE (LGPL) conforme publicada 
 * pela Free Software Foundation; vers�o 2.1 da Licen�a.
 * Este programa � distribu�do na expectativa de que seja �til, por�m, SEM 
 * NENHUMA GARANTIA; nem mesmo a garantia impl�cita de COMERCIABILIDADE OU 
 * ADEQUA��O A UMA FINALIDADE ESPEC�FICA.
 * 
 * Consulte a GNU LGPL para mais detalhes.
 * Voc� deve ter recebido uma c�pia da GNU LGPL junto com este programa; se n�o, 
 * veja em http://www.gnu.org/licenses/ 
 */

package br.com.webinside.runtime.lw.func.diariolw;

import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import org.imgscalr.Scalr;
import org.imgscalr.Scalr.Rotation;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.lw.img.ImgEnum;
import br.com.webinside.runtime.lw.img.ImgUtil;
import br.com.webinside.runtime.util.CmdUtil;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class ConteudoRecorte extends AbstractConnector implements InterfaceParameters {

	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			String action = wiMap.get("tmp.diario.tipo").toLowerCase().trim();
			int idCont = Function.parseInt(wiMap.get("tmp.diario.id_conteudo").trim());
			int idPag = Function.parseInt(wiMap.get("tmp.diario.id_pagina").trim());
			if (idPag < 1) idPag = 1;
			String query = "select ts_cont_key from tb_conteudo";
			query += " where id_conteudo = ?|tmp.diario.id_conteudo|";
			ResultSet rsKey = dh.execute(query, wiMap);
			String contKey = rsKey.columnNext(1);
			String pngFolder = wiMap.get("pvt.lwpath.pub") + "/diario/doc-img";
			String imgFolder = pngFolder + "/c" + idCont + "-" + contKey;
			if (action.equals("save")) {
				String[] lote = (idPag + "," + wiMap.get("tmp.crop_page")).split(",");
				for (String pg : lote) {
					int ipg = Function.parseInt(pg.trim());
					if (ipg > 0) doCrop(wiMap, imgFolder, ipg);
				}
			} else if (action.equals("autocrop")) {
				int count = 1;
				String[] lote = (idPag + "," + wiMap.get("tmp.crop_page")).split(",");
				for (String pg : lote) {
					int ipg = Function.parseInt(pg.trim());
					if (ipg > 0) {
						String msgPos = "auto recorte " + count + " de " + lote.length;
						ShowMessage.addMessage(wiMap, "crop", "Processando " + msgPos);
						String fname = "pg-" + (ipg-1) + ".png";
						List<String> cmd = new ArrayList<String>();
						cmd.add(CmdUtil.getConvertPath());
						cmd.add("#{source}.png");
						cmd.add("-fuzz");
						cmd.add("50%");
						cmd.add("-trim");
						cmd.add("-bordercolor");
						cmd.add("White");
						cmd.add("-border");
						cmd.add("10");
						cmd.add("#{target}.png");
						if (new File(imgFolder, fname).isFile()) {
							ImgUtil.execute(cmd, imgFolder, fname, fname, false);
						}
					}
					count ++;
				}
				Function.sleep(1000);
			} else if (action.equals("desfazer") || 
					action.equals("direita") || action.equals("esquerda")) {
				String pdfFolder = wiMap.get("pvt.lwpath.priv") + "/diario/documento";
				String pdfFile = pdfFolder + "/doc-" + idCont + ".pdf";
				String tmpFolder = Function.rndTmpFolder("pdf");
		        String tmpFile = tmpFolder + "/file.pdf";
		        Function.copyFile(pdfFile, tmpFile, true);
				int count = 1;
				String[] lote = (idPag + "," + wiMap.get("tmp.crop_page")).split(",");
				for (String pg : lote) {
					int ipg = Function.parseInt(pg.trim());
					if (ipg > 0) {
						String msgPos = "Preparando para rota��o " + count + " de " + lote.length;
						if (action.equals("desfazer")) {
							msgPos = "Processando desfazer " + count + " de " + lote.length;
						}
						ShowMessage.addMessage(wiMap, "crop", msgPos);
						wiMap.put("tmp.id_pagina", pg);
						boolean doUpd = action.equals("desfazer");
						undo(wiMap, dh, tmpFolder, imgFolder, ipg, doUpd);
					}
					count ++;
				}
				Function.removeDir(tmpFolder);
				if (action.equals("direita") || action.equals("esquerda")) {
					int count2 = 1;
					String[] lote2 = (idPag + "," + wiMap.get("tmp.crop_page")).split(",");
					for (String pg : lote2) {
						int ipg = Function.parseInt(pg.trim());
						if (ipg > 0) {
							String msgPos = "Rotacionando " + count2 + " de " + lote.length;
							ShowMessage.addMessage(wiMap, "crop", msgPos);
							wiMap.put("tmp.id_pagina", pg);
							query = "select vl_rotacao from tb_conteudo_img "
									+ "where id_conteudo = ?|tmp.obj.id_conteudo| "
									+ "and id_img_seq = ?|tmp.id_pagina|";
							String rotacao = dh.execute(query, wiMap).columnNext(1);
							float oldRot = Function.parseFloat(rotacao);
							float newRot = doRotate(wiMap, imgFolder, ipg, action, oldRot);
							if (oldRot != newRot) {
								doRotateSql(wiMap, dh, newRot);
							}
						}
						count2 ++;
					}
				}
			}
			wiMap.put("tmp.id_pagina", idPag);
			Function.sleep(1000);
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}

	private void doRotateSql(WIMap wiMap, DatabaseHandler dh, float newRot) throws Exception {
		String query = "select 'true' as found from tb_conteudo_img "
				+ "where id_conteudo = ?|tmp.obj.id_conteudo| "
				+ "and id_img_seq = ?|tmp.id_pagina|";
		String found = dh.execute(query, wiMap).columnNext("found");
		String update = "";
		if (found.equals("true")) {
			update = "update tb_conteudo_img "
					+ "set vl_rotacao = " + newRot + " "
					+ "where id_conteudo = ?|tmp.obj.id_conteudo| "
					+ "and id_img_seq = ?|tmp.id_pagina|";
		}
		dh.executeUpdate(update, wiMap);
	}

	private float doRotate(WIMap wiMap, String imgFolder, int idPag, String action, float oldRot) 
			throws Exception {
		String pngFile = imgFolder + "/pg-" + (idPag-1) + ".png";
		String srot = wiMap.get("tmp.rot_graus").trim().replace(',', '.');
		Float rot = Function.parseFloat(srot);
		if (action.equals("direita")) rot = oldRot + rot;
		while (rot > 360) rot = rot - 360;
		if (action.equals("esquerda")) rot = oldRot - rot;
		while (rot < 0) rot = rot + 360;
		if (rot == 360) rot = 0f;
		if (rot == 90 || rot == 180 || rot == 270) {
			BufferedImage orig = ImageIO.read(new File(pngFile));
			boolean doRotate = true;
			String rotSmart = wiMap.get("tmp.rot_smart"); 
			if (rotSmart.equals("R") && orig.getWidth() < orig.getHeight()) doRotate = false; 
			if (rotSmart.equals("P") && orig.getWidth() > orig.getHeight()) doRotate = false; 
			if (doRotate) {
				BufferedImage rotate = null;
				if (rot == 90) {
					rotate = Scalr.rotate(orig, Rotation.CW_90);
				} else if (rot == 180) {
					rotate = Scalr.rotate(orig, Rotation.CW_180);
				} else {
					rotate = Scalr.rotate(orig, Rotation.CW_270);
				}
				ImageIO.write(rotate, "png", new File(pngFile));
				rotate.flush();
			} else rot = oldRot;
			orig.flush();
		} else if (rot > 0) {
			String pngNew = "pg-" + (idPag-1) + "-new.png";
			List<String> cmd = new ArrayList<String>();
			cmd.add(CmdUtil.getConvertPath());
			cmd.add("-rotate");
			cmd.add(rot + "");
			cmd.add("pg-" + (idPag-1) + ".png");
			cmd.add(pngNew);
			CmdUtil.execute(imgFolder, cmd);
			new File(pngFile).delete();
			new File(imgFolder + "/" + pngNew).renameTo(new File(pngFile));
		}
		return rot;
	}
		
	private void doCrop(WIMap wiMap, String imgFolder, int idPag) throws Exception {
		String pngFile = imgFolder + "/pg-" + (idPag-1) + ".png";
		int idWtotal = Function.parseInt(wiMap.get("tmp.nr_wtotal").trim());
		int idHtotal = Function.parseInt(wiMap.get("tmp.nr_htotal").trim());
		int idWinicial = Function.parseInt(wiMap.get("tmp.nr_winicial").trim());
		int idHinicial = Function.parseInt(wiMap.get("tmp.nr_hinicial").trim());
		int idWfinal = Function.parseInt(wiMap.get("tmp.nr_wfinal").trim());
		int idHfinal = Function.parseInt(wiMap.get("tmp.nr_hfinal").trim());
		if (idWtotal > 0 && idHtotal > 0) {
			BufferedImage orig = ImageIO.read(new File(pngFile));
			int w1 = Math.round(idWinicial * orig.getWidth() / idWtotal);
			int h1 = Math.round(idHinicial * orig.getHeight() / idHtotal);
			int w2 = Math.round(idWfinal * orig.getWidth() / idWtotal);
			int h2 = Math.round(idHfinal * orig.getHeight() / idHtotal);
			BufferedImage crop = orig.getSubimage(w1, h1, w2 - w1, h2 - h1);			
			ImageIO.write(crop, "png", new File(pngFile));			
			orig.flush();
		}
	}

	private void undo(WIMap wiMap, DatabaseHandler dh, String tmpFolder, 
			String imgFolder, int idPag, boolean doUpd) throws Exception {
        String page = "[" + (idPag-1) + "]";
		List<String> cmd = ImgUtil.cmdPdfToImg(page, ImgEnum.PNG_COLOR, 125, "", null);
		ImgUtil.execute(cmd, tmpFolder, "file", "pg", false);
    	String srcFile = tmpFolder + "/pg.png";
		String pngFile = imgFolder + "/pg-" + (idPag-1) + ".png";
		Function.copyFile(srcFile, pngFile, true);
		if (doUpd) {
			String update = "update tb_conteudo_img set vl_rotacao = 0 "
					+ "where id_conteudo = ?|tmp.obj.id_conteudo| "
					+ "and id_img_seq = " + idPag;
			dh.executeUpdate(update, wiMap);
		}
	}
	
	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[10];
		in[0] = new JavaParameter("tmp.diario.id_conteudo", "ID do Conte�do");
		in[1] = new JavaParameter("tmp.diario.id_pagina", "ID da P�gina");
		in[2] = new JavaParameter("tmp.diario.tipo", "Tipo A��o");
		in[3] = new JavaParameter("tmp.diario.wtotal", "W Total");
		in[4] = new JavaParameter("tmp.diario.htotal", "H Total");
		in[5] = new JavaParameter("tmp.diario.winicial", "W Inicial");
		in[6] = new JavaParameter("tmp.diario.wfinal", "W Final");
		in[7] = new JavaParameter("tmp.diario.hinicial", "H Inicial");
		in[8] = new JavaParameter("tmp.diario.hfinal", "H Final");
		in[9] = new JavaParameter("tmp.diario.rotacao", "Rota��o Atual");
		return in;
	}

	public JavaParameter[] getOutputParameters() {
		return new JavaParameter[0];
	}
	
}
