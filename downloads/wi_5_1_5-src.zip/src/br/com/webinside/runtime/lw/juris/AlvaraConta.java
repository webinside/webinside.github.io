package br.com.webinside.runtime.lw.juris;

import java.io.File;

import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class AlvaraConta extends AbstractConnector implements InterfaceParameters {

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		String path = wiMap.get("wi.proj.path");
		try {
			String idAlv = wiMap.get("tmp.id_alvara");
			String tipo =  wiMap.get("tmp.tipo").trim().toUpperCase();
			DatabaseHandler dh = databases.get("principal");
			String insert = "insert into tb_rec_doc (fk_receita, fk_tipo_doc, nr_rec_doc, st_anexado, st_removido) values "
					+ "(?|tmp.id_receita|,'PAG_" + tipo + "', 0, 1, 0)";
			int idDoc = dh.executeSqlInsert(insert, wiMap);
			File source = new File(path + "/WEB-INF/storage/alvara/d" + idAlv + ".pdf");
			File dest = new File(path + "/WEB-INF/storage/rec_doc/d" + idDoc + ".pdf");
			Function.copyFile(source.getAbsolutePath(), dest.getAbsolutePath());
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
	
	@Override
	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[3];
		in[0] = new JavaParameter("tmp.id_receita", "ID da Receita");
		in[1] = new JavaParameter("tmp.id_alvara", "ID do Alvara");
		in[2] = new JavaParameter("tmp.tipo", "Tipo: ESC/CLI/CONJ");
		return in;
	}

	@Override
	public JavaParameter[] getOutputParameters() {
		return null;
	}

}
