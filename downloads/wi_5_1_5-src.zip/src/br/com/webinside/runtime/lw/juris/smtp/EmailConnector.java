package br.com.webinside.runtime.lw.juris.smtp;

import java.io.File;

import br.com.webinside.runtime.component.Host;
import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.integration.Producer;
import br.com.webinside.runtime.util.FileIO;
import br.com.webinside.runtime.util.WIMap;

public class EmailConnector extends AbstractConnector implements InterfaceParameters {

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) throws UserException {
		Email bean = new Email();
		String idHost = wiMap.get("tmp.id_smtp_host").trim();
		if (idHost.equals("")) idHost = "smtp";
    	Host host = getParams().getProject().getHosts().getHost(idHost);
		bean.setHost(host.getAddress());
		bean.setPort(host.getPort());
		bean.setUser(host.getUser());
		bean.setPass(host.getPass());
		String tipo = wiMap.get("tmp.tipo_email");
		if (tipo.equals("login")) {
			String nome, email;
			try {
				DatabaseHandler dh = databases.get("principal");
				ResultSet rs = dh.execute("select * from tb_usuario where ts_login = ?|tmp.user|", wiMap);
				rs.next();
				nome = rs.column("ts_nome");
				email = rs.column("ts_email");
			} catch (Exception e) {
				throw new UserException(e);
			}	
			wiMap.put("tmp.email_nome", nome);
			String title = "Login efetuado por |tmp.email_nome| em |wi.date.dmy| �s |wi.date.hms|";
			bean.setTitle(Producer.execute(wiMap, title));
			FileIO body = new FileIO(wiMap.get("wi.proj.path")+"/WEB-INF/email/login.html", 'r');
			bean.setBody(Producer.execute(wiMap, body.readText()));
			boolean local = wiMap.get("wi.server.host").equals("localhost");
			if (local) {
				bean.setTitle("TESTE - " + bean.getTitle());
				bean.setTo("geraldo@lineweb.com.br");
			} else {
				bean.setTo(email.trim().toLowerCase());
				bean.setBcc("alessandro@alessandroguimaraes.adv.br");
			}
			new EmailThread(bean).start();
		} else if (tipo.equals("nota")) {
			String nome, email, comp;
			try {
				String tpnota = wiMap.get("tmp.obj.fk_tipo_doc");
				String sql = "SELECT ts_nome, ts_email, ts_pf_conj_nome, ts_pf_conj_email, DATE_FORMAT(dd_rec_doc, \"%m/%Y\") AS ts_comp "
						+ "FROM tb_rec_doc rd INNER JOIN vw_receita r ON (r.id_receita = rd.fk_receita) "
						+ "WHERE id_rec_doc = |tmp.obj.id_rec_doc|";
				if (tpnota.equals("NOTA_OPOS")) {
					sql = "SELECT ts_nome, ts_email, DATE_FORMAT(dd_rec_doc, \"%m/%Y\") AS ts_comp "
							+ "FROM tb_rec_doc rd INNER JOIN vw_opositor o ON (o.id_opositor = rd.fk_opositor) "
							+ "WHERE id_rec_doc = |tmp.obj.id_rec_doc|";
				}
				DatabaseHandler dh = databases.get("principal");
				ResultSet rs = dh.execute(sql, wiMap);
				rs.next();
				if (tpnota.equals("NOTA_CLI") || tpnota.equals("NOTA_OPOS")) {
					nome = rs.column("ts_nome");
					email = rs.column("ts_email");
					comp = rs.column("ts_comp");
				} else {
					nome = rs.column("ts_pf_conj_nome");
					email = rs.column("ts_pf_conj_email");
					comp = rs.column("ts_comp");
				}
			} catch (Exception e) {
				throw new UserException(e);
			}	
			wiMap.put("tmp.email_nome", nome);
			wiMap.put("tmp.email_comp", comp);
			String title = "Nota fiscal de |tmp.email_nome| da compet�ncia |tmp.email_comp|";
			bean.setTitle(Producer.execute(wiMap, title));
			FileIO body = new FileIO(wiMap.get("wi.proj.path")+"/WEB-INF/email/nota.html", 'r');
			bean.setBody(Producer.execute(wiMap, body.readText()));
			String fname = "d" + wiMap.get("tmp.obj.id_rec_doc") + ".pdf";
			File file = new File(wiMap.get("wi.proj.path")+"/WEB-INF/storage/rec_doc/" + fname);
			bean.getAttachList().add(new EmailAttach("Nota_Fiscal_" + comp + ".pdf", file));
			boolean local = wiMap.get("wi.server.host").equals("localhost");
			if (local) {
				bean.setTitle("TESTE - " + bean.getTitle());
				bean.setTo("geraldo@lineweb.com.br");
				bean.setBcc("alessandro@alessandroguimaraes.adv.br");
			} else {
				bean.setTo(email.trim().toLowerCase());
				bean.setBcc("alessandro@alessandroguimaraes.adv.br");
			}
			new EmailThread(bean).start();
		}
	}

	@Override
	public JavaParameter[] getInputParameters() {
		JavaParameter[] param = new  JavaParameter[2]; 
		param[0] = new JavaParameter("tmp.id_smtp_host", "ID do servidor de email");
		param[1] = new JavaParameter("tmp.tipo_email", "Tipo de Email (login/nota)");
		return param;
	}

	@Override
	public JavaParameter[] getOutputParameters() {
		// TODO Auto-generated method stub
		return null;
	}

}
