package br.com.webinside.runtime.lw.func.diariolw;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.codec.binary.Base64;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfCopy;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfReader;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.ElasticUtil;
import br.com.webinside.runtime.util.WIMap;

public class PesquisaManager extends AbstractConnector implements InterfaceParameters {

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) 
	throws UserException {
		String className = getClass().getName();
		try {
			DatabaseHandler dh = databases.get("diariolw");
			ElasticUtil.INDEX = "/diariolw";
			String type = wiMap.get("tmp.type");
			if (type.equalsIgnoreCase("reindex_OFF")) {
				ElasticUtil.sendHttp(ElasticUtil.DELETE, "", null);
				JSONParser parser = new JSONParser();
				FileReader reader = new FileReader(wiMap.get("wi.proj.path") + "/WEB-INF/elastic/diariolw.json");
				JSONObject jsonInit = (JSONObject) parser.parse(reader);
				reader.close();
				ElasticUtil.sendHttp(ElasticUtil.PUT, "", jsonInit);
				reader = new FileReader(wiMap.get("wi.proj.path") + "/WEB-INF/elastic/attachment.json");
				jsonInit = (JSONObject) parser.parse(reader);
				reader.close();
				ElasticUtil.sendHttp(ElasticUtil.PUT, "attachment", jsonInit);
				String update = "update tb_pdf set ts_status=''";
				dh.executeUpdate(update, wiMap);
				executeSave(wiMap, dh);
			} else if (type.contentEquals("reindex")) {
				executeSaveEdicao(wiMap, dh);
			} else if (type.contentEquals("save")) {
				executeSave(wiMap, dh);
			} else if (type.contentEquals("delete")) {
				String id = wiMap.get("tmp.id_pdf");
				deletePdf(wiMap, id);
			}
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
			wiMap.put("tmp.msg_error", "Falha de acesso ao ElasticSearch");
		}
	}
	
	private void executeSave(WIMap wiMap, DatabaseHandler dh) throws Exception {
		DatabaseHandler dh2 = dh.cloneMe();
		dh2.connect();
		boolean found = false;
		boolean save = wiMap.get("tmp.type").equalsIgnoreCase("save");
		String sql = "select * from tb_pdf";
		if (save) sql += " where id_pdf = ?|tmp.id_pdf|";
		sql += " order by id_pdf";
		ResultSet rs = dh.execute(sql, wiMap);
		while (rs.next() > 0) {
			found = true;
			String id =  rs.column("id_pdf");
			SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		    String strDate = sdfDate.format(new Date());			
			String update = "update tb_pdf set ts_status='START: " + strDate
					+ "' where id_pdf = '" + id + "'";
			dh2.executeUpdate(update, wiMap);
			deletePdf(wiMap, id);
			JSONObject json = new JSONObject();
			json.put("id_pdf", id);
			json.put("nr_pdf", rs.column("nr_pdf"));
			String tp = rs.column("tp_pdf");
			json.put("tp_pdf", tp);
			String tp_ord = "1"; 
			if (tp.equals("E")) tp_ord = "2";
			if (tp.equals("S")) tp_ord = "3";
			json.put("tp_pdf_ord", tp_ord);
			json.put("dd_pdf", rs.column("dd_pdf"));
			int qtd = executePdf(wiMap, json);
			// Atualizando numero de paginas e status
			update = "update tb_pdf set nr_paginas=" + qtd 
						  + ", ts_status='OK' where id_pdf = '" + id  + "'";
			dh2.executeUpdate(update, wiMap);
		}
		if (!save || !found) executeSaveEdicao(wiMap, dh2);
		dh2.close();
	}
	
	private void executeSaveEdicao(WIMap wiMap, DatabaseHandler dh) throws Exception {
		boolean save = wiMap.get("tmp.type").equalsIgnoreCase("save");
		String sql = "select * from tb_edicao where tp_ocr_status = 'S'";
		if (save) sql += " and concat(nr_edicao,tp_edicao) = ?|tmp.id_pdf|";
		sql += " order by nr_edicao, tp_edicao";
		ResultSet rs = dh.execute(sql, wiMap);
		while (rs.next() > 0) {
			String id =  rs.column("nr_edicao") + rs.column("tp_edicao");				
			deletePdf(wiMap, id);
			JSONObject json = new JSONObject();
			json.put("id_pdf", id);
			json.put("nr_pdf", rs.column("nr_edicao"));
			String tp = rs.column("tp_edicao");
			json.put("tp_pdf", tp);
			String tp_ord = "1"; 
			if (tp.equals("E")) tp_ord = "2";
			if (tp.equals("S")) tp_ord = "3";
			json.put("tp_pdf_ord", tp_ord);
			json.put("dd_pdf", rs.column("dd_edicao"));
			executePdf(wiMap, json);
		}		
	}

	private int executePdf(WIMap wiMap, JSONObject jsonParent) throws Exception {
		int qtd = 0;
		String id = (String) jsonParent.get("id_pdf");
		String pdfFile = wiMap.get("pvt.lwpath.priv") + "/diario/pesquisa/" + id + ".pdf";
		if (!new File(pdfFile).isFile()) {
			pdfFile = wiMap.get("pvt.lwpath.priv") + "/diario/concluido/" + id + "-signed.pdf";
		}
		if (!new File(pdfFile).isFile()) {
			pdfFile = wiMap.get("pvt.lwpath.priv") + "/diario/concluido/" + id + ".pdf";
		}
		try {
			PdfReader pdfReader = new PdfReader(pdfFile);
			qtd = pdfReader.getNumberOfPages();
			for (int pg= 1; pg <= qtd; pg++) {
				// extraindo pagina
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				Document document = new Document(pdfReader.getPageSizeWithRotation(pg));
				PdfCopy writer = new PdfCopy(document, baos);
				document.open();
				PdfImportedPage page = writer.getImportedPage(pdfReader, pg);
				writer.addPage(page);
				document.close();
				writer.close();
				// codificando em base64
		        byte[] encoded = Base64.encodeBase64(baos.toByteArray());
		        String strEnc = new String(encoded);
				// transmitindo para o ElasticSearch
				JSONObject json = new JSONObject();
				json.put("id_pdf", jsonParent.get("id_pdf"));
				json.put("id_pdf_page", pg + "");
				json.put("nr_pdf", jsonParent.get("nr_pdf"));
				json.put("tp_pdf", jsonParent.get("tp_pdf"));
				json.put("tp_pdf_ord", jsonParent.get("tp_pdf_ord"));
				json.put("dd_pdf", jsonParent.get("dd_pdf"));
				json.put("ts_pdf_title", jsonParent.get("id_pdf"));
				json.put("base64", strEnc);
				ElasticUtil.sendHttp(ElasticUtil.PUT, "/_doc/" + id + pg, json);
			}
			pdfReader.close();
		} catch (Exception err) {
			String className = getClass().getName();
			getParams().getErrorLog().write(className, "PDF ID: " + id, err);
		}
		return qtd;
	}
	
	private void deletePdf(WIMap wiMap, String id) throws Exception {
        JSONObject rootQuery = new JSONObject();
        JSONObject query = ElasticUtil.jsonObj(rootQuery, "query");
        JSONObject term = ElasticUtil.jsonObj(query, "term");
        term.put("id_pdf", id);
        ElasticUtil.sendHttp(ElasticUtil.POST, "/_delete_by_query", rootQuery);
	}
	
	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[2];
		in[0] = new JavaParameter("tmp.type", "Tipo (reindex/save/delete)");
		in[1] = new JavaParameter("tmp.id_pdf", "Id Pdf");
		return in;
	}

	public JavaParameter[] getOutputParameters() {
		return new JavaParameter[0];
	}
		
}
