package br.com.webinside.runtime.lw.juris;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.webinside.runtime.database.impl.ConnectionSql;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.WIMap;

public class TreeGenerator extends AbstractConnector implements InterfaceParameters {

	private WIMap wiMap = null;

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) 
	throws UserException {
		this.wiMap = wiMap;
		String className = getClass().getName();
		try {
			DatabaseHandler dh = databases.get("principal");
			Connection con = ((ConnectionSql) dh.getDatabaseConnection()).getConnection();
			String resp = recursive(con, "");
			wiMap.put("tmp.tree", resp);
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
	
	private String recursive(Connection con, String codPai) throws Exception {
		StringBuilder resp = new StringBuilder();
		String tipo = wiMap.get("tmp.tipo").toLowerCase().trim();
		String filter = wiMap.get("tmp.filter").toUpperCase().trim();
		String query = "";
		if (tipo.equals("classe")) {
			query = "select cod_classe as cod, nome, qtd_filhos from sgt_consulta.vw_classe where ";
		}
		if (tipo.equals("assunto")) {
			query = "select cod_assunto as cod, nome, qtd_filhos from sgt_consulta.vw_assunto where ";
		}
		if (codPai.equals("")) {
			query += "cod_item_pai is null"; 
		} else {
			query += "cod_item_pai = " + codPai;
		}
		query += " order by nome";
		PreparedStatement ps = con.prepareStatement(query);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			String cod = rs.getString("cod");
			String desc =  cod + " - " + rs.getString("nome").toUpperCase();
			String qtd = rs.getString("qtd_filhos");
			if (qtd.equals("0")) {
				if (filter.equals("") || desc.indexOf(filter) > -1) {
					String hide = (filter.equals("") ? "style='display:none'" : "");
	 				resp.append("<li class='treelink' " + hide + ">\r\n");
					if (!filter.equals("")) desc = desc.replace(filter, "<font class='match'>" + filter + "</font>");
	 				if (tipo.equals("classe")) {
						resp.append("<span onclick='instanciaClasse(this)'><i class='fa fa-file-o'></i> " + desc + "</span>");
	 				} else {
						resp.append("<span><input type='checkbox' value='" + cod + "' class='check'> " + desc + "</span>");
	 				}
					resp.append("</li>\r\n");
				}	
			} else {
				String respChild = recursive(con, cod);
				if (!respChild.equals("") || desc.indexOf(filter) > -1) {
					String hide = (!codPai.equals("") && filter.equals("") ? "style='display:none'" : "");
					StringBuilder aux = new StringBuilder("<li " + hide + ">\r\n");
					if (!filter.equals("")) desc = desc.replace(filter, "<font class='match'>" + filter + "</font>");
	 				if (tipo.equals("classe")) {
	 					aux.append("<span><i class='fa fa-folder-open'></i> " + desc + "</span>\r\n");
	 				} else {
	 					aux.append("<span><i class='fa fa-folder-open'></i> ");
	 					aux.append("<input type='checkbox' value='" + cod + "' class='check'> " + desc + "</span>");
	 				}
					if (!respChild.equals("")) {
						aux.append("<ul>\r\n");
						aux.append(respChild);
						aux.append("</ul>\r\n");
					}					
					aux.append("</li>\r\n");
					resp.append(aux.toString());
				}
			}
		}
		rs.close();
		ps.close();
		return resp.toString();
	}

	@Override
	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[2];
		in[0] = new JavaParameter("tmp.tipo", "Tipo (classe/assunto)");
		in[1] = new JavaParameter("tmp.filter", "Filtro");
		return in;
	}

	@Override
	public JavaParameter[] getOutputParameters() {
		JavaParameter[] out = new JavaParameter[1];
		out[0] = new JavaParameter("tmp.tree", "Html da tree");
		return out;
	}	
	
}
