package br.com.webinside.runtime.lw.eproc;

import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.file.Files;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class ImagemServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	String caminho = null;

	public void init() throws ServletException {
        super.init();
        ServletContext eprocSC = getServletContext().getContext("/eproc");
        if (eprocSC != null) {
            caminho = eprocSC.getInitParameter("localizacao.das.imagens");
        }
        if (caminho == null) {
        	caminho = "/temp";
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    	if (request.getRequestURL().indexOf("http://localhost") != 0) {
            response.sendError(403);
            return;
    	}
        String urlDaImagem = request.getPathInfo();
        if (urlDaImagem == null) {
            response.sendError(404);
            return;
        }
        File imagem = new File(caminho, URLDecoder.decode(urlDaImagem, "UTF-8"));
        if (!imagem.exists()) {
            response.sendError(404);
            return;
        }
        String contentType = getServletContext().getMimeType(imagem.getName());
        if (contentType == null || !contentType.startsWith("image")) {
            response.sendError(404);
            return;
        } else {
            response.reset();
            response.setContentType(contentType);
            response.setHeader("Content-Length", String.valueOf(imagem.length()));
            Files.copy(imagem.toPath(), response.getOutputStream());
            return;
        }
    }

}
