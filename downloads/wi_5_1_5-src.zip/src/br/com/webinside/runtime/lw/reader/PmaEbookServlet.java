package br.com.webinside.runtime.lw.reader;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.WritableByteChannel;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;

import br.com.webinside.runtime.core.MimeType;
import br.com.webinside.runtime.lw.img.ImgEnum;
import br.com.webinside.runtime.lw.img.ImgUtil;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class PmaEbookServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
		
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		String doc = request.getParameter("d");
		WIMap wiMap = new WIMap();
		wiMap.put("wi.proj.path", getServletContext().getRealPath(""));
		File docDir = new File(PmaGenerateXml.generatedDir(wiMap), "/pma" + doc);
		File time = new File(docDir, "/lwreader.time");
		if (doc == null || !time.isFile()) return;
		int siz = Function.parseInt(request.getParameter("s"));
		File sizFolder = new File(docDir, "/img" + siz);
		if (siz < 1 || siz > 3) return;
		int pag = Function.parseInt(request.getParameter("p"));
	    if (pag < 1) return;
	    PmaGenerateXml.PdfNode node = PmaGenerateXml.pdfMap.get(doc);
	    if (new File(node.pdf).lastModified() > node.timestamp) {
	    	FileUtils.deleteDirectory(new File(docDir,"/img1"));
	    	FileUtils.deleteDirectory(new File(docDir,"/img2"));
	    	FileUtils.deleteDirectory(new File(docDir,"/img3"));
	    }
	    File image = image(sizFolder, node.pdf, doc, pag);
	    if (image == null || !image.isFile()) return;
		response.setHeader("Content-length", image.length() + "");
		response.setContentType(MimeType.get("png"));
		response.setDateHeader("Last-Modified", image.lastModified());
		// response.setHeader("Content-Disposition","attachment; filename=\"" +
		// file.getName() + "\"");
		FileChannel inChannel = new FileInputStream(image).getChannel();
		WritableByteChannel outChannel = Channels.newChannel(response.getOutputStream());
		inChannel.transferTo(0, inChannel.size(), outChannel);
		inChannel.close();
		outChannel.close();
	}
	
	private File image(File sizFolder, String pdf, String doc, int pag) {
		File image = new File(sizFolder, "/p" + pag + ".png");
		if (image.isFile()) return image;
		String rndKey = Function.randomKey().toLowerCase();
		String tmpFolder = Function.tmpDir() + "/pdf-" + rndKey;
        String tmpFile = tmpFolder + "/file.pdf";
        Function.copyFile(pdf, tmpFile, true);
        String tamanho = "x150";
        if (sizFolder.getName().endsWith("2")) tamanho = "x900";
        if (sizFolder.getName().endsWith("3")) tamanho = "x1600";
		List<String> cmd = ImgUtil.cmdPdfToImg("[" + (pag-1) + "]" , ImgEnum.PNG_COLOR, tamanho);
		ImgUtil.execute(cmd, tmpFolder, "file", "pg", false);
    	Function.copyFile(tmpFolder + "/pg.png", image.getAbsolutePath(), true);
		Function.removeDir(tmpFolder);
		return image;
	}
			
}
