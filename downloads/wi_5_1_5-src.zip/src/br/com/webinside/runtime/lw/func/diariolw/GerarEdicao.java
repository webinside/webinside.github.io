package br.com.webinside.runtime.lw.func.diariolw;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class GerarEdicao extends AbstractConnector implements InterfaceParameters {
	
	private boolean exit = true;
		
	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			ConteudoPdf contPdf = new ConteudoPdf();
			ResultSet rs = dh.execute("select id_conteudo, ts_cont_key, st_pdf_grande from tb_conteudo "
					+ "where fk_edicao = ?|tmp.obj.id_edicao| and tp_conteudo = 'P' and st_removido = 0", wiMap);
			while (rs.next() > 0) {
				String tmpFolder = Function.rndTmpFolder("pdf");
				boolean trim = (!rs.column(3).equals("1"));
				contPdf.extrairImages(wiMap, tmpFolder, rs.column(1), rs.column(2),trim);
				Function.removeDir(tmpFolder);
			}
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
				
	@Override
	public JavaParameter[] getInputParameters() {
		return null;
	}

	@Override
	public JavaParameter[] getOutputParameters() {
		return null;
	}

	@Override
	public boolean exit() {
		return exit;
	}
	
}
