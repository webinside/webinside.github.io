package br.com.webinside.runtime.lw.juris;

import java.io.ByteArrayOutputStream;
import java.io.FileReader;
import java.sql.ResultSetMetaData;

import org.apache.commons.codec.binary.Base64;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.jsoup.Jsoup;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfCopy;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfReader;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.ElasticUtil;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class JurisprudManager extends AbstractConnector implements InterfaceParameters {

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) 
	throws UserException {
		String className = getClass().getName();
		try {
			DatabaseHandler dh = databases.get("principal");
			ElasticUtil.INDEX = "/jurisprud";
			String type = wiMap.get("tmp.type");
			if (type.equalsIgnoreCase("reindex")) {
				ElasticUtil.sendHttp(ElasticUtil.DELETE, "", null);
				JSONParser parser = new JSONParser();
				FileReader reader = new FileReader(wiMap.get("wi.proj.path") + "/WEB-INF/elastic/jurisprud.json");
				JSONObject jsonInit = (JSONObject) parser.parse(reader);
				reader.close();
				ElasticUtil.sendHttp(ElasticUtil.PUT, "", jsonInit);
				reader = new FileReader(wiMap.get("wi.proj.path") + "/WEB-INF/elastic/attachment.json");
				jsonInit = (JSONObject) parser.parse(reader);
				reader.close();
				ElasticUtil.sendHttp(ElasticUtil.PUT, "attachment", jsonInit);
				executeSave(wiMap, dh);
			} else if (type.contentEquals("save")) {
				executeSave(wiMap, dh);
			} else if (type.contentEquals("delete")) {
				String id = wiMap.get("tmp.id_jurisprud");
				deleteJurisprud(wiMap, id);
			} else if (type.contentEquals("comment")) {
				executeComment(dh, wiMap);
			}
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
			wiMap.put("tmp.msg_error", "Falha de acesso ao ElasticSearch");
		}
	}
	
	private void executeSave(WIMap wiMap, DatabaseHandler dh) throws Exception {
		String sql = "select j.*, "
				+ "c.ts_cat_jrsprd as fk_cat_jrsprd_txt, "
				+ "u.ts_nome as fk_usuario_txt "
				+ "from tb_jurisprud j "
				+ "inner join tb_cat_jrsprd c on (c.id_cat_jrsprd = j.fk_cat_jrsprd) "
				+ "inner join tb_usuario u on (u.id_usuario = j.fk_usuario) ";
		if (wiMap.get("tmp.type").equalsIgnoreCase("save")) {
			sql += "where id_jurisprud = ?|tmp.id_jurisprud| ";
		}
		sql += "order by id_jurisprud";
		ResultSet rs = dh.execute(sql, wiMap);
		while (rs.next() > 0) {
			String id =  rs.column("id_jurisprud");
			deleteJurisprud(wiMap, id);
			JSONObject json = new JSONObject();
			json.put("type", "doc");
			ResultSetMetaData rsmd = rs.getMetaData();
		    int numCols = rsmd.getColumnCount();
		    for (int i = 1; i <= numCols; i++) {
		    	String cname = rsmd.getColumnLabel(i);
		    	String value = rs.column(cname);
		    	if (cname.equals("tx_html")) {
		    		value = Jsoup.parse(value).text();
		    	}
				json.put(cname, value);
		    }
		    String html = rs.column("tx_html");
		    html = html.replace("<p>", "");
		    html = html.replace("</p>", "");
		    html = html.replace("<br />", "");
		    html = html.replace("&nbsp;", "");
		    String vazio = html.trim().equals("") ? "1" : "0";
			json.put("st_vazio", vazio);
			ElasticUtil.sendHttp(ElasticUtil.PUT, "/_doc/" + id, json);
			if (rs.column("st_usa_pdf").equals("1")) {
				int qtd = executePdf(wiMap, json);
				if (!rs.column("nr_pdf_pages").equals(qtd+"")) {
					DatabaseHandler dh2 = dh.cloneMe();
					dh2.connect();
					String update = "update tb_jurisprud set nr_pdf_pages = " + qtd 
								  + " where id_jurisprud = " + id;
					dh2.executeUpdate(update, wiMap);
					dh2.close();
					json = new JSONObject();
					JSONObject doc = ElasticUtil.jsonObj(json, "doc");
					doc.put("nr_pdf_pages", qtd + "");
					ElasticUtil.sendHttp(ElasticUtil.POST, "/_update/" + id, json);
				}
			}
		}
	}

	private int executePdf(WIMap wiMap, JSONObject jsonParent) throws Exception {
		int qtd = 0;
		String id = (String) jsonParent.get("id_jurisprud");
		String pdfFile = wiMap.get("wi.proj.path") + "/WEB-INF/storage/jurisprud/d" + id + ".pdf";
		try {
			PdfReader pdfReader = new PdfReader(pdfFile);
			qtd = pdfReader.getNumberOfPages();
			for (int pg= 1; pg <= qtd; pg++) {
				// extraindo pagina
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				Document document = new Document(pdfReader.getPageSizeWithRotation(pg));
				PdfCopy writer = new PdfCopy(document, baos);
				document.open();
				PdfImportedPage page = writer.getImportedPage(pdfReader, pg);
				writer.addPage(page);
				document.close();
				writer.close();
				// codificando em base64
		        byte[] encoded = Base64.encodeBase64(baos.toByteArray());
		        String strEnc = new String(encoded);
				// transmitindo para o ElasticSearch
				JSONObject json = new JSONObject();
				json.put("type", "pdf");
				json.put("id_jurisprud", jsonParent.get("id_jurisprud"));
				json.put("fk_cat_jrsprd", jsonParent.get("fk_cat_jrsprd"));
				json.put("fk_usuario", jsonParent.get("fk_usuario"));
				json.put("dd_jurisprud", jsonParent.get("dd_jurisprud"));
				json.put("st_importante", jsonParent.get("st_importante"));
				json.put("tx_comentario", jsonParent.get("tx_comentario"));
				json.put("fk_cat_jrsprd_txt", jsonParent.get("fk_cat_jrsprd_txt"));
				json.put("fk_usuario_txt", jsonParent.get("fk_usuario_txt"));
				json.put("id_pdf_page", pg + "");
				json.put("ts_pdf_title", jsonParent.get("ts_jurisprud"));
				json.put("base64", strEnc);
				ElasticUtil.sendHttp(ElasticUtil.PUT, "/_doc/" + id + "-" + pg, json);
			}
			pdfReader.close();
		} catch (Exception err) {
			String className = getClass().getName();
			getParams().getErrorLog().write(className, "PDF ID: " + id, err);
		}
		return qtd;
	}

	private void executeComment(DatabaseHandler dh, WIMap wiMap) throws Exception {
		String txt = "";
		String qtd = ""; 
		String query = "select tx_comentario, nr_pdf_pages from tb_jurisprud where id_jurisprud = ?|tmp.id_jurisprud|";
		ResultSet rs = dh.execute(query, wiMap);
		if (rs.next() > 0) {
			txt = rs.column("tx_comentario");
			qtd = rs.column("nr_pdf_pages");
		}
		if (!txt.trim().equals("")) txt += ", ";
		txt += wiMap.get("tmp.tx_comentario") + " (" + wiMap.get("pvt.login.ts_nome") + ")";
		wiMap.put("tmp.tx_comentario", txt);
		String upd = "update tb_jurisprud set tx_comentario = ?|tmp.tx_comentario| "
				   + "where id_jurisprud = ?|tmp.id_jurisprud|";
		dh.executeUpdate(upd, wiMap);
		String id =  wiMap.get("tmp.id_jurisprud");
		JSONObject json = new JSONObject();
		JSONObject doc = ElasticUtil.jsonObj(json, "doc");
		doc.put("tx_comentario", txt);
		ElasticUtil.sendHttp(ElasticUtil.POST, "/_update/" + id, json);
		for (int i = 1; i <= Function.parseInt(qtd); i++) {
			ElasticUtil.sendHttp(ElasticUtil.POST, "/_update/" + id + "-" + i, json);
		}
		Function.sleep(3000);
	}
	
	private void deleteJurisprud(WIMap wiMap, String id) throws Exception {
        JSONObject rootQuery = new JSONObject();
        JSONObject query = ElasticUtil.jsonObj(rootQuery, "query");
        JSONObject term = ElasticUtil.jsonObj(query, "term");
        term.put("id_jurisprud", id);
        ElasticUtil.sendHttp(ElasticUtil.POST, "/_delete_by_query", rootQuery);
	}
	
	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[3];
		in[0] = new JavaParameter("tmp.type", "Tipo (reindex/save/delete/comment)");
		in[1] = new JavaParameter("tmp.id_jurisprud", "ID Jurisprud");
		in[2] = new JavaParameter("tmp.tx_comment", "Texto do coment�rio");
		return in;
	}

	public JavaParameter[] getOutputParameters() {
		return new JavaParameter[0];
	}
		
}
