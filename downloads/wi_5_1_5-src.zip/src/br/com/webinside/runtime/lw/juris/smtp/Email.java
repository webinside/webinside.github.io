package br.com.webinside.runtime.lw.juris.smtp;

import java.util.ArrayList;
import java.util.List;

public class Email {

	private String host;
	private String port;
	private String user;
	private String pass;
	private String to;
	private String bcc;
	private String title;
	private String body;
	private List<EmailAttach> attachList = new ArrayList<>();
	
	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getBcc() {
		return bcc;
	}

	public void setBcc(String bcc) {
		this.bcc = bcc;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public List<EmailAttach> getAttachList() {
		return attachList;
	}

}
