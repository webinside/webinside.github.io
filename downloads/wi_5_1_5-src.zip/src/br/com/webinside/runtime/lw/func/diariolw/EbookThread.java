package br.com.webinside.runtime.lw.func.diariolw;

import java.io.File;
import java.util.List;

import br.com.webinside.runtime.lw.img.ImgEnum;
import br.com.webinside.runtime.lw.img.ImgUtil;
import br.com.webinside.runtime.util.FileIO;
import br.com.webinside.runtime.util.Function;

public class EbookThread extends Thread {
	
	private File pdfFile = null;
	private String ebookDir = null;
	private String showDir = null;
	
	public EbookThread(File pdf) {
		this.pdfFile = pdf;
		String folder = pdfFile.getParent();
		int pos = folder.indexOf("WEB-INF");
		ebookDir = folder.substring(0,pos) + "publico/aracaju/diario/ebook";
	    String webapps = new File(folder.substring(0,pos)).getParent();
	    showDir = webapps + "/diariolw/ebook/show/js";
	}
	
	@Override
	public void run() {
		Function.removeFiles(ebookDir, "*");
		File destFile = new File(ebookDir, "diario.pdf");
		Function.copyFile(pdfFile.getAbsolutePath(), destFile.getAbsolutePath(), true);
		execute("x1000", "small");
		int pages = destFile.getParentFile().listFiles().length - 1;
		execute("x2000", "large");
		destFile.delete();
		Function.sleep(1000);
		if (new File(ebookDir,"small.jpg").isFile()) {
			new File(ebookDir,"small.jpg").renameTo(new File(ebookDir,"small-0.jpg"));
		}
		if (new File(ebookDir,"large.jpg").isFile()) {
			new File(ebookDir,"large.jpg").renameTo(new File(ebookDir,"large-0.jpg"));
		}
		String text = String.format("var PAGES_QTD = %s;", pages + "");
		FileIO fio = new FileIO(new File(showDir, "pages.js").getAbsolutePath(), 'w');
		fio.writeText(text);
	}
	
	private void execute(String tamanho, String name) {
		List<String> cmd = ImgUtil.cmdPdfToImg("" , ImgEnum.JPG_GRAY, tamanho);
		ImgUtil.execute(cmd, ebookDir, "diario", name, false);
	}
	
}
