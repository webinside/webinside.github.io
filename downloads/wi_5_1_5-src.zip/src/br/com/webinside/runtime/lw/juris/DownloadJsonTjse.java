package br.com.webinside.runtime.lw.juris;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class DownloadJsonTjse extends AbstractConnector {

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) 
	throws UserException {
		String className = getClass().getName();
		try {
			execute(databases.get("principal"), wiMap);
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
	
	private void execute(DatabaseHandler dh, WIMap wiMap) throws Exception {
		JSONArray jsonResp = new JSONArray();
		String sql = "SELECT tx_informacao, ts_magist AS magistrado, ts_adv_dono AS adv_dono, ts_adv_resp AS adv_responsavel, "
				+ "ts_area_juridica AS area_juridica, ts_tipo_contrato AS tipo_contrato, ts_tipo_vinculo AS tipo_vinculo "
				+ "FROM tb_inst_info ii "
				+ "INNER JOIN vw_instancia i ON (i.id_instancia = ii.fk_instancia) "
				+ "INNER JOIN tb_processo p ON (p.id_processo = i.fk_inst_proc) "
				+ "INNER JOIN vw_contrato c ON (c.id_contrato = p.fk_contrato) ";
		ResultSet rs = dh.execute(sql, wiMap);
		while (rs.next() > 0) {
			JSONObject dados = new JSONObject();
			ResultSetMetaData rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 2; i <= cols; i++) {
				String name = rsmd.getColumnLabel(i); 
				dados.put(name, rs.column(name));
			}
		    JSONObject json = (JSONObject) new JSONParser().parse(rs.column(1));
		    JSONArray arr = (JSONArray) json.get("movimentos");
		    while (arr != null && arr.size() > 3) arr.remove(arr.size()-1);
		    json.put("info_contrato", dados);
		    jsonResp.add(json);
		}
        File tmpFolder = new File(Function.rndTmpFolder("tjse_json")); 
        tmpFolder.mkdirs();
        File jsonFile = new File(tmpFolder + "/tjse.json");
        FileUtils.writeStringToFile(jsonFile, jsonResp.toJSONString(), "UTF-8");
        File zipFile = new File(tmpFolder + "/tjse_json.zip");
		FileOutputStream fos = new FileOutputStream(zipFile);
		ZipOutputStream zos = new ZipOutputStream(fos);
		List<String> exclude = new ArrayList();
		exclude.add("tjse_json.zip");
		Function.doZIPFile(tmpFolder.getAbsolutePath(), tmpFolder, zos, exclude);
		zos.close();
		fos.close();
		HttpServletResponse response = getParams().getHttpResponse();
		response.setContentType("application/zip");
		response.setHeader("Content-Disposition", "attachment; filename=" + zipFile.getName());
		response.setContentLength((int) zipFile.length());
		Function.sendFile(zipFile, response.getOutputStream());
		Thread.sleep(1000);
		FileUtils.deleteDirectory(tmpFolder);
	}	

	@Override
	public boolean exit() {
		return true;
	}

}
