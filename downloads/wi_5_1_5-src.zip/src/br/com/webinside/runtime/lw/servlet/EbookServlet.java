package br.com.webinside.runtime.lw.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.WritableByteChannel;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.webinside.runtime.core.ExecuteParams;
import br.com.webinside.runtime.core.MimeType;
import br.com.webinside.runtime.lw.img.ImgEnum;
import br.com.webinside.runtime.lw.img.ImgUtil;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.StringA;
import br.com.webinside.runtime.util.WIMap;

public class EbookServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
        ExecuteParams wiParams = null;
        try {
        	wiParams = ExecuteParams.initInstance(request, response, getServletContext());
            request.setAttribute("wiParams", wiParams);
            super.service(request, response);
        } catch (Exception ex) {
        	if (wiParams != null && wiParams.getErrorLog() != null) {
        		wiParams.getErrorLog().write(getClass().getName(), "Service", ex);
        	}
        } finally {
        	if (wiParams != null) {
        		wiParams.getDatabaseAliases().closeAll();
        	}
        }
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
 		ExecuteParams wiParams = (ExecuteParams) request.getAttribute("wiParams");
 		WIMap wiMap = wiParams.getWIMap();
		if (wiMap.get("pvt.lwpath.priv").equals("")) return;
		File file = new File(wiMap.get("tmp.ebook_img"));
		String ext = StringA.piece(file.getName(), ".", 2);
		if (!file.isFile()) {
			String rndKey = Function.randomKey().toLowerCase();
			String tmpFolder = Function.tmpDir() + "/pdf-" + rndKey;
	        String tmpFile = tmpFolder + "/file.pdf";
	        String pdfFolder = wiMap.get("pvt.lwpath.priv") + "/ged/arquivo";
			String pdfFile = pdfFolder + "/file-" + wiMap.get("tmp.arq") + ".pdf";
	        Function.copyFile(pdfFile, tmpFile, true);
	        String tamanho = "x150";
	        if (wiMap.get("tmp.tam").equals("2")) tamanho = "x900";
	        if (wiMap.get("tmp.tam").equals("3")) tamanho = "x1600";
	 		String pag = wiMap.get("tmp.pag");
			List<String> cmd = ImgUtil.cmdPdfToImg("[" + pag + "]" , ImgEnum.PNG_COLOR, tamanho);
			ImgUtil.execute(cmd, tmpFolder, "file", "pg", false);
        	Function.copyFile(tmpFolder + "/pg.png", file.getAbsolutePath(), true);
			Function.removeDir(tmpFolder);
		}
		response.setHeader("Content-length", file.length() + "");
		response.setContentType(MimeType.get(ext));
		response.setDateHeader("Last-Modified", file.lastModified());
		// response.setHeader("Content-Disposition","attachment; filename=\"" +
		// file.getName() + "\"");
		FileChannel inChannel = new FileInputStream(file).getChannel();
		WritableByteChannel outChannel = Channels.newChannel(wiParams.getOutputStream());
		inChannel.transferTo(0, inChannel.size(), outChannel);
		inChannel.close();
		outChannel.close();
	}
	
	@Override
	protected long getLastModified(HttpServletRequest request) {
 		ExecuteParams wiParams = (ExecuteParams) request.getAttribute("wiParams");
 		WIMap wiMap = wiParams.getWIMap();
 		String pubTmp = wiMap.get("pvt.lwpath.pub-tmp");
 		String doc = "/doc-" + wiMap.get("tmp.doc");
 		String arq = "/images-" + wiMap.get("tmp.arq");
 		String tam = "/img" + wiMap.get("tmp.tam");
 		String pag =  "/pg-" + wiMap.get("tmp.pag") + ".png";
 		File file = new File(pubTmp, "/ged/simplificado" + doc + arq + tam + pag);
		wiMap.put("tmp.ebook_img", file.getAbsolutePath());
		if (file.isFile()) return file.lastModified();
		return -1;
	}

}
