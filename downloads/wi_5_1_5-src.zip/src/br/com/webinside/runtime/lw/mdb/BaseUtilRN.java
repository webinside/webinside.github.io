package br.com.webinside.runtime.lw.mdb;



public class BaseUtilRN {

}
