package br.com.webinside.runtime.lw.func.diariolw;

import java.io.BufferedReader;
import java.io.File;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.util.StringA;
import br.com.webinside.runtime.util.WIMap;

public class ContPosCore {

	private List<ContPosBean> contPosList = new ArrayList<>();
	
	public List<ContPosBean> makeList(DatabaseHandler dh, String idEdicao, File pdf)
	throws Exception {
		String query = "select id_conteudo, fn_tb_hash(ts_cont_key,0) hash"
			+ " from tb_conteudo where st_removido = 0 and fk_edicao = 0" + idEdicao
			+ " order by id_conteudo";
		ResultSet rs = dh.execute(query, new WIMap());
		while (rs.next() > 0 ) {
			String id = rs.column("id_conteudo");
			String hash = rs.column("hash");
			contPosList.add(new ContPosBean(id, hash));
		}
    	if (pdf.isFile()) {
    		PDDocument doc = PDDocument.load(pdf);
    		int pages = doc.getNumberOfPages();
    		for (int i = 1; i <= pages; i++) {
    			PDFTextStripper reader = new PDFTextStripper();
    			reader.setStartPage(i);
    			reader.setEndPage(i);
    			String pageText = reader.getText(doc);
    			BufferedReader rText = new BufferedReader(new StringReader(pageText));
    			String line = null;
    			while ( (line = rText.readLine()) != null ) {
    				String type = "";
    				int from = -1;
    				if ( (from = line.indexOf(HtmlEdicao.chaveMatInicio)) > -1) {
    					type = "I";
    				} else { 
        				if ( (from = line.indexOf(HtmlEdicao.chaveMatAcesso)) > -1) {
        					type = "F";
        				}
    				}
    				if (!type.equals("")) {
    					int pos = line.indexOf(":", from);
    					String aux = line.substring(pos+1, line.length()).trim();
    					String hash = StringA.piece(aux, " ", 1);
    					ContPosBean bean = findByHash(hash);
    					if (bean != null) {
    						if (type.equals("I")) bean.setPgIni(i);
    						if (type.equals("F")) bean.setPgFin(i);
    					}
    				}
    			}
    		}
    		doc.close();
    	}
		return contPosList;
	}

	public List<ContPosBean> getContPosList() {
		return contPosList;
	}

	public ContPosBean findById(String id) {
		for (ContPosBean bean : contPosList) {
			if (bean.getId().equals(id)) {
				return bean;
			}
		}
		return null;
	}

	public ContPosBean findByHash(String hash) {
		for (ContPosBean bean : contPosList) {
			if (bean.getHash().equals(hash)) {
				return bean;
			}
		}
		return null;
	}

}
