package br.com.webinside.runtime.lw.func.diariolw;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.util.ErrorLog;
import br.com.webinside.runtime.util.WIMap;

public class OcrMonitor extends AbstractConnector {
		
	public static final String MSG_S = "SUCESSO - Arquivo pdf substituido pelo com OCR";
	public static final String MSG_E = "ERRO - Falha ao processar arquivo OCR";

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers)
			throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";     
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			ServletContext sc = getParams().getServletContext();
			Map<String, String> map = (Map)sc.getAttribute("ocrMap"); 
			if (map == null) {
				map = new HashMap<>();
				sc.setAttribute("ocrMap", map);
			}
	    	String key = wiMap.get("tmp.obj.hash");
	    	String msg = map.get(key);
	    	if (msg != null) {
		    	wiMap.put("tmp.obj.st_ocr_ajax", "true");
 	    	} else {
	    		String query = "SELECT tp_ocr_status FROM tb_edicao "
						+ " WHERE fn_tb_hash(ts_edi_key, 0) = '" + key + "'";
				ResultSet rs = dh.execute(query, wiMap);
				String status = rs.columnNext(1).trim();
				msg = "Nenhum processamento de OCR foi executado"; 
				if (status.equals("S")) msg = MSG_S;
				if (status.equals("E")) msg = MSG_E;
 	    	}
	    	wiMap.put("tmp.obj.ts_ocr_msg", msg);
 		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			ErrorLog errorLog = getParams().getErrorLog();
			if (errorLog != null) {
				errorLog.write(className, "Page: " + pageId, err);
			}
		}
	}
		
}
