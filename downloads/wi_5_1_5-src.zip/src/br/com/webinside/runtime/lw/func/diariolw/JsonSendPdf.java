package br.com.webinside.runtime.lw.func.diariolw;

import java.io.File;
import java.math.BigInteger;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

import org.json.simple.JSONObject;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.util.WIMap;

public class JsonSendPdf extends AbstractConnector {

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) 
			throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			getParams().getHttpResponse().setContentType("application/json; charset=iso-8859-1");
			String query = "SELECT * FROM tb_edicao e "
					+ "INNER JOIN tb_assinatura a ON (a.id_assinatura = e.fk_assinatura) "
					+ "WHERE st_removido = 0 and ts_chave = ?|tmp.chave|";
			ResultSet rs = dh.execute(query, wiMap);
			rs.next();
			String idEdi = rs.column("id_edicao");
			String idAss = rs.column("id_assinatura");
			if (idAss.trim().equals("")) {
				sendError("Chave n�o encontrada");
				return;
			}
			String dtAss = rs.column("dt_assinatura");
			if (!dtAss.trim().equals("")) {
				sendError("Edi��o j� assinada anteriormente");
				return;
			}
			byte[] pdfBytes = Base64.getDecoder().decode(wiMap.get("tmp.pdf"));
			byte[] sha1 = MessageDigest.getInstance("sha1").digest(pdfBytes);
			if (!new BigInteger(1, sha1).toString(16).equals(wiMap.get("tmp.pdf_sha1"))) {
				sendError("Erro na valida��o do SHA1 do pdf");
				return;
			}
			String path = wiMap.get("pvt.lwpath.priv");
			String keyEdicao = rs.column("nr_edicao") + rs.column("tp_edicao");
			File pdfSigned = new File(path,"/diario/concluido/" + keyEdicao + "-signed.pdf");
			Files.write(pdfSigned.toPath(), pdfBytes);
			wiMap.put("tmp.id_assinatura", idAss);
			Date date = new Date(Long.parseLong(wiMap.get("tmp.date")));
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			wiMap.put("tmp.dt_assinatura", sdf1.format(date));
			String update = "update tb_assinatura "
					+ "set dt_assinatura = ?|tmp.dt_assinatura|, ts_nome = ?|tmp.nome|, ts_cpf = ?|tmp.cpf| "
					+ "where id_assinatura = ?|tmp.id_assinatura|";
			dh.executeUpdate(update, wiMap);
			update = "update tb_edicao set st_publicada = 1 where id_edicao = 0" + idEdi;
			dh.executeUpdate(update, wiMap);
			new EbookThread(pdfSigned).start();
			JSONObject json = new JSONObject();
			json.put("status", "OK");
			getParams().getWriter().println(json.toJSONString());
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}

	private void sendError(String msg) {
		JSONObject json = new JSONObject();
		json.put("status", "ERROR");
		json.put("msg", msg);
		getParams().getWriter().println(json.toJSONString());
	}
	
	@Override
	public boolean exit() {
		return true;
	}	

}
