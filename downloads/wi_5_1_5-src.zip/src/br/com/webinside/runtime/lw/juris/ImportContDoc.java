package br.com.webinside.runtime.lw.juris;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class ImportContDoc extends AbstractConnector implements InterfaceParameters {

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		try {
			Set<String> ignoreSet = new HashSet<String>();
			String path = wiMap.get("wi.proj.path");
			DatabaseHandler dh = databases.get("principal");
			String sql1 = "SELECT fk_doc_obrig FROM tb_cont_doc "
					+ "where st_removido = 0 AND fk_contrato = ?|tmp.id_contrato|";
			ResultSet rs1 = dh.execute(sql1, wiMap);
			while (rs1.next() > 0) {
				ignoreSet.add(rs1.column("fk_doc_obrig"));
			}
			DatabaseHandler dh2 = dh.cloneMe();
			dh2.connect();
			String sql = "SELECT id_cli_doc, fk_doc_obrig FROM tb_cli_doc d "
					+ "WHERE d.st_removido = 0 AND fk_doc_obrig IN (8,9,10,11,13,14) "
					+ "AND fk_cliente = ?|tmp.id_cliente|";
			ResultSet rs = dh.execute(sql, wiMap);
			while (rs.next() > 0) {
				String fkDocObrig = rs.column("fk_doc_obrig");
				if (!ignoreSet.contains(fkDocObrig)) {
					if (wiMap.get("tmp.st_usar_conj").equals("0") && fkDocObrig.equals("9")) continue;
					if (!wiMap.get("tmp.id_area_juridica").equals("1") && fkDocObrig.equals("11")) continue;
					String txt = "CPF/RG (Cliente ou Administrador)";
					if (fkDocObrig.equals("9")) txt = "CPF/RG do C�njuge (Cliente ou Administrador)";
					if (fkDocObrig.equals("10")) txt = "Comprovante de Endere�o";
					if (fkDocObrig.equals("11")) txt = "Carteira de Trabalho";
					if (fkDocObrig.equals("13")) txt = "Contrato Social";
					if (fkDocObrig.equals("14")) txt = "Comprovante de Inscri��o e de Situa��o do CNPJ";
					txt += " (Importado)";
					String insert = "insert into tb_cont_doc (fk_contrato, fk_doc_obrig, dd_cont_doc, ts_grp_doc, ts_cont_doc, st_removido) "
							+ "values (?|tmp.id_contrato|," + fkDocObrig + ",now(),'','" + txt + "', 0)";
					int idDocNew = dh2.executeSqlInsert(insert, wiMap); 
					String idDoc = rs.column("id_cli_doc");
					File source = new File(path + "/WEB-INF/storage/cliente/d" + idDoc + ".pdf");
					File dest = new File(path + "/WEB-INF/storage/documento/d" + idDocNew + ".pdf");
					Function.copyFile(source.getAbsolutePath(), dest.getAbsolutePath());
				}
			}
			dh2.close();
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
	
	@Override
	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[4];
		in[0] = new JavaParameter("tmp.id_contrato", "ID do Contrato");
		in[1] = new JavaParameter("tmp.id_cliente", "ID do Cliente");
		in[2] = new JavaParameter("tmp.id_area_juridica", "ID da Area");
		in[3] = new JavaParameter("tmp.st_usar_conj", "STATUS usar conjuge");
		return in;
	}

	@Override
	public JavaParameter[] getOutputParameters() {
		return null;
	}

}
