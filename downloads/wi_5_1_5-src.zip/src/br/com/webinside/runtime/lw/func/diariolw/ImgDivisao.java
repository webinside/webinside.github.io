package br.com.webinside.runtime.lw.func.diariolw;

import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.util.WIMap;

public class ImgDivisao extends AbstractConnector {
		
	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			String query = "select * from tb_conteudo_img im "
					+ "inner join tb_conteudo co on (co.id_conteudo = im.id_conteudo and id_img_seq = ?|tmp.page|)";
			query += " where ts_cont_key = ?|tmp.key|";
			ResultSet rs = dh.execute(query, wiMap);
			if (rs.next() == 0) return;
			String idCont = rs.column("id_conteudo");
			String pngFolder = wiMap.get("pvt.lwpath.pub") + "/diario/doc-img";
			String imgFolder = pngFolder + "/c" + idCont + "-" + wiMap.get("tmp.key");
			int page = Integer.parseInt(wiMap.get("tmp.page"));
			String pngFile = imgFolder + "/pg-" + (page-1) + ".png";
    		int div = Integer.parseInt(rs.column("nr_divisao"));
			BufferedImage orig = ImageIO.read(new File(pngFile));
			BufferedImage crop = null;
			if (wiMap.get("tmp.pos").equals("1")) {
				crop = orig.getSubimage(0, 0, orig.getWidth(), div);			
			} else {
				crop = orig.getSubimage(0, div, orig.getWidth(), orig.getHeight() - div);			
			}
	    	HttpServletResponse response = getParams().getHttpResponse();
			response.setContentType("image/png");
//			response.setHeader("Content-disposition", "inline; filename=\"diario.png\"");
//			response.setContentLength((int) crop.getData().g.length());
			ImageIO.write(crop, "png", getParams().getOutputStream());			
			orig.flush();
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
		
	@Override
	public boolean exit() {
		return true;
	}
	
}
