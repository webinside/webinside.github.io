/*
 * WEBINSIDE - Ferramenta de produtividade Java
 * Copyright (c) 2011-2012 LINEWEB Solu��es Tecnol�gicas Ltda.
 * Copyright (c) 2009-2010 Inc�gnita Intelig�ncia Digital Ltda.
 *
 * Este programa � software livre; voc� pode redistribu�-lo e/ou modific�-lo 
 * sob os termos da GNU LESSER GENERAL PUBLIC LICENSE (LGPL) conforme publicada 
 * pela Free Software Foundation; vers�o 2.1 da Licen�a.
 * Este programa � distribu�do na expectativa de que seja �til, por�m, SEM 
 * NENHUMA GARANTIA; nem mesmo a garantia impl�cita de COMERCIABILIDADE OU 
 * ADEQUA��O A UMA FINALIDADE ESPEC�FICA.
 * 
 * Consulte a GNU LGPL para mais detalhes.
 * Voc� deve ter recebido uma c�pia da GNU LGPL junto com este programa; se n�o, 
 * veja em http://www.gnu.org/licenses/ 
 */

package br.com.webinside.runtime.lw.func.diariolw;

import java.io.File;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.pdfbox.util.TextPosition;

import br.com.webinside.runtime.core.ExecuteParams;
import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceGrid;
import br.com.webinside.runtime.util.WIMap;

public class CadernoSearch implements InterfaceGrid {

	private int returntype;

    public Map[] execute(WIMap wiMap, DatabaseAliases dbAliases) {
		String className = getClass().getName();
        returntype = HAS_MORE_ROWS;
        int from = 1;
        int limit = 0;
        try {
        	limit = Integer.parseInt(wiMap.get("grid.limit"));
            String next = "grid." + wiMap.get("grid.id") + ".next";
            from = Integer.parseInt(wiMap.get(next));
        } catch (NumberFormatException err) {
        	// ignorado.
        }
        long pos = 50;
        List<Map> completa = new ArrayList();
		try {
			String database = "diariolw";
			DatabaseHandler dh = dbAliases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				ExecuteParams.get().getErrorLog().write(className, "Page: " + pageId, msg);
				return new Map[0];
			}
			String contFolder = wiMap.get("pvt.lwpath.priv") + "/diario/documento";

			String search = wiMap.get("tmp.search").trim();
//			List<String> wordList = Arrays.stream(search.split("\\s+")).collect(Collectors.toList());
	        Pattern pattern = Pattern.compile("\"[^\"]*\"|\\S+");
	        Matcher matcher = pattern.matcher(search);
	        List<String> wordList = new ArrayList<>();
	        while (matcher.find()) {
	        	wordList.add(matcher.group().replace("\"", ""));
	        }
	        
			String query = "SELECT c.id_conteudo, c.ts_cont_key, c.tp_conteudo, c.ts_conteudo, "
					+ "c.nr_edi_ini, c.nr_edi_fin, e.nr_edicao, e.tp_edicao, e.dd_edicao "
					+ "FROM vw_conteudo c INNER JOIN vw_edicao e ON (e.id_edicao = c.fk_edicao) "
					+ "WHERE e.st_publicada = 1 and id_caderno = ?|tmp.id_caderno| "
					+ "and dd_edicao between ?|$df(|tmp.dd_inicial|,fmtymd)$| and ?|$df(|tmp.dd_final|,fmtymd)$| "
					+ "ORDER BY id_edicao, nr_conteudo";
			ResultSet rs = dh.execute(query, wiMap);
			while (rs.next() > 0) {
				String idCont = rs.column("id_conteudo");
				File pdf = new File(contFolder, "doc-" + idCont + ".pdf");
				if (pdf.isFile()) {
					try {
						PDDocument doc = PDDocument.load(pdf);
			            PDFTextStripper stripper = new PDFTextStripper() {
			                @Override
			                protected void processTextPosition(TextPosition text) {
			                    if (text.getDir() == 0) { // 0 indica texto horizontal
			                        super.processTextPosition(text);
			                    }
			                }
			            };			            
			            for (int i = 1; i <= doc.getNumberOfPages(); i++) {
			                stripper.setStartPage(i);
			                stripper.setEndPage(i);
			                String text = stripper.getText(doc).trim();
			                if (text.equals("")) continue; 
			                String text2 = highlight(text, wordList);
			                if (!text2.equals(text) || search.equals("")) {
				                Map aux = new HashMap();
				                aux.put("nr_pdf", rs.column("nr_edicao"));
				                aux.put("tp_pdf", rs.column("tp_edicao"));
				                aux.put("dd_pdf", rs.column("dd_edicao"));
				                aux.put("ts_pdf", rs.column("ts_conteudo"));
				                aux.put("ts_cont_key", rs.column("ts_cont_key"));
				                aux.put("tp_conteudo", rs.column("tp_conteudo"));
				                aux.put("id_pdf_page", i + "");
				                aux.put("nr_edi_ini", rs.column("nr_edi_ini"));
				                aux.put("nr_edi_fin", rs.column("nr_edi_fin"));
				                aux.put("texto", text2);
				                completa.add(aux);
				                pos++;
			                }
			            }
			            doc.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
	        wiMap.put("grid.caderno_search.rowcount", pos + "");
	        if (from + limit > pos) {
	            returntype = NO_MORE_ROWS;
	        }
	        if (limit == 0) returntype = COMPLETE;
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			ExecuteParams.get().getErrorLog().write(className, "Page: " + pageId, err);
			wiMap.put("tmp.msg_error", "Falha ao pesquisar cadernos");
		}
		
        return (Map[])completa.toArray(new Map[0]);
    }

    private String highlight(String texto, List<String> palavras) {
        String textoNormalizado = normalizar(texto);
        for (String palavra : palavras) {
        	if (palavra.trim().equals("")) continue;
            String palavraNormalizada = normalizar(palavra);
            int from = 0;
            StringBuffer sb = new StringBuffer();
            String regex = "\\b" + Pattern.quote(palavraNormalizada) + "\\b";
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(textoNormalizado);
            while (matcher.find()) {
                int inicio = matcher.start();
                int fim = matcher.end();
                sb.append(texto.substring(from,inicio));
                String palavraOriginal = texto.substring(inicio, fim);
                String novoTexto = "<span class='highlight'>" + palavraOriginal + "</span>";
                sb.append(novoTexto);
                from = fim;
            }
            sb.append(texto.substring(from,texto.length()));
            texto = sb.toString();
            textoNormalizado = normalizar(texto);
        }
        return texto;
    }    
    
    private static String normalizar(String texto) {
        return Normalizer.normalize(texto, Normalizer.Form.NFD)
        		.replaceAll("\\p{M}", "").toLowerCase();
    }    
    
    public int returnType() {
    	return returntype;
    }

}
