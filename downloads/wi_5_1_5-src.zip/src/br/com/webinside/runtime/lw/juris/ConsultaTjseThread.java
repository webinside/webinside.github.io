package br.com.webinside.runtime.lw.juris;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.BasicHttpClientConnectionManager;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.twocaptcha.TwoCaptcha;
import com.twocaptcha.captcha.Normal;

import br.com.webinside.runtime.util.WIMap;

public class ConsultaTjseThread extends Thread {
	
	private static boolean DEBUG = false;
	
	private static int RETRIES = 6;
	
	private static final String TWOCAPTCHA_KEY = "8d61648b70358faa281f3be8fc39fcde";
	
	private static String PROXY_HOST = "gate.smartproxy.com:7000";
	private static String PROXY_USER = "legalmanager:Bi0nc3+H01JucuUjvj";

	private static String URL_CAPTCHA = "https://www.tjse.jus.br/ConsultaProcessualService/Captcha.jpg";
	private static String URL_JSON = "https://www.tjse.jus.br/ConsultaProcessualService/service?auth=captcha&metodo=num&tmp_qtde=T";
	
    private CloseableHttpClient httpClient = null;

    private ConsultaTjse parent = null;
    private String twocaptcha_key = null;
    private String numProc = null; 
    private String idInst = null;
	private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    
	public ConsultaTjseThread(ConsultaTjse parent, String twocaptcha_key, 
			String numProc, String idInst) {
		this.parent = parent;
		if (twocaptcha_key == null) twocaptcha_key = TWOCAPTCHA_KEY;
		this.twocaptcha_key = twocaptcha_key;
		if (numProc == null) numProc = "";
		this.numProc = numProc;
		if (idInst == null) idInst = "";
		this.idInst = idInst;
	}
	
	@Override
	public void run() {
		try {
			JSONObject json = consultaCore();
			parent.databaseUpdate(idInst, json);
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			parent.getSemaphore().release();
		}
	}
	
    private JSONObject consultaCore() throws Exception {
    	if (DEBUG) System.out.println("DEBUG - Processo: " + numProc);
    	JSONObject json = null;
    	int cnt = 1;
    	while (json == null && cnt <= RETRIES) {
    		createHttpClient();
    		String method = "loadCaptcha";
        	try {
    	    	String base64 = loadCaptcha();
    	    	method = "solveCaptcha";
    	    	String captcha = solveCaptcha(base64);
    	    	if (captcha != null && !captcha.equals("")) {
    	    		method = "loadJSON";
    	        	String numProcAux = numProc.replaceAll("[^\\d.]", "").trim();
    	        	if (numProcAux.equals("")) numProcAux = "0";
    	    		json = loadJSON(captcha, numProcAux);
    	    	}
    	    	method = "procJSON";
    	    	if (json != null && json.get("msg") != null) {
    	    		if (json.get("msg").equals("erro_consulta")) {
    	    			json.put("msg", "Processo n�o localizado");
    	    		}
    	    		if (json.get("msg").equals("erro_captcha")) json = null;
    	    	}
    	    	if (json != null) {
        	    	if (DEBUG) {
        	    		System.out.println("DEBUG - Json: " + json.toJSONString());
        	    		System.out.println();
        	    	}
        	    	return json;
    	    	}
        	} catch (Exception ex) {
        		System.out.println("ConsultaTjseThread Exception in " + method + " (" + sdf.format(new Date()) + "): "+ ex);
        	}
           	if (cnt < RETRIES) Thread.sleep(ConsultaTjse.RETRY_SLEEP * 1000);
        	cnt++;
    	}
    	closeHttpClient();
    	if (json == null) {
    		System.out.println("ConsultaTjseThread Json NULL after " + RETRIES + " tries (" + sdf.format(new Date()) + "): " + numProc);
    		if (DEBUG) System.out.println();
    	}
    	return json;
    }
        
    private String loadCaptcha() throws Exception {
    	String base64 = "";
        HttpGet httpReq = createHttpGet(URL_CAPTCHA);
		CloseableHttpResponse response = httpClient.execute(httpReq);
	    int status = response.getStatusLine().getStatusCode();
	    if (DEBUG) {
	    	String txt = response.getStatusLine().getReasonPhrase();
	    	System.out.println("DEBUG - Status Load Captcha: " + status + " (" + txt + ")");
	    }
		InputStream in = response.getEntity().getContent();
		byte[] sourceBytes = IOUtils.toByteArray(in);
		base64 = Base64.getEncoder().encodeToString(sourceBytes);
		if (status != 200 || base64.startsWith("PCF")) base64 = "";
		if (DEBUG && !base64.equals("")) {
//			System.out.println("--- START LOAD CAPTCHA RESULT ---");
//			System.out.println(new String(sourceBytes));
//			System.out.println("--- END LOAD CAPTCHA RESULT ---");
			File png = new File("/temp/captcha.png");
			FileUtils.writeByteArrayToFile(png, sourceBytes);
		}		
	    response.close();
	    return base64;
    }    
    
    private String solveCaptcha(String base64) throws Exception {
    	if (base64 == null || base64.trim().equals("")) return null;
    	TwoCaptcha solver = new TwoCaptcha(twocaptcha_key);
    	solver.setDefaultTimeout(30);
    	solver.setPollingInterval(5);
    	Normal captcha = new Normal();
    	captcha.setBase64(base64);
    	captcha.setCode("JurisLW");
        captcha.setCaseSensitive(true);
        captcha.setMinLen(5);
        captcha.setMaxLen(5);
        String code  = "";
        try {
            solver.solve(captcha);
            code = captcha.getCode();
            if (DEBUG) System.out.println("DEBUG - Captcha Solved: " + code);
        } catch (Exception e) {
        	System.err.println("2CAPTCHA Error (" + sdf.format(new Date()) + "): " + e.getMessage());
//        	System.err.println("2CAPTCHA(Base64): " + base64);
        }
        return code;
    }
    
    private JSONObject loadJSON(String captcha, String numProc) throws Exception {
    	String url = URL_JSON + "&token=" + captcha + "&tmp_npro=" + numProc;
		HttpUriRequest httpReq = createHttpGet(url);
		CloseableHttpResponse response = httpClient.execute(httpReq);
	    int status = response.getStatusLine().getStatusCode();
	    if (DEBUG) System.out.println("DEBUG - Status Load Json: " + status);
	    JSONObject respJson = null;
	    if (status == 200) {
			InputStream in = response.getEntity().getContent();
		    Reader reader = new InputStreamReader(in, "UTF-8");
		    String resp = IOUtils.toString(reader).trim();
		    if (!resp.trim().equals("")) {
			    respJson = (JSONObject) new JSONParser().parse(resp);
		    }
	    }
	    response.close();
	    return respJson;
    }
    
    private HttpGet createHttpGet(String url) {
        int timeout = 15 * 1000; // 15 segundos
    	Logger.getLogger("org.apache.http.client.protocol.ResponseProcessCookies").setLevel(Level.OFF);
        RequestConfig.Builder requestConfig = RequestConfig.custom();
        requestConfig.setConnectionRequestTimeout(timeout);
        requestConfig.setConnectTimeout(timeout);
        requestConfig.setSocketTimeout(timeout);
        HttpGet httpGet = new HttpGet(url);
    	httpGet.setConfig(requestConfig.build());
        return httpGet;
    }

	private void closeHttpClient() throws Exception {
		if (httpClient != null) httpClient.close();
		httpClient = null;
	}

	public static JSONObject execute(String twocaptcha_key, String numProc)
	throws Exception {
		return new ConsultaTjseThread(null, twocaptcha_key, numProc, null).consultaCore();
	}

	public static double balance(String twocaptcha_key, WIMap wiMap)
    throws Exception {
   		if (twocaptcha_key == null) twocaptcha_key = TWOCAPTCHA_KEY;    	
    	TwoCaptcha solver = new TwoCaptcha(twocaptcha_key);
    	double balance = solver.balance();
    	String strBalance = Double.toString(balance).replace('.', ',');
    	if (wiMap != null) wiMap.put("tmp.twocaptcha_balance", strBalance);
    	if (DEBUG) System.out.println("DEBUG - Saldo: " + strBalance);
    	return balance;
    }
	
	private void createHttpClient() throws Exception {
		closeHttpClient();
        HttpClientBuilder builder = HttpClients.custom().setConnectionManager(new BasicHttpClientConnectionManager());
		if (PROXY_HOST != null) {
			String host = PROXY_HOST.split(":")[0];
			int port = Integer.parseInt(PROXY_HOST.split(":")[1]);
			HttpHost proxy = new HttpHost(host, port);
            builder.setProxy(proxy);
	    	if (PROXY_USER != null) {
	    		String user = PROXY_USER.split(":")[0];
	    		String pass = PROXY_USER.split(":")[1];
	    		UsernamePasswordCredentials upc = new UsernamePasswordCredentials(user, pass);
	    		CredentialsProvider credProvider = new BasicCredentialsProvider();
		        credProvider.setCredentials(new AuthScope(proxy), upc);
        		builder.setDefaultCredentialsProvider(credProvider);   		
	    	}
	    	if (DEBUG) System.out.println("DEBUG - Proxy " + proxy);
		}
        httpClient = builder.build();
	}
		
	public static void main(String[] args) throws Exception {
    	DEBUG = true;
    	execute(null, "202390201802");
    	execute(null, "202400740757");
    	execute(null, "202410300938");
    	balance(null, null);
    }

}
