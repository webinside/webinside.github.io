package br.com.webinside.runtime.lw.img;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import br.com.webinside.runtime.util.CmdUtil;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.StringA;

import com.itextpdf.text.pdf.PdfReader;

public class ImgUtil {

	public static final int PNG_GRAY = 11;
	public static final int PNG_COLOR = 12;
	public static final int JPG_GRAY = 21;
	public static final int JPG_COLOR = 22;
	
	public static void executeOCR(String folder, String source)
	throws IOException {
        PdfReader pdfReader = new PdfReader(folder + "/" + source + ".pdf");
        int pages = pdfReader.getNumberOfPages();
		pdfReader.close();
		if (pages > 10) pages = 10; // provisorio
		int from = 0;
		List<Thread> threads = OcrThread.execute(folder, "ocr", 4);
		while (from < pages) {
			String mask = "[" + from + "-" + (from + 19) + "]";
			execute(ImgUtil.cmdOcrPdfToPng(mask), folder, source, "ocr", true);
			from = from + 10;
		}
		File single = new File(folder, "ocr.png");
		if (single.isFile()) {
			String name =  "ocr-" + (pages-1) + ".png";
			single.renameTo(new File(folder, name));
		}
		try {
			Function.sleep(500);
			new File(folder, "ocr-end.log").createNewFile();
		} catch (IOException e) { }	
		OcrThread.join(threads);
	}
	
	public static int execute(List<String> cmd, String folder, String source, String target, boolean log) {
		if (target == null) target = source; 
		source = source.split("\\.")[0];
		target = target.split("\\.")[0];
		for (int i = 0; i < cmd.size(); i++) {
			String str = cmd.get(i);
			if (str.indexOf("#{source}") > -1) {
				cmd.set(i, StringA.change(str, "#{source}", source));
			}
			if (str.indexOf("#{target}") > -1) {
				cmd.set(i, StringA.change(str, "#{target}", target));
			}
		}
		new File(folder,target).getParentFile().mkdirs();
		return CmdUtil.execute(folder, cmd, log);
	}
		
	public static List<String> cmdOcrPngToTxt() {
		List<String> cmd = new ArrayList<String>();
		cmd.add(CmdUtil.getTesseractPath());
		cmd.add("#{source}.png");
		cmd.add("#{target}");
		cmd.add("-l");
		cmd.add("por");
		return cmd;
	}
	
	public static List<String> cmdOcrPdfToPng(String pages) {
		List<String> cmd = new ArrayList<String>();
		cmd.add(CmdUtil.getConvertPath());
		cmd.add("-density");
		cmd.add("300");
		cmd.add("-colorspace");
		cmd.add("Gray");
		cmd.add("-depth");
		cmd.add("8");
		cmd.add("-alpha");
		cmd.add("remove");
		if (pages == null) pages = "";
		cmd.add("#{source}.pdf" + pages.trim());
		cmd.add("#{target}.png");
		return cmd;
	}
	
	public static List<String> cmdPdfToImg(String pages, ImgEnum type) {
		return cmdPdfToImg(pages, type, 0, "", null);
	}

	public static List<String> cmdPdfToImg(String pages, ImgEnum type, String resize) {
		return cmdPdfToImg(pages, type, 0, resize, null);
	}
	
	public static List<String> cmdPdfToImg(String pages, ImgEnum type, 
			int density, String resize, TrimType trimType) {
		List<String> cmd = new ArrayList<String>();
		cmd.add(CmdUtil.getConvertPath());
		int width = 0, height = 0;
		resize = (resize == null ? "" : resize.trim());
		if (resize != null && !resize.equals("")) {
			width = Function.parseInt(StringA.piece(resize,"x",1));
			height = Function.parseInt(StringA.piece(resize,"x",2));
		}
		if (density == 0) {
			density = 100;
			if (width > 400 || height > 500) density = 150;
			if (width > 800 || height > 1000) density = 200;
			if (width > 1200 || height > 1500) density = 250;
			if (width > 1600 || height > 2000) density = 300;
		}
		cmd.add("-density");
		cmd.add(density + "");
		cmd.add("-colorspace");
		cmd.add(type.isColor() ? "sRGB" : "Gray");
		cmd.add("-depth");
		cmd.add(type.getDepth() + "");
		cmd.add("-alpha");
		cmd.add("remove"); 
		if (pages == null) pages = "";
		cmd.add("#{source}.pdf" + pages.trim());
		if (type.getExt().equals("png")) {
			cmd.add("-quality");
			cmd.add("95");
			cmd.add("-colors");
			cmd.add("256");
		}
		if (!resize.equals("")) {
			cmd.add("-resize");
			cmd.add(resize);
		}
		if (trimType == TrimType.BORDER10) {
			cmd.add("-fuzz");
			cmd.add("50%");
			cmd.add("-trim");
			cmd.add("-bordercolor");
			cmd.add("White");
			cmd.add("-border");
			cmd.add("10");
		}
		cmd.add("#{target}." + type.getExt()); 
		return cmd;
	}
	
}
