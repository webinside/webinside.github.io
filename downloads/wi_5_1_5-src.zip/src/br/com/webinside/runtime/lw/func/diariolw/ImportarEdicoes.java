package br.com.webinside.runtime.lw.func.diariolw;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.util.ElasticUtil;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.StringA;
import br.com.webinside.runtime.util.WIMap;

public class ImportarEdicoes extends AbstractConnector {
	
	private Map<String, String> cargaMap = new HashMap<String,String>(); 
	private Map<String, File> pdfMap = new LinkedHashMap<String,File>(); 
	private PrintWriter pw = null;
	
	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) 
	throws UserException {
		String className = getClass().getName();
		try {
			DatabaseHandler dh = databases.get("diariolw");
			ElasticUtil.INDEX = "/diariolw";
			pw = getParams().getWriter();
			out("<html><head>");
			out("<title>Importar Pdfs</title>");
			out("<link rel='stylesheet' type='text/css' href='/lwstyle/smartadmin/css/bootstrap.min.css'>");
			out("<link rel='stylesheet' type='text/css' href='/lwstyle/smartadmin/css/font-awesome.min.css'>");
			out("<link rel='stylesheet' type='text/css' href='/lwstyle/css/lineweb.css'>");
			out("<link rel='stylesheet' type='text/css' href='/diariolw/css/import_pdf.css'>");
			out("</head><body>");
			out("<div class='title'>Importador de Pdfs</div>");
			out("<div> --- Para inserir usar: insert=true --- </div>");
			File cargaDir =  new File("/tmp/diariolw-pdfs");
			if (!new File(cargaDir, "carga.csv").isFile()) {
				cargaDir =  new File("/D:/diariolw-pdfs");
			}
			if (!new File(cargaDir, "carga.csv").isFile()) {
				out("<div class='red'>Nenhum arquivo de carga encontrado</div>");
				return;
			}
			out("<div><b>Criando mapa da carga</b></div>");
			FileReader freader = new FileReader(new File(cargaDir, "carga.csv"));
			BufferedReader reader = new BufferedReader(freader) ;
			String line = null;
			while ((line = reader.readLine()) != null) {
				if (line.trim().equals("")) continue;
				String nr = StringA.piece(line, ";", 1);
				String dt = StringA.piece(line, ";", 2);
				String tp = StringA.piece(line, ";", 3);
				if (tp.startsWith("S")) tp = "S";
				if (tp.startsWith("E")) tp = "E";
				cargaMap.put(nr, dt);
			};
			freader.close();
			out("<div><b>Criando mapa dos pdfs</b></div>");
			findPdf(cargaDir);
			out("<div><b>Processando pdfs</b></div>");
			for (Map.Entry<String, File> entry : pdfMap.entrySet()) {
				String key = entry.getKey();
				String data = cargaMap.get(StringA.changeChars(key,"RSE",""));
				if (data == null) {
					String msg = "Data n�o localizada no arquivo de carga: " + key;
					out("<div class='red'>" + msg + " = " + entry.getValue().getName() + "</div>");
				} else {
					wiMap.put("tmp.type", "save");
					wiMap.put("tmp.id_pdf", key);
					wiMap.put("tmp.tp_pdf", key.charAt(key.length()-1)+"");
					wiMap.put("tmp.nr_pdf", key.replace(wiMap.get("tmp.tp_pdf"), ""));
					String dd = StringA.piece(data, "/", 1);
					String mm = StringA.piece(data, "/", 2);
					String yy = StringA.piece(data, "/", 3);
					wiMap.put("tmp.dd_pdf", yy + "-" + mm + "-" + dd);
					String sql = "select id_pdf from tb_pdf where id_pdf = ?|tmp.id_pdf|";
					ResultSet rs = dh.execute(sql, wiMap);
					String found = rs.columnNext(1);
					if (!found.equals("")) {
						out("<div>Ignorando " +  key + " pois j� existe no sistema</div>");
					} else if (wiMap.get("tmp.insert").equals("true")) {
						out("<div class='green'>Processando " +  key + " = " + data + "</div>");
						String insert = "insert into tb_pdf values "
								+ "(?|tmp.id_pdf|,?|tmp.nr_pdf|,?|tmp.tp_pdf|,?|tmp.dd_pdf|,0,'')";
						dh.executeUpdate(insert, wiMap);
						String webapps = wiMap.get("wi.webapps.path");
						String tofile = webapps + "/lwstorage/WEB-INF/privado/aracaju/diario/pesquisa/" + key + ".pdf";
						Function.copyFile(entry.getValue().getAbsolutePath(), tofile, true);
						new PesquisaManager().execute(wiMap, databases, headers);
					}
				}
			}
			out("<div><b>Processamento finalizado</b></div>"); 
			out("</body></html>");
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
			wiMap.put("tmp.msg_error", "Falha de acesso ao ElasticSearch");
		}
	}
	
	private void findPdf(File dir) {
		File[] files = dir.listFiles();
		Arrays.sort(files);
		for (File file : files) {
			if (file.isDirectory() && !file.getName().toLowerCase().endsWith("ignore")) {
				findPdf(file);
			} else if (file.isFile() && file.getName().endsWith(".pdf")) {
				String name = file.getName();
				if (name.startsWith(".")) continue;
				int pos = findPdfKeyPos(name, "_.-[ ");
				String key = "";
				try {
					key = name.substring(0, pos);
				} catch (Exception e) { }
				if (Function.parseInt(key) == 0) {
					int nrPos = name.indexOf("Nr_"); 
					if (nrPos > -1) {
						key = name.substring(nrPos + 3, name.indexOf("_", nrPos + 3));
					}
				}
				if (Function.parseInt(key) == 0) {
					String msg = "Problema na chave do arquivo: " + name;
					out("<div class='red'>" + msg + "</div>");
				} else {
					String found = "";
					String lname = name.toLowerCase();
					if (found.equals("") && lname.indexOf("supl") > -1) found = "S";
					if (found.equals("") && lname.indexOf("extra") > -1) found = "E";
					if (found.equals("") && name.indexOf("(S)") > -1) found = "S";
					if (found.equals("") && name.indexOf("(E)") > -1) found = "E";
					if (found.equals("")) found = "R";
					key += found;
					if (pdfMap.get(key) != null) {
						String msg = "Chave do arquivo duplicada: " + name;
						out("<div class='red'>" + msg + "</div>");
					} else {
						pdfMap.put(key, file);
					}
				}
			}
		}
	}

	private int findPdfKeyPos(String name, String chars) {
		for (int i=0 ; i<name.length() ;i++) {
			if (chars.indexOf(name.charAt(i)) > -1) return i; 
		}
		return -1;
	}
	
	private void out(String text) {
		pw.println(text);
		pw.flush();
	}
	
	@Override
	public boolean exit() {
		return true;
	}	
	
}
