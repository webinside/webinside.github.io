package br.com.webinside.runtime.lw.func.diariolw;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.Producer;
import br.com.webinside.runtime.util.FileIO;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class HtmlEdicao extends AbstractConnector {

	public static String chaveMatInicio = "Chave de in�cio da mat�ria:";
	public static String chaveMatAcesso = "Chave de acesso da mat�ria:";
	
	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) 
			throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			String hpg = wiMap.get("pvt.hide_pdf_grande");
			wiMap.put("tmp.pdf_type", "finalizar");
			makeHtml(getWriter(), dh, wiMap);
			if (hpg.equals("1")) wiMap.put("pvt.hide_pdf_grande", 1);
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
			ShowMessage.addMessage(wiMap, "pdf", "Erro ao gerar PDF");
		}
	}
	
	public void makeHtml(PrintWriter pw, DatabaseHandler dh, WIMap wiMap) 
			throws Exception {
        pw.println("<html>");
        pw.println("<head>");
        pw.println("<style>");
        String projPath = wiMap.get("wi.proj.path");
        File cssFile = new File(projPath, "/WEB-INF/pdf-template/lwdiario.css");
        String css = FileUtils.readFileToString(cssFile, StandardCharsets.ISO_8859_1);
        pw.println(css);
        pw.println(wiMap.get("tmp.obj.tx_comp_css"));
        pw.println(".secretariado p { padding-top: " + wiMap.get("pvt.param.capa_espaco") + "px }");
        pw.println("</style>");
        pw.println("</head>");
		boolean finalizar = wiMap.get("tmp.pdf_type").trim().equalsIgnoreCase("finalizar");
		if (finalizar) wiMap.remove("pvt.hide_pdf_grande");
        pw.println("<body class='" + (!finalizar ? "bg_visual" : "") + "'>");
        File topoFile = new File(projPath, "/WEB-INF/pdf-template/capa-topo.html");
        String topo = FileUtils.readFileToString(topoFile, StandardCharsets.ISO_8859_1);
        topo = Producer.execute(wiMap, topo);
        pw.println(topo);
        String mainCols = "2";
        pw.println("<div class='body'>");
        pw.println("<div class='cols2 init'>");
		pw.println("<div class='doe_capa'>");
		pw.println(wiMap.get("tmp.obj.tx_comp_html"));
		pw.println("</div>");
        String unidTitle = "";
		ResultSet rs = dh.execute("select ct.*, fn_tb_hash(ts_cont_key,0) hash, "
				+ "(select nr_img_cols from tb_conteudo_img im "
				+ "where im.id_conteudo = ct.id_conteudo and id_img_seq = 1) nr_img_cols, "
				+ "(select st_quebra_pag from tb_conteudo_img im "
				+ "where im.id_conteudo = ct.id_conteudo and id_img_seq = 1) st_quebra_pag "
				+ "from vw_conteudo ct "
				+ "where fk_edicao = ?|tmp.obj.id_edicao|", wiMap);
		int total = rs.rowCount();
		int pos = 0;
		while ((pos = rs.next()) > 0) {
			((WIMap)wiMap.getObj("tmp.")).putAll(rs.columns(""));
			String unid = rs.column("ts_unidade");
			String tp = rs.column("tp_conteudo");
			boolean pdfGrande = rs.column("st_pdf_grande").equals("1");
			String auxCols = rs.column("nr_cont_cols");
			if (tp.equals("P")) auxCols = rs.column("nr_img_cols");
			if (pdfGrande) auxCols="1";
			if (!mainCols.equals(auxCols)) {
				pw.println("</div>");
		        pw.println("<div class='cols" + auxCols + "'>");
		        mainCols = auxCols;
			}
			if (!unid.equalsIgnoreCase(unidTitle)) {
				String clazz = "unid";
				if (pdfGrande) {
					clazz += " pagebreak"; 						
					wiMap.put("tmp.st_pdf_grande_topo", "1");
				}
				if (rs.column("st_quebra_pag").equals("1")) {
					pw.println("</div>");
			        pw.println("<div class='cols" + mainCols + " pagebreak'>");
					wiMap.put("tmp.st_quebra_pag_topo", "1");
				}
		        pw.println("<div class='" + clazz + "'>" + unid + "</div>");
		        unidTitle = unid;
			}
			boolean ocultaChave = (total == pos) && wiMap.get("tmp.obj.st_usa_final").equals("1") ;
			if (rs.column("st_oculta_chave").equals("1")) ocultaChave = true;
	        String hash = rs.column("hash");
	        String keyClass = "mat_key";
	        if (tp.equals("D")) {
	        	pw.println(initDiv(wiMap, "mat", pos + "", hash, finalizar));
	        	String conteudo = rs.column("tx_conteudo"); 
	            pw.println(conteudo);
	    		pw.println("</div>");
	    		String sep = wiMap.get("tmp.tp_separador");
	    		if (sep.equals("A") || sep.equals("I")) pw.println("<hr/>");
				Document jdoc = Jsoup.parse(conteudo, "UTF-8");	
				Element eleLast = jdoc.body().children().last();
				if (eleLast != null && eleLast.hasClass("destaque")) {
					keyClass = "mat_key_destaque";
				}
	        } else if (tp.equals("P")) {
	        	String idCont = rs.column("id_conteudo");
	        	int nrPagPdf = Function.parseInt(wiMap.get("tmp.nr_pag_pdf"));
	        	wiMap.put("tmp.id_conteudo", idCont);
	        	DatabaseHandler dh2 = dh.cloneMe();
	        	dh2.connect();
	        	ResultSet rs2 = dh2.execute("select * from tb_conteudo_img "
	        			+ "where id_conteudo = ?|tmp.id_conteudo|", wiMap);
	        	int pos2 = 0;
	        	String initHash = hash;
	        	while ((pos2 = rs2.next()) > 0) {
	        		if (pdfGrande && wiMap.get("pvt.hide_pdf_grande").equals("1")) {
	        			if (pos2 == 2) {
	        				String txt = wiMap.get("tmp.ts_conteudo");
	        				txt += "<br/>(" + (nrPagPdf - 2) + " p�ginas ocultadas)"; 
	        				pw.println("<div class='pdfGrande'>" + txt + "</div>");
	        				continue;
	        			}
	        			if (pos2 > 1 && pos2 < nrPagPdf) continue; 
	        		}
	        		if (rs2.column("nr_tam_perc").equals("0")) continue;
					((WIMap)wiMap.getObj("tmp.")).putAll(rs2.columns(""));
	        		String imgCols = rs2.column("nr_img_cols");
					if (pdfGrande) imgCols="1";
					if (!mainCols.equals(imgCols)) {
						pw.println("</div>");
				        pw.println("<div class='cols" + imgCols + "'>");
				        mainCols = imgCols;
					}
					if (rs2.column("st_quebra_pag").equals("1") 
							&& !wiMap.get("tmp.st_quebra_pag_topo").equals("1")) {
						pw.println("</div>");
				        pw.println("<div class='cols" + imgCols + " pagebreak'>");
					}
					String clazz = "mat_img";
					// if (pdfGrande) clazz += " pagebreak";
		        	pw.println(initDiv(wiMap, clazz, pos + "." + pos2, initHash, finalizar));
		    		imgSplit(pw, wiMap);
		    		initHash = "";
		    		pw.println("</div>");
		    		String sep = wiMap.get("tmp.tp_separador");
		    		if (sep.equals("A") || sep.equals("I")) pw.println("<hr/>");
			        wiMap.remove("tmp.st_pdf_grande_topo");
			        wiMap.remove("tmp.st_quebra_pag_topo");
	        	}
		        dh2.close();
	        }
	        if (ocultaChave) keyClass = "mat_mark";
	        pw.println("<div class='" + keyClass + "'>" + chaveMatAcesso + " " + hash+ "</div>");
			if (keyClass.equals("mat_key_destaque")) pw.println("<div class='mat_key_break'></div>");
		}
        pw.println("</div>");
        pw.println("</div>");
        pw.println("</body>");
        pw.println("</html>");
	}
	
	private String initDiv(WIMap wiMap, String clazz, String id, String hash, boolean finalizar) {
		StringWriter str = new StringWriter();
		PrintWriter pw = new PrintWriter(str);
		boolean pdfGrande = wiMap.get("tmp.st_pdf_grande").equals("1");		
		String style = "";
		int margSup = Integer.parseInt(wiMap.get("tmp.nr_marg_sup"));
		if (clazz.endsWith("mat_img") && !pdfGrande) margSup = margSup - (margSup % 10);
		if (margSup > 0) style += " padding-top:" + margSup + "px;";
		String margInf = wiMap.get("tmp.nr_marg_inf");
		if (!margInf.equals("0")) style += " padding-bottom:" + margInf + "px;";
		String tamPerc = wiMap.get("tmp.nr_tam_perc");
		if (wiMap.get("tmp.st_pdf_grande_topo").equals("1")) {
			if (Function.parseInt(tamPerc) > 94) tamPerc = "94";
		}
		if (!tamPerc.equals("100")) style += " width:" + tamPerc + "%;";
		String sep = wiMap.get("tmp.tp_separador");
		if (sep.equals("A") || sep.equals("S")) pw.println("<hr/>");
		pw.println("<div class='" + clazz + "' style='" + style + "'>");
		if (!hash.equals("")) {
	        String markClass = finalizar ? "mat_mark" : "mat_mark_dev";
        	pw.println("<div class='" + markClass + "'>" + chaveMatInicio + " " + hash + "</div>");
		}
		if (!finalizar) {
			pw.println("<div class='visual_pos'>");
			pw.println("<div class='visual_id'>" + id + "</div>");
			pw.println("</div>");
		}
		return str.toString();
	}

	private void imgSplit(PrintWriter pw, WIMap wiMap) throws Exception {
		String idCont = wiMap.get("tmp.id_conteudo");
		String pngFolder = wiMap.get("pvt.lwpath.pub") + "/diario/doc-img";
		String imgFolder = pngFolder + "/c" + idCont + "-" + wiMap.get("tmp.ts_cont_key");
		int page = Integer.parseInt(wiMap.get("tmp.id_img_seq"));
		int div = Integer.parseInt(wiMap.get("tmp.nr_divisao"));		
		File pngFile = new File(imgFolder + "/pg-" + (page-1) + ".png");
		File pngHtml = new File(imgFolder + "/pg-" + (page-1) + ".html");
		if (pngHtml.lastModified() > pngFile.lastModified()) {
			FileIO fio = new FileIO(pngHtml.getAbsolutePath(), 'r');
			pw.print(fio.readText());
			return;
		}
		String ajaxFile = "c" + idCont + "/pg-" + (page-1);
		ShowMessage.addMessage(wiMap, "pdf", "Gerando Base64 de " + ajaxFile); 
		StringBuilder content = new StringBuilder();
		if (wiMap.get("tmp.st_pdf_grande").equals("1")) { 
			BufferedImage orig = ImageIO.read(pngFile);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ImageIO.write(orig, "png", baos);	
			Base64.Encoder enc = Base64.getEncoder();
			String base64 = enc.encodeToString(baos.toByteArray());	
    		content.append("<img src='data:image/png;base64," + base64 + "'/>\n");
    		orig.flush();
		} else {
			int FRACTION = 10;
			BufferedImage orig = ImageIO.read(pngFile);
			int margSup = Integer.parseInt(wiMap.get("tmp.nr_marg_sup"));
			int grow = (margSup % 10) * 3;
			if (grow > 0) {
			    BufferedImage orig2 = new BufferedImage(orig.getWidth(), orig.getHeight() + grow, orig.getType());
			    Graphics2D g2d = orig2.createGraphics();
			    g2d.setPaint(Color.WHITE);
			    g2d.fillRect(0, 0, orig.getWidth(), grow);		    
			    g2d.drawImage(orig, 0, grow, null);
			    g2d.dispose();
			    orig = orig2;
			}
		    int hTotal = orig.getHeight();
			if (div > hTotal) div = hTotal;
			int hPos = 0;
			while (hTotal > hPos) {
				int hPart = hPos + FRACTION > hTotal ? hTotal - hPos : FRACTION;
				if (div > hPos) hPart = div;
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				BufferedImage crop = orig.getSubimage(0, hPos, orig.getWidth(), hPart);
				ImageIO.write(crop, "png", baos);	
				Base64.Encoder enc = Base64.getEncoder();
				String base64 = enc.encodeToString(baos.toByteArray());	
	    		content.append("<img src='data:image/png;base64," + base64 + "'/>\n");
		        hPos += hPart;
			}
			orig.flush();
		}
		FileIO fio = new FileIO(pngHtml.getAbsolutePath(), 'w');
		fio.writeText(content.toString());
		pw.print(content.toString());
	}
	
}
