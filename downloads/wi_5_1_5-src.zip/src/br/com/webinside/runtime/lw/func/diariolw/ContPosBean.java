package br.com.webinside.runtime.lw.func.diariolw;

public class ContPosBean {

	private String id;
	private String hash;
	private int pgIni = 0;
	private int pgFin = 0;
	
	public ContPosBean(String id, String hash) {
		this.id = id;
		this.hash = hash;
	}

	public String getId() {
		return id;
	}

	public String getHash() {
		return hash;
	}

	public int getPgIni() {
		return pgIni;
	}

	public void setPgIni(int pgIni) {
		this.pgIni = pgIni;
	}

	public int getPgFin() {
		return pgFin;
	}

	public void setPgFin(int pgFin) {
		this.pgFin = pgFin;
	}
	
}
