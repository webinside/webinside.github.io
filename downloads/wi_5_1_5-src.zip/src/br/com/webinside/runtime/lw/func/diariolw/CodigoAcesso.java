package br.com.webinside.runtime.lw.func.diariolw;

import org.json.simple.JSONObject;

import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;
import br.com.webinside.runtime.util.WISession;

public class CodigoAcesso extends AbstractConnector implements InterfaceParameters {

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		try {
			String codeAction = wiMap.get("tmp.code_action");
			String user = wiMap.get("tmp.user").toLowerCase().trim();
			if (user.trim().equals("")) return;
			WISession wiSession = getParams().getWISession();
			if (codeAction.equalsIgnoreCase("create")) {
				String loginCode = (String) wiSession.getAttribute("login_code_" + user);
				if (loginCode == null) {
					loginCode = Function.randomKey(6, false);
					wiSession.setAttribute("login_code_" + user, loginCode);
				}
				wiMap.put("tmp.login_code", loginCode);
				wiMap.put("pvt.login.accept", "true");					
				wiMap.put("wi.pwd.sha1", wiMap.get("tmp.sha1"));
				JSONObject json = new JSONObject();
				json.put("message", "Email enviado contendo o c�digo de acesso");
				getParams().getWriter().print(json.toJSONString());
			} else if (codeAction.equalsIgnoreCase("check")) {
				String regCode = wiMap.get("tmp.code");
				if (regCode.equals("")) regCode = "EMPTY";
				String loginCode = (String) wiSession.getAttribute("login_code_" + user);
				if (loginCode == null) loginCode = "";
				String host = wiMap.get("wi.server.host");
				boolean local = host.equals("localhost") && regCode.equals("lw1234");
				if (loginCode.equalsIgnoreCase(regCode) || local) {
					wiMap.put("tmp.code_ok", "true");
				} else {
					wiMap.put("tmp.msglogin","C�digo de Acesso Inv�lido");
				}
			}
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}

	@Override
	public JavaParameter[] getInputParameters() {
		JavaParameter[] params = new JavaParameter[1];
		params[0] = new JavaParameter("tmp.code_action", "A��o (Create/Check)");
		return params;
	}

	@Override
	public JavaParameter[] getOutputParameters() {
		return null;
	}
}
