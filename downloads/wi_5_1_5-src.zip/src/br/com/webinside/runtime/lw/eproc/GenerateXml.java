package br.com.webinside.runtime.lw.eproc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.function.DateFormat;
import br.com.webinside.runtime.function.HtmlToPdfCore;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.util.CmdUtil;
import br.com.webinside.runtime.util.FileIO;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.StringA;
import br.com.webinside.runtime.util.WIMap;

import com.itextpdf.text.pdf.PdfReader;

public class GenerateXml extends AbstractConnector {

	private static String xmlQuery = null;
	
	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) 
	throws UserException {
		String prjPath = wiMap.get("wi.proj.path");
		if (xmlQuery == null) {
			FileIO fio = new FileIO(prjPath + "/WEB-INF/eproc-query.sql",'R');
			xmlQuery = fio.readText();
		}
		try {
			String docId = wiMap.get("tmp.docid");
			if (Function.parseInt(docId) < 1) return;
			cleanOldGenerated(new File (prjPath, "/WEB-INF/generated"));			
			File docDir = new File (prjPath, "/WEB-INF/generated/d" + docId);
			docDir.mkdirs();
			// Inicializando XML
			Element rootEle = new Element("EprocReader");
			Element docsEle = new Element("docs");
			rootEle.addContent(docsEle);
			Element docEle = new Element("doc");
			docEle.setAttribute("id", "doc-" + docId);
			docsEle.addContent(docEle);
			Element docTitleEle = new Element("title");
			docEle.addContent(docTitleEle);
			Element pages = new Element("pages");
			docEle.addContent(pages);
			// Iteragindo nos elementos
	        Properties anexos = new Properties();
			DatabaseHandler dh = databases.get("eproc");
			ResultSet rs = dh.execute(xmlQuery, wiMap);
			int pos = 0;
			while ((pos = rs.next()) > 0) {
				String id = rs.column("id");
				String pdf = "";
				if (id.startsWith("d-")) {
					String ext = rs.column("extensao");
					if (ext.equals("html") || ext.equals("pdf")) {
						File dest = new File (docDir, "/bin/" + id + ".pdf");
						if (!dest.isFile()) {
							dest.getParentFile().mkdirs();
							if (ext.equals("html")) {
								String url = "http://localhost:8080/lwreader/eproc/";
								String page = url + "pdf.wsp?docid=" + StringA.piece(id, "-", 2);
								File file = HtmlToPdfCore.generatePage(getParams(), page);
								file.renameTo(dest);
							} else {
								FileOutputStream fout = new FileOutputStream(dest);
								rs.columnBin(fout, "conteudo");
								fout.close();
							}
						}
						pdf = dest.getAbsolutePath();
					} else {
						File dest = new File (docDir, "/bin/" + id + "." + ext);
						String destPath = dest.getAbsolutePath();
						int dot = destPath.lastIndexOf(".");
						File genPdf = new File(StringA.mid(destPath, 0, dot-1) + ".pdf");
						if (!genPdf.isFile()) {
							dest.getParentFile().mkdirs();					
							FileOutputStream fout = new FileOutputStream(dest);
							rs.columnBin(fout, "conteudo");
							fout.close();
							CmdUtil.execute(genPdf.getParent(), CmdUtil.cmdConvertFile(dest.getName(),"pdf"));
						}
						pdf = genPdf.getAbsolutePath();
					}
				} else if (id.startsWith("a-")) {
					pdf = rs.column("conteudo");
					if (!new File(pdf).isFile()) continue;
					if (!pdf.toLowerCase().endsWith(".pdf")) {
						int dot = pdf.lastIndexOf(".");
						File genPdf = new File(StringA.mid(pdf, 0, dot-1) + ".pdf");
						if (!genPdf.isFile()) {
							String name = new File(pdf).getName();
							CmdUtil.execute(genPdf.getParent(), CmdUtil.cmdConvertFile(name,"pdf"));
						}
						pdf = genPdf.getAbsolutePath();
					}
					anexos.setProperty(id, pdf);
				}
				String data = rs.column("dt_criacao");
				String args[] = { data, "FMTdmyhms" };
				data = new DateFormat().execute(getParams(), args);
				String tipo = (id.startsWith("d-") ? "Sub-Documento: " : "Anexos: ");
				String titulo = tipo + rs.column("titulo") + " (" + data + ")"; 
				if (pos == 1) {
					String conc = wiMap.get("tmp.documento_dtm_concluido");
					String status = conc.equals("") ? "Em andamento" : "Conclu�do";
					docTitleEle.setText(rs.column("titulo") + " (" + status + ")");
					titulo = "Documento: Inicial (" + data + ")";
				}
		        PdfReader pdfReader = new PdfReader(pdf);
		        int pgN = pdfReader.getNumberOfPages();
		        for (int i = 1; i <= pgN; i++) {
					Element pageEle = new Element("page");
					int pgW = Math.round(pdfReader.getCropBox(i).getWidth());
					int pgH = Math.round(pdfReader.getCropBox(i).getHeight());
					if (i == 1) {
						Element pageTitleEle = new Element("title");
						pageTitleEle.setText(titulo);
						pageEle.addContent(pageTitleEle);
					}
					Element sizeEle = new Element("size");
					sizeEle.setText(pgW + "x" + pgH);
					pageEle.addContent(sizeEle);
					pages.addContent(pageEle);
					for (int s = 1; s <= 3; s++) {
						Element imgEle = new Element("img" + s);
						String params = "d="+ docId + "&e=" + id + "&p=" + i +"&s=" + s;
						imgEle.setText("/lwreader/EprocServlet?" + params);
						pageEle.addContent(imgEle);
					}
				}
				pdfReader.close();
			}
			writeAnexos(docDir, anexos);
			// Gravar o XML
			Document doc = new Document(rootEle);
			XMLOutputter out = new XMLOutputter();
			out.setFormat(defineXmlFormat(out.getFormat()));
			StringWriter sw = new StringWriter();
			out.output(doc, sw);
			wiMap.put("tmp.xml", sw.toString());
			new File(docDir, "lwreader.time").createNewFile();
			new File(docDir, "lwreader.time").setLastModified(new Date().getTime());
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(getClass().getName(), "Page: " + pageId, err);
		}
	}

	private void writeAnexos(File docDir, Properties anexos) {
		try {
			File f = new File (docDir, "/bin/anexos.props");
			f.getParentFile().mkdirs();
			Properties old = new Properties();
			if (f.isFile()) {
				InputStream inOld = new FileInputStream(f);
				old.load(inOld);
				inOld.close();
			}
			if (old.size() == 0 || old.size() != anexos.size()) {
		        OutputStream out = new FileOutputStream(f);
		        anexos.store(out, null);
		        out.close();
			}    
	    }
	    catch (Exception e ) {
	        e.printStackTrace();
	    }			
	}
		
	protected Format defineXmlFormat(Format format) {
		format.setOmitDeclaration(false);
		format.setExpandEmptyElements(false);
		format.setEncoding("ISO-8859-1");
		format.setIndent("    ");
		format.setTextMode(Format.TextMode.TRIM_FULL_WHITE);
		return format;
	}
	
	protected void cleanOldGenerated(File generatedDir) {
		File[] docList = generatedDir.listFiles();
		if (docList == null) return;
		for (File docDir : docList) {
			File timeFile = new File (docDir, "/lwreader.time");
			if (expired(docDir) && expired(timeFile)) {
				try {
					FileUtils.deleteDirectory(docDir);
				} catch (IOException ioe) { }	
			}
		}
		
	}
		
	private boolean expired(File file) {
		if (!file.exists()) return true;
		long now = new Date().getTime();
		if (now - file.lastModified() > 36 * 60 * 60 * 1000) {
			return true;
		}
		return false;
	}
		
}
