package br.com.webinside.runtime.lw.mdb;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import br.com.webinside.runtime.core.MimeType;
import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.StringA;
import br.com.webinside.runtime.util.WIMap;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;
import com.mongodb.gridfs.GridFSInputFile;

public class DemoTJSE extends AbstractConnector implements InterfaceParameters {
	
	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		try {
			DB mdb = BaseUtil.getDB(getParams(), "TJSE");
			String table = wiMap.get("tmp.mongoobj.table");
			GridFS gfs = new GridFS(mdb, table);
			long regId = Function.parseLong(wiMap.get("tmp.mongoobj.id"));
			GridFSDBFile docObj = gfs.findOne(regId + ".pdf");
			if (docObj == null) {
				File mytemp = null;
				DatabaseHandler dh = databases.get("principal");
				String where = " where id_movimento = " + regId;
				ResultSet rs = dh.execute("select bi_movimento from " + table + where, wiMap);
				if (rs.next() > 0) {
			        mytemp = new File(Function.rndTmpFile("dow", "tmp"));
	                FileOutputStream myout = new FileOutputStream(mytemp);
	               	rs.columnBin(myout, 1);
	                myout.close();
	                dh.executeUpdate("update " + table + " set bi_movimento = null " + where, wiMap);
				}
				if (mytemp != null) {
			        Map meta = new HashMap();
					BaseUtil.fileMetadata(meta, mytemp);
			        InputStream fIn = new FileInputStream(mytemp);
					GridFSInputFile mFile = gfs.createFile(fIn, regId + ".pdf");
					mFile.setMetaData(new BasicDBObject(meta));
					mFile.setContentType("pdf");
					mFile.save();		
					fIn.close();
					mytemp.delete();
				}
				docObj = gfs.findOne(regId + ".pdf");
			}
			if (docObj != null) {
				String ext = docObj.getContentType();
	            String mime = MimeType.get(ext);
	            if (mime.equals("")) mime = "application/octet-stream";
	            getParams().setContentType(mime);
	            String dispname = "inline; filename=\""; 
	            String fname = "id-" + regId + "." + ext;
	        	dispname += StringA.getUsAscii(fname) + "\"";
	        	getParams().getHttpResponse().setHeader("Content-disposition", dispname);
	            Function.copyStream(docObj.getInputStream(), getParams().getOutputStream());
            	getParams().getHttpResponse().flushBuffer();
			}
		} catch (Exception err) {
			String msg = "Page: " + wiMap.get("wi.page.id");
			getParams().getErrorLog().write(getClass().getName(), msg, err);
		}
	}
	 		
	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[5];
		in[0] = new JavaParameter("tmp.mongoobj.table", "Mongo Table (Collection)");
		in[1] = new JavaParameter("tmp.mongoobj.id", "Table ID");
		return in;
	}

	public JavaParameter[] getOutputParameters() {
		return new JavaParameter[0];
	}
	
}
