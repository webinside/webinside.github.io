package br.com.webinside.runtime.lw.func.diariolw;
import java.io.File;
import java.util.List;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.WIMap;

public class LocalizaConteudo extends AbstractConnector implements InterfaceParameters {
	
	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			String idEdicao = wiMap.get("tmp.id_edicao");
			if (idEdicao.trim().equalsIgnoreCase("all")) {
				DatabaseHandler dh2 = dh.cloneMe();
				dh2.connect();
				String query = "SELECT id_edicao FROM tb_edicao "
						+ "WHERE st_removido = 0 AND st_publicada = 1";
				ResultSet rs2 = dh2.execute(query, wiMap);
				while (rs2.next() > 0 ) {
					execute(wiMap, dh, rs2.column(1));
				}
				dh2.close();
			} else {
				execute(wiMap, dh, idEdicao);
			}			
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
	
	private void execute(WIMap wiMap, DatabaseHandler dh, String idEdicao)
			throws Exception {
    	String priv = wiMap.get("pvt.lwpath.priv");
		String query = "select nr_edicao, tp_edicao from tb_edicao where id_edicao = 0" + idEdicao;
		ResultSet rs = dh.execute(query, wiMap);
		rs.next();
		String pdf = rs.column("nr_edicao") + rs.column("tp_edicao") + ".pdf";
    	File pdfFile = new File(priv, "/diario/concluido/" + pdf);
    	List<ContPosBean> list = new ContPosCore().makeList(dh, idEdicao, pdfFile);
		for (ContPosBean bean : list) {
			if (bean.getPgIni() > 0 && bean.getPgFin() > 0) {
				String upd = "update tb_conteudo set nr_edi_ini = " + bean.getPgIni() 
						+ " , nr_edi_fin = " + bean.getPgFin()
						+ " where id_conteudo = " + bean.getId();
				dh.executeUpdate(upd, wiMap);
			}
		}
	}
		
	@Override
	public JavaParameter[] getInputParameters() {
		JavaParameter[] params = new JavaParameter[1];
		params[0] = new JavaParameter("tmp.id_edicao", "Id da Edi��o (Todas = ALL)");
		return params;
	}

	@Override
	public JavaParameter[] getOutputParameters() {
		return null;
	}
	
}
