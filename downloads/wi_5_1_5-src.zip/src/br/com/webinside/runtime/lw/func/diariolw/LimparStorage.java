package br.com.webinside.runtime.lw.func.diariolw;

import java.io.File;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class LimparStorage extends AbstractConnector {

	private static long nextRun = 0 ;
	
	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			removerLoteAntigo(dh, wiMap);
			if (nextRun > new Date().getTime()) return;
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, 1);			
			nextRun = cal.getTimeInMillis();
			String hostname = InetAddress.getLocalHost().getHostName().toUpperCase();
			if (hostname.equals("DELL-GMORAES") || hostname.indexOf("LINODE") > -1) {
				removerExcesso(dh, wiMap);			
			}
			limparConteudo(dh, wiMap);			
			limparConteudoLegado(dh, wiMap);
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
	
	private void removerLoteAntigo(DatabaseHandler dh, WIMap wiMap) throws Exception {
		List<String> keyList = new ArrayList();
		String query = "select distinct id_cont_lote from tb_cont_lote "
				+ "where date_add(dt_cont_lote, INTERVAL 2 HOUR) < now()";
		ResultSet rs = dh.execute(query, wiMap);
		while (rs.next() > 0) {
			keyList.add(rs.column("id_cont_lote"));
		}
    	String priv = wiMap.get("pvt.lwpath.priv");
		for (String key : keyList) {
	    	File loteDir = new File(priv, "/diario/lote/" + key);
    		Function.removeDir(loteDir.getAbsolutePath());
    		wiMap.put("tmp.id_cont_lote", key);
    		String delete = "delete from tb_cont_lote where id_cont_lote = ?|tmp.id_cont_lote|";
    		dh.executeUpdate(delete, wiMap);
		}
		new File(priv, "/diario/lote").delete();
	}
	
	private void removerExcesso(DatabaseHandler dh, WIMap wiMap) throws Exception {
		String query1 = "select group_concat(id_publicacao) ids from ("
				+ "select id_publicacao from lwsolution.tb_diario_publicacao p "
				+ "inner join lwsolution.tb_diario_edicao e on (e.id_edicao = p.fk_edicao) "
				+ "where st_removido = 0 order by dt_edicao desc limit 4"
				+ ") t";
		ResultSet rs1 = dh.execute(query1, wiMap);
		String keys1 = rs1.columnNext(1);
		String update1 = "update lwsolution.tb_diario_publicacao "
				+ "set st_removido = 1 where id_publicacao not in (" + keys1 + ")";
		dh.executeUpdate(update1, wiMap);
		String query2 = "select group_concat(id_edicao) ids from ("
				+ "select id_edicao from tb_edicao e "
				+ "where st_removido = 0 order by dd_edicao desc limit 8"
				+ ") t";
		ResultSet rs2 = dh.execute(query2, wiMap);
		String keys2 = rs2.columnNext(1);
		String update2 = "update tb_edicao "
				+ "set st_removido = 1 where id_edicao not in (" + keys2 + ")";
		dh.executeUpdate(update2, wiMap);
	}

	private void limparConteudo(DatabaseHandler dh, WIMap wiMap) throws Exception {
		String query = "select c.id_conteudo, c.ts_cont_key, c.st_removido + e.st_removido, c.tp_extensao "
				+ "from tb_edicao e "
				+ "inner join tb_conteudo c on (c.fk_edicao = e.id_edicao) "
				+ "where c.st_removido = 1 or e.st_removido = 1 or st_publicada = 1 order by id_edicao desc";
		ResultSet rs = dh.execute(query, wiMap);
		while (rs.next() > 0) {
			String pubFolder = wiMap.get("pvt.lwpath.pub") + "/diario/doc-img/";
			String pubKey = "c" + rs.column(1) + "-" + rs.column(2);
			File folder = new File(pubFolder, pubKey);
			if (folder.isDirectory()) {
				FileUtils.deleteDirectory(folder);
			}
			if (!rs.column(3).equals("0")) {
				String privFolder = wiMap.get("pvt.lwpath.priv") + "/diario/documento/";
				String privKey = "doc-" + rs.column(1) + "." + rs.column(4);
				File file = new File(privFolder, privKey);
				if (file.isFile()) file.delete();
			}
		}
	}
	
	private void limparConteudoLegado(DatabaseHandler dh, WIMap wiMap) throws Exception {
		String query = "select c.id_conteudo, c.ts_rnd_key, c.st_removido + p.st_removido "
				+ "from lwsolution.tb_diario_publicacao p "
				+ "inner join lwsolution.tb_diario_conteudo c on (c.fk_publicacao = p.id_publicacao) "
				+ "where c.st_removido = 1 or p.st_removido = 1 or st_autorizado = 1 order by id_publicacao desc";
		ResultSet rs = dh.execute(query, wiMap);
		while (rs.next() > 0) {
			String pubFolder = wiMap.get("pvt.lwpath.pub") + "/diario/imagens/";
			String pubKey = "c" + rs.column(1) + "-" + rs.column(2);
			File folder = new File(pubFolder, pubKey);
			if (folder.isDirectory()) {
				FileUtils.deleteDirectory(folder);
			}
			if (!rs.column(3).equals("0")) {
				String privFolder = wiMap.get("pvt.lwpath.priv") + "/diario/conteudo/";
				String privKey = "file-" + rs.column(1) + ".pdf";
				File file = new File(privFolder, privKey);
				if (file.isFile()) file.delete();
			}
		}
	}

}
