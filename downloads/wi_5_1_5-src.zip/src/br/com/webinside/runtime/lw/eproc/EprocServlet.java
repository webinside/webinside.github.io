package br.com.webinside.runtime.lw.eproc;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.webinside.runtime.core.MimeType;
import br.com.webinside.runtime.lw.img.ImgEnum;
import br.com.webinside.runtime.lw.img.ImgUtil;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.StringA;

public class EprocServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	private static Map<String, AnexosNode> anexosMap = 
			Collections.synchronizedMap(new HashMap()); 
		
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		
		File image = null;
		String man = request.getParameter("man_d");
		if (man == null) {
			String doc = request.getParameter("d");
			String prjPath = getServletContext().getRealPath("");
			File docDir = new File (prjPath, "/WEB-INF/generated/d" + doc);
			File time = new File(docDir, "/lwreader.time");
			if (doc == null || !time.isFile()) return;
			int siz = Function.parseInt(request.getParameter("s"));
			File sizFolder = new File(docDir, "/img" + siz);
			if (siz < 1 || siz > 3) return;
			String type = StringA.piece(request.getParameter("e"), "-", 1);
			if (!type.equals("d") && !type.equals("a")) return;
			int ele = Function.parseInt(StringA.piece(request.getParameter("e"), "-", 2));
			int pag = Function.parseInt(request.getParameter("p"));
		    if (ele < 1 || pag < 1) return;
		    image = image(sizFolder, doc, type, ele, pag);
		} else {
			String prjPath = getServletContext().getRealPath("");
			File docDir = new File (prjPath, "/WEB-INF/generated/man_d" + man);
			File time = new File(docDir, "/lwreader.time");
			if (man == null || !time.isFile()) return;
			int siz = Function.parseInt(request.getParameter("s"));
			File sizFolder = new File(docDir, "/img" + siz);
			if (siz < 1 || siz > 3) return;
			int pag = Function.parseInt(request.getParameter("p"));
		    if (pag < 1) return;
		    image = image(sizFolder, man, "m", 0, pag);
		}
	    if (image == null || !image.isFile()) return;
		response.setHeader("Content-length", image.length() + "");
		response.setContentType(MimeType.get("png"));
		response.setDateHeader("Last-Modified", image.lastModified());
		// response.setHeader("Content-Disposition","attachment; filename=\"" +
		// file.getName() + "\"");
		FileChannel inChannel = new FileInputStream(image).getChannel();
		WritableByteChannel outChannel = Channels.newChannel(response.getOutputStream());
		inChannel.transferTo(0, inChannel.size(), outChannel);
		inChannel.close();
		outChannel.close();
	}
	
	private File image(File sizFolder, String doc, String type, int ele, int pag) {
		File image = new File(sizFolder, "/" + type + ele + "p" + pag + ".png");
		if (type.equals("m")) {
			image = new File(sizFolder, "/p" + pag + ".png");
		}
		if (image.isFile()) return image;
		File pdfFile = null;
		if (type.equals("d")) {
			String name = type + "-" + ele + ".pdf";
			pdfFile = new File(sizFolder.getParentFile(), "/bin/" + name);
		} else if (type.equals("a")) {
			AnexosNode aNode = anexosMap.get("d"+doc);
			File anexosFile = new File(sizFolder.getParentFile(), "/bin/anexos.props");
			if (aNode == null || anexosFile.lastModified() > aNode.timestamp) {
				try {
					Properties props = new Properties();
			    	InputStream is = new FileInputStream(anexosFile);
			        props.load(is);
			        is.close();
			        aNode = new AnexosNode(anexosFile.lastModified(), props);
			        anexosMap.put("d"+doc, aNode);
			    } catch ( Exception e ) { }
			}
			if (aNode != null) {
				String anexo = aNode.props.getProperty(type + "-" + ele);
				if (anexo != null) pdfFile = new File(anexo);
			}
		} else if (type.equals("m")) {
			pdfFile = new File(sizFolder.getParentFile(), "/bin/manual.pdf");
		}
		if (pdfFile == null) return null;
		String rndKey = Function.randomKey().toLowerCase();
		String tmpFolder = Function.tmpDir() + "/pdf-" + rndKey;
        String tmpFile = tmpFolder + "/file.pdf";
        Function.copyFile(pdfFile.getAbsolutePath(), tmpFile, true);
        String tamanho = "x150";
        if (sizFolder.getName().endsWith("2")) tamanho = "x900";
        if (sizFolder.getName().endsWith("3")) tamanho = "x1600";
		List<String> cmd = ImgUtil.cmdPdfToImg("[" + (pag-1) + "]" , ImgEnum.PNG_COLOR, tamanho);
		ImgUtil.execute(cmd, tmpFolder, "file", "pg", false);
    	Function.copyFile(tmpFolder + "/pg.png", image.getAbsolutePath(), true);
		Function.removeDir(tmpFolder);
		return image;
	}
		
	private class AnexosNode {
		
		private long timestamp;
		private Properties props;
		
		private AnexosNode(long timestamp, Properties props) {
			this.timestamp = timestamp;
			this.props = props;
		}
		
	}
	
}
