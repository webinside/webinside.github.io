package br.com.webinside.runtime.lw.juris;

import java.io.File;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.fileupload.FileItem;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.database.impl.ConnectionSql;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.function.database.AbstractConnectorDB;
import br.com.webinside.runtime.function.database.NodeColumn;
import br.com.webinside.runtime.function.database.NodeTable;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.net.FileUpload;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class UploadMultiplo extends AbstractConnectorDB implements InterfaceParameters {

	private WIMap wiMap = null;

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) 
	throws UserException {
		this.wiMap = wiMap;
		String className = getClass().getName();
		try {
			execute(databases.get("principal"));
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
	
	private void execute(DatabaseHandler dh) throws Exception {
		String pref = wiMap.get("tmp.prefix");
		String exts = wiMap.get("tmp.upd_exts");
		String path = wiMap.get("wi.proj.path");
		String storage = wiMap.get("tmp.storage");
        File destdir = new File(path, "WEB-INF/storage/" + storage);
        destdir.mkdirs();
        FileUpload fileUpload = getParams().getFileUpload();
        List<FileItem> itens = fileUpload.getMultFileField("tmp.mult_arq");
        for (FileItem item : itens) {
        	Map<String,String> fnameMap = fileUpload.getItemNameMap(item);
        	String name = fnameMap.get("name");
            String ext = fnameMap.get("ext");
            if (exts.indexOf(ext) > -1) {
            	int id = executeItem(dh, destdir, name, ext);
        		File destfile = new File(destdir, pref + id + "." + ext); 
        		item.write(destfile);
            }
		}        
	}	

	private int executeItem(DatabaseHandler dh, File destdir, String name, String ext) 
	throws Exception {
		String tabela = wiMap.get("tmp.upd_tab");
		String ctit = wiMap.get("tmp.upd_ctit");
		String cext = wiMap.get("tmp.upd_cext");
		String obj = wiMap.get("tmp.upd_obj");
		StringBuilder cols = new StringBuilder();
		StringBuilder vals = new StringBuilder();
		NodeTable nodeTable = getNodeTable(dh, tabela);
		List columns = nodeTable.getColumns();
		for (Iterator it = columns.iterator(); it.hasNext();) {
			NodeColumn column = (NodeColumn) it.next();
			String cname = column.getName();
			if (cname.startsWith("id_")) continue;
			String val = wiMap.get(obj + "." + cname);
			if (val.equals("") && cname.startsWith("st_")) {
				val = "0";
			}
			if (cname.equals(ctit)) {
				wiMap.put(obj + "." + cname, name);
				val = name;
			}
			if (cname.equals(cext)) {
				wiMap.put(obj + "." + cname, ext);
				val = ext;
			}
			if (val.equals("") && column.isNullable()) val = "null";
			if (val.equals("null")) continue;
			if (cols.length() > 0) cols.append(",");
			cols.append(cname);
			if (vals.length() > 0) vals.append(",");
			if (cname.startsWith("st_")) vals.append(val);
			else if (val.trim().equalsIgnoreCase("now")) vals.append("now()");
			else vals.append("?|" + obj + "." + cname + "|");
		}
		String sql = "insert into " + tabela + "(" + cols.toString() + ") values (" + vals + ")";
		ConnectionSql dbSql = (ConnectionSql)dh.getDatabaseConnection();
		dbSql.returnGeneratedKeys();
		dh.executeUpdate(sql, wiMap);
		int id = 0;
		ResultSet rsKey = dbSql.getGeneratedKeys();
		if (rsKey.next() > 0) {
			id = Function.parseInt(rsKey.column(1));
		}
		return id;
	}
	
	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[7];
		in[0] = new JavaParameter("tmp.upd_tab", "Tabela");
		in[1] = new JavaParameter("tmp.upd_ctit", "Coluna do Titulo");
		in[2] = new JavaParameter("tmp.upd_cext", "Coluna da Extens�o");
		in[3] = new JavaParameter("tmp.upd_obj", "Objeto WI");
		in[4] = new JavaParameter("tmp.upd_exts", "Extens�es");
		in[5] = new JavaParameter("tmp.storage", "Storage");
		in[6] = new JavaParameter("tmp.prefix", "Prefixo do Arquivo");
		return in;
	}

	public JavaParameter[] getOutputParameters() {
		return new JavaParameter[0];
	}

}
