package br.com.webinside.runtime.lw.func.diariolw;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;

import com.itextpdf.text.pdf.BarcodeQRCode;
import com.itextpdf.text.pdf.qrcode.EncodeHintType;
import com.itextpdf.text.pdf.qrcode.ErrorCorrectionLevel;

import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.util.WIMap;

public class GerarQRCode extends AbstractConnector {

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) 
			throws UserException {
		String className = getClass().getName();
		try {
			String database = "diariolw";
			DatabaseHandler dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			String sql = "select tx_parametro from tb_parametro where id_parametro = 'URL_QRCODE'";
			String url = dh.execute(sql, wiMap).columnNext(1).trim();
			if (url.endsWith("diariolw")) url += "/portal/edicoes.wsp?key=" + wiMap.get("tmp.key");
		    HttpServletResponse response = getParams().getHttpResponse();
			response.setContentType("image/png");
		    response.setHeader("Content-disposition", "inline; filename='qrcode.png'");
		    Map<EncodeHintType, Object> hints = new HashMap<>();
		    hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
		    hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.Q);		    
		    BarcodeQRCode qrCode = new BarcodeQRCode(url, 100, 100, hints);
		    Image image = qrCode.createAwtImage(Color.BLACK, Color.WHITE);
		    BufferedImage bi = new BufferedImage(100, 100, BufferedImage.TYPE_3BYTE_BGR);
		    Graphics g = bi.getGraphics(); 
	        g.drawImage(image, 0, 0, null);
		    ImageIO.write(bi, "png", getOutputStream());
		} catch (Exception e) {
			throw new UserException(e);
		}
	}	
	 		
	@Override
	public boolean exit() {
		return true;
	}

}
