package br.com.webinside.runtime.lw.img;

public enum TrimType {

	BORDER10
	
}
