package br.com.webinside.runtime.lw.func.diariolw;

import java.util.HashMap;
import java.util.Map;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.WIMap;

public class NavegarConteudo extends AbstractConnector implements InterfaceParameters {

	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			String idConteudo = wiMap.get("tmp.obj.id_conteudo");
			int pos = 0, rowid = 0, last = 0;			
			String query = "select id_conteudo from vw_conteudo ct "
					+ "where fk_edicao = "
					+ "(select fk_edicao from tb_conteudo "
					+ "where id_conteudo = 0" + idConteudo + ") ";
			if (wiMap.get("tmp.nav_filtro").equalsIgnoreCase("pdf")) {
				query += "and tp_conteudo = 'P'";
			}
			Map<Integer,String> map = new HashMap();
			ResultSet rs = dh.execute(query, wiMap);
			while ((pos = rs.next()) > 0) {
				if (idConteudo.equals(rs.column("id_conteudo"))) rowid = pos;
				map.put(pos, rs.column("id_conteudo"));
				last= pos;
			}
			if (rowid > 0) {
				String action = wiMap.get("tmp.action");
				if (action.equals("go_prev") && rowid > 1) rowid--;;
				if (action.equals("go_next") && rowid < last) rowid++;
				if (action.equals("go_prev") || action.equals("go_next")) {
					wiMap.put("tmp.id_pagina", "1");
				}
				wiMap.put("tmp.obj.id_conteudo", map.get(rowid));	
			}
			if (rowid == 0 || rowid == 1) wiMap.put("tmp.nav_prev", "ct_nav_off");
			if (rowid == 0 || rowid == last) wiMap.put("tmp.nav_next", "ct_nav_off");
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}

	@Override
	public JavaParameter[] getInputParameters() {
		JavaParameter[] params = new JavaParameter[1];
		params[0] = new JavaParameter("tmp.nav_filtro", "Filtro Navega��o");
		return params;
	}

	@Override
	public JavaParameter[] getOutputParameters() {
		return null;
	}

}
