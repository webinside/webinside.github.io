package br.com.webinside.runtime.lw.juris.smtp;

import java.util.Date;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class EmailThread extends Thread {

	private Email bean;

	public EmailThread(Email bean) {
		super();
		this.bean = bean;
	}

	@Override
	public void run() {
        try {
	        Properties props = new Properties();
	        props.put("mail.smtp.host", bean.getHost());
	        props.put("mail.smtp.port", bean.getPort());        
	        props.put("mail.smtp.sendpartial", "true"); 
	        props.put("mail.smtp.starttls.enable","true");
	    	props.put("mail.smtp.auth", "true");        
	        Authenticator auth = new SMTPAuthenticator();
	        Session session = Session.getInstance(props, auth);
		   	MimeMessage message = new MimeMessage(session);
		    message.setSubject(bean.getTitle());
		    message.setSentDate(new Date());
		    message.setFrom(new InternetAddress("contato@alessandroguimaraes.adv.br", "Alessandro Guimar�es Advogados"));
		    message.setRecipient(Message.RecipientType.TO, new InternetAddress(bean.getTo()));
		    if (bean.getBcc() != null) {
			    message.setRecipient(Message.RecipientType.BCC, new InternetAddress(bean.getBcc()));
		    }
		    Multipart multipart = new MimeMultipart("related");
		    message.setContent(multipart);
	        MimeBodyPart mbp = new MimeBodyPart();
	       	mbp.setContent(bean.getBody(), "text/html");
	       	multipart.addBodyPart(mbp);
	       	for (EmailAttach att : bean.getAttachList()) {
	            multipart.addBodyPart(att.getMimeBodyPart());
			}
        	Transport.send(message);
        } catch (Exception ex) {
        	ex.printStackTrace();
        }
	}
	
   class SMTPAuthenticator extends Authenticator {
		public PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(bean.getUser().trim(), bean.getPass().trim());
		}
    }
	
}
