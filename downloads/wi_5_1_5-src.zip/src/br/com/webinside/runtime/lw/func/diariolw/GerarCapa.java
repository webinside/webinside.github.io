package br.com.webinside.runtime.lw.func.diariolw;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.FileUtils;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.Producer;
import br.com.webinside.runtime.util.WIMap;

public class GerarCapa extends AbstractConnector {
		
	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		try {
			String database = "diariolw";
			DatabaseHandler dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			wiMap.put("tmp.prefeito", wiMap.get("pvt.param.prefeito"));
			String desigPref = wiMap.get("pvt.param.designar_prefeito").toUpperCase();
			wiMap.put("tmp.desig_prefeito", desigPref);
			String vice = wiMap.get("pvt.param.vice-prefeito");
			if (!vice.trim().equals("")) {
				StringWriter sw = new StringWriter(); 
				PrintWriter pw = new PrintWriter(sw);
				pw.println("<tr>");
				pw.println("<td style='background-color:#a6a6a6'>");
				String desigVice = wiMap.get("pvt.param.designar_vice-prefeito").toUpperCase();
				pw.println("<p style='text-align:center'>" + desigVice + "<br /><strong>");
				pw.print(vice);
				pw.println("</strong></p>");
				pw.println("</td>");
				pw.println("</tr>");
				wiMap.put("tmp.bloco_vice_prefeito", sw.toString());
			}
			String respSegov = ""; 
			StringBuffer resp = new StringBuffer();
			ResultSet rs = dh.execute("SELECT * FROM tb_unidade "
					+ "WHERE st_removido = 0 and st_ativo = 1 "
					+ "ORDER BY nr_ordem", wiMap);
			while (rs.next() > 0) {
				if (rs.column("ts_sigla").toUpperCase().equals("SEGOV")) {
					respSegov = rs.column("ts_responsavel");
				}
				String cargo = rs.column("ts_doe_comp");
				if (cargo.trim().equals("")) cargo = rs.column("ts_unidade");
				if (rs.column("st_usar_capa").equals("0")) continue;
				resp.append("<p style='text-align:center'><strong>" + cargo + "</strong><br/>");
				resp.append(rs.column("ts_responsavel") + "</p>\n");
			}
			wiMap.put("tmp.lista_secretario", resp.toString());
			wiMap.put("tmp.resp_segov", respSegov);
			wiMap.put("tmp.resp1_nome", wiMap.get("pvt.param.resp1_nome"));
			wiMap.put("tmp.resp1_cargo", wiMap.get("pvt.param.resp1_cargo"));
			wiMap.put("tmp.resp2_nome", wiMap.get("pvt.param.resp2_nome"));
			wiMap.put("tmp.resp2_cargo", wiMap.get("pvt.param.resp2_cargo"));
			wiMap.put("tmp.endereco", wiMap.get("pvt.param.endereco"));
			wiMap.put("tmp.url_site", wiMap.get("pvt.param.url_site"));
	        String projPath = wiMap.get("wi.proj.path");
	        File capaFile = new File(projPath, "/WEB-INF/modelos/capa_gerar.html");
	        String capa = FileUtils.readFileToString(capaFile, StandardCharsets.ISO_8859_1);
	        capa = Producer.execute(wiMap, capa);
			wiMap.put("tmp.obj.tx_comp_html", capa);
			wiMap.put("tmp.obj.tx_comp_css", "");
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
			
}
