package br.com.webinside.runtime.lw.juris;

import java.util.Map;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import org.docx4j.openpackaging.parts.StAXHandlerAbstract;

public class Docx4jStAXHandler extends StAXHandlerAbstract {

	private Map<String, String> mappings = null;

	public Docx4jStAXHandler(Map<String, String> mappings) {
		this.mappings = mappings;
	}

	public void handleCharacters(XMLStreamReader xmlr, XMLStreamWriter writer) throws XMLStreamException {
		StringBuilder sb = new StringBuilder();
		sb.append(xmlr.getTextCharacters(), xmlr.getTextStart(), xmlr.getTextLength());
		String wmlString = replace(sb.toString(), 0, new StringBuilder(), mappings).toString();
		char[] charOut = wmlString.toCharArray();
		writer.writeCharacters(charOut, 0, charOut.length);
	}

	private StringBuilder replace(String wmlTemplateString, int offset, StringBuilder strB, Map<String, ?> mappings) {
		int startKey = wmlTemplateString.indexOf("${", offset);
		if (startKey == -1)
			return strB.append(wmlTemplateString.substring(offset));
		else {
			strB.append(wmlTemplateString.substring(offset, startKey));
			int keyEnd = wmlTemplateString.indexOf('}', startKey);
			if (keyEnd > 0) {
				String key = wmlTemplateString.substring(startKey + 2, keyEnd);
				Object val = mappings.get(key);
				if (val == null) {
					System.out.println("Invalid key '" + key + "' or key not mapped to a value");
					strB.append(key);
				} else {
					strB.append(val.toString());
				}
				return replace(wmlTemplateString, keyEnd + 1, strB, mappings);
			} else {
				System.out.println("Invalid key: could not find '}' ");
				strB.append("$");
				return replace(wmlTemplateString, offset + 1, strB, mappings);
			}
		}
	}

}
