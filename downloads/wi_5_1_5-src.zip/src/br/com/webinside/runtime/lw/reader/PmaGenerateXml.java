package br.com.webinside.runtime.lw.reader;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.util.StringA;
import br.com.webinside.runtime.util.WIMap;

import com.itextpdf.text.pdf.PdfReader;

public class PmaGenerateXml extends AbstractConnector {

	public static Map<String,PdfNode> pdfMap = 
			Collections.synchronizedMap(new HashMap<String,PdfNode>());
	
	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) 
	throws UserException {
		try {
			String docId = wiMap.get("tmp.docid");
			cleanOldGenerated(generatedDir(wiMap));			
			if (!hasDocId(wiMap)) return;
			File docDir = new File (generatedDir(wiMap), "/pma" + docId);
			docDir.mkdirs();
			// Inicializando XML
			Element rootEle = new Element("LWReader");
			Element docsEle = new Element("docs");
			rootEle.addContent(docsEle);
			Element docEle = new Element("doc");
			docEle.setAttribute("id", "doc-" + docId);
			docsEle.addContent(docEle);
			Element docTitleEle = new Element("title");
			docEle.addContent(docTitleEle);
			Element pages = new Element("pages");
			docEle.addContent(pages);
			// Processando PDF
			String pdf = pdfMap.get(docId + "").pdf;
			String titulo = "Di�rio Oficial do Munic�pio - N� "; 
			if (docId.toLowerCase().endsWith("e")) {
				titulo += StringA.mid(docId, 0, docId.length() - 2) + " (Extra)";
			} else {
				titulo += docId;
			}
			docTitleEle.setText(titulo);
	        PdfReader pdfReader = new PdfReader(pdf);
	        int pgN = pdfReader.getNumberOfPages();
	        for (int i = 1; i <= pgN; i++) {
				Element pageEle = new Element("page");
				int pgW = Math.round(pdfReader.getCropBox(i).getWidth());
				int pgH = Math.round(pdfReader.getCropBox(i).getHeight());
				Element sizeEle = new Element("size");
				sizeEle.setText(pgW + "x" + pgH);
				pageEle.addContent(sizeEle);
				pages.addContent(pageEle);
				for (int s = 1; s <= 3; s++) {
					Element imgEle = new Element("img" + s);
					String params = "d="+ docId + "&p=" + i +"&s=" + s;
					imgEle.setText("/lwreader/PmaEbookServlet?" + params);
					pageEle.addContent(imgEle);
				}
			}
			pdfReader.close();
			// Gravar o XML
			Document doc = new Document(rootEle);
			XMLOutputter out = new XMLOutputter();
			out.setFormat(defineXmlFormat(out.getFormat()));
			StringWriter sw = new StringWriter();
			out.output(doc, sw);
			wiMap.put("tmp.xml", sw.toString());
			new File(docDir, "lwreader.time").createNewFile();
			new File(docDir, "lwreader.time").setLastModified(new Date().getTime());
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(getClass().getName(), "Page: " + pageId, err);
		}
	}
			
	private Format defineXmlFormat(Format format) {
		format.setOmitDeclaration(false);
		format.setExpandEmptyElements(false);
		format.setEncoding("ISO-8859-1");
		format.setIndent("    ");
		format.setTextMode(Format.TextMode.TRIM_FULL_WHITE);
		return format;
	}
	
	private void cleanOldGenerated(File generatedDir) {
		File[] docList = generatedDir.listFiles();
		if (docList == null) return;
		for (File docDir : docList) {
			File timeFile = new File (docDir, "/lwreader.time");
			if (expired(docDir) && expired(timeFile)) {
				try {
					FileUtils.deleteDirectory(docDir);
				} catch (IOException ioe) { }	
			}
		}
		
	}
	
	private boolean expired(File file) {
		if (!file.exists()) return true;
		long now = new Date().getTime();
		if (now - file.lastModified() > 36 * 60 * 60 * 1000) {
			return true;
		}
		return false;
	}
	
	public static File generatedDir(WIMap wiMap) {
		String genDir = wiMap.get("pvt.pma_folder_generated").trim();
		if (genDir.equals("")) {
			String prjPath = wiMap.get("wi.proj.path").trim();
			return new File(prjPath, "/WEB-INF/generated/");
		}
		return new File(genDir);
	}

	public static boolean hasDocId(WIMap wiMap) {
		String docId = wiMap.get("tmp.docid");
		if (pdfMap.containsKey(docId)) return true;
		String dir = wiMap.get("pvt.pma_folder_diarios");
		readPdfMap(new File(dir));
		PdfNode node = pdfMap.get(docId);
		return (node != null && new File(node.pdf).isFile());
	}

	private static void readPdfMap(File dir) {
		if (dir == null || dir.listFiles() == null) return;
		for (File file : dir.listFiles()) {
			if (file.isDirectory()) {
				readPdfMap(file);
			} else if (file.getName().endsWith(".pdf")) {
				String id = StringA.piece(file.getName(), ".", 1).trim();
				pdfMap.put(id, (new PmaGenerateXml()).new PdfNode(file));
			}
		}
	}
	
	public class PdfNode {
		
		public String pdf;
		public long timestamp;
		
		private PdfNode(File pdf) {
			this.pdf = pdf.getAbsolutePath();
			this.timestamp = pdf.lastModified();
		}
		
	}
	
}
