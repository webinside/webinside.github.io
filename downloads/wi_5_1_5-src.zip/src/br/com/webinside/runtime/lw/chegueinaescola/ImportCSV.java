/*
 * WEBINSIDE - Ferramenta de produtividade Java
 * Copyright (c) 2011-2012 LINEWEB Solu��es Tecnol�gicas Ltda.
 * Copyright (c) 2009-2010 Inc�gnita Intelig�ncia Digital Ltda.
 *
 * Este programa � software livre; voc� pode redistribu�-lo e/ou modific�-lo 
 * sob os termos da GNU LESSER GENERAL PUBLIC LICENSE (LGPL) conforme publicada 
 * pela Free Software Foundation; vers�o 2.1 da Licen�a.
 * Este programa � distribu�do na expectativa de que seja �til, por�m, SEM 
 * NENHUMA GARANTIA; nem mesmo a garantia impl�cita de COMERCIABILIDADE OU 
 * ADEQUA��O A UMA FINALIDADE ESPEC�FICA.
 * 
 * Consulte a GNU LGPL para mais detalhes.
 * Voc� deve ter recebido uma c�pia da GNU LGPL junto com este programa; se n�o, 
 * veja em http://www.gnu.org/licenses/ 
 */

package br.com.webinside.runtime.lw.chegueinaescola;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import javax.imageio.ImageIO;

import org.apache.commons.codec.binary.Base64;
import org.bouncycastle.crypto.digests.SHA256Digest;
import org.bouncycastle.crypto.generators.PKCS5S2ParametersGenerator;
import org.bouncycastle.crypto.params.KeyParameter;
import org.imgscalr.Scalr;
import org.imgscalr.Scalr.Rotation;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.database.impl.ConnectionSql;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.StringA;
import br.com.webinside.runtime.util.WIMap;

public class ImportCSV extends AbstractConnector implements InterfaceParameters {

	private static final int ID_INSTITUICAO_PROD = 3;
	
	// Turma, Matricula, Aluno 
	// CPF, Nome, Email, Celular, Fixo
	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "principal";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			loadCSV(dh, wiMap);
		} catch (Exception err) {
			err.printStackTrace();
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
	
	private void loadCSV(DatabaseHandler dh, WIMap wiMap) throws Exception {
		String str = getIdInstituicaoSTR(ID_INSTITUICAO_PROD);
		File file = new File(wiMap.get("wi.proj.path")+"/WEB-INF/importar/lista-" + str + ".csv");
		BufferedReader br = new BufferedReader(new FileReader(file));
		String line = "";
		int count = 0;
		while ((line = br.readLine()) != null) {
			if (line.trim().equals("") || line.trim().startsWith("#")) continue;
			count++;
			wiMap.put("tmp.obj.id_inst", ID_INSTITUICAO_PROD + "");
			String turma = StringA.piece(line, ";", 1).trim();
			wiMap.put("tmp.obj.turma", turma);
			String mat = StringA.piece(line, ";", 2).trim();
			wiMap.put("tmp.obj.mat", mat);
			String aluno = StringA.piece(line, ";", 3).trim();
			wiMap.put("tmp.obj.aluno", aluno);
			System.out.println(count + " = " + turma + " - " + mat + " - " + aluno);
			int pos = 4;
			Set<String> cpfHist = new HashSet<String>();
			while (!StringA.piece(line, ";", pos+1).equals("")) {
				loadCols(dh, wiMap, cpfHist, line, pos);
				pos = pos + 5;
			}
		}
		br.close();
	}
	
	private void loadCols(DatabaseHandler dh, WIMap wiMap, Set<String> cpfHist, String line, int pos) 
	throws Exception {
		String cpf = StringA.piece(line, ";", pos);
		cpf = StringA.changeChars(cpf, ".- ", "").trim();
		wiMap.put("tmp.obj.cpf", cpf);
		String resp = StringA.piece(line, ";", pos+1).trim();
		wiMap.put("tmp.obj.resp", resp);
		String email = StringA.piece(line, ";", pos+2).trim();
		wiMap.put("tmp.obj.email", email);
		String cel = StringA.piece(line, ";", pos+3).trim();
		if (cel.length() > 20) cel = cel.substring(0, 20);
		wiMap.put("tmp.obj.cel", pos+4);
		String tel = StringA.piece(line, ";", pos+4).trim();
		if (tel.length() > 20) tel = tel.substring(0, 20);
		wiMap.put("tmp.obj.tel", tel);
		if (cpfHist.contains(cpf)) return;
		if (cpf.equals("")) {
			System.out.println("###=> CPF VAZIO: " + resp);
		} else if (email.equals("")) {
			System.out.println("###=> EMAIL VAZIO: " + resp);
		} else {
			System.out.println(cpf + " - " + resp);
			addTurma(dh, wiMap);
			cpfHist.add(cpf);
		}
	}
	
	private void addTurma(DatabaseHandler dh, WIMap wiMap) throws Exception {
		findResponsavel(dh, wiMap);
		findAluno(dh, wiMap);
		String insert = "insert into tb_aluno_instituicao (ts_turma, ts_matricula, fk_aluno, fk_instituicao) "
				+ "values (?|tmp.obj.turma|, ?|tmp.obj.mat|, ?|tmp.obj.id_aluno|, ?|tmp.obj.id_inst|)";
		dh.executeUpdate(insert, wiMap);
	}

	private void findResponsavel(DatabaseHandler dh, WIMap wiMap) throws Exception {
		ConnectionSql con = (ConnectionSql) dh.getDatabaseConnection();
		String query = "select r.*, u.ts_password from tb_responsavel r "
				+ "inner join tb_usuario u on (r.fk_usuario = u.usuario_id)"
				+ "where ts_cpf = ?|tmp.obj.cpf|";
		ResultSet rs = dh.execute(query, wiMap);
		if (rs.next() > 0) {
			wiMap.put("tmp.obj.id_resp", rs.column("id_responsavel"));
			wiMap.put("tmp.obj.id_usu", rs.column("fk_usuario"));
			if (rs.column("ts_password").trim().equals("")) {
				updatePassword(dh, wiMap);
			}
		} else {
			findUsuario(dh, wiMap);
			String insert = "insert into tb_responsavel (ts_cpf, ts_telefone_fixo, ts_telefone_celular, ts_telefone_opcional, "
					+ "ts_caminho_foto, fk_usuario) "
					+ "values (?|tmp.obj.cpf|, '', ?|tmp.obj.tel|, '', '', ?|tmp.obj.id_usu|)";
			con.returnGeneratedKeys();
			dh.executeUpdate(insert, wiMap);
			ResultSet rsKey = con.getGeneratedKeys();
			if (rsKey.next() > 0) {
				wiMap.put("tmp.obj.id_resp", rsKey.column(1));
			}
			updatePassword(dh, wiMap);
		}
	}

	private void findUsuario(DatabaseHandler dh, WIMap wiMap) throws Exception {
		ConnectionSql con = (ConnectionSql) dh.getDatabaseConnection();
		String query2 = "select * from tb_usuario where ts_email = ?|tmp.obj.email|";
		ResultSet rs2 = dh.execute(query2, wiMap);
		if (rs2.next() > 0) {
			System.out.println("###=> EMAIL DUPLICADO PARA OUTRO CPF: " + wiMap.get("tmp.obj.email"));
			String rnd = Function.randomKey(5).toLowerCase();
			wiMap.put("tmp.obj.email", wiMap.get("tmp.obj.email") + "." + rnd);
		}	
		String insert = "insert into tb_usuario (is_superuser, ts_email, ts_password, ts_nome, st_confirmado, st_ativo, dt_criado) "
				+ "values (0, ?|tmp.obj.email|, '', ?|tmp.obj.resp|, 1, 1, now())";
		con.returnGeneratedKeys();
		dh.executeUpdate(insert, wiMap);
		ResultSet rsKey = con.getGeneratedKeys();
		if (rsKey.next() > 0) {
			wiMap.put("tmp.obj.id_usu", rsKey.column(1));
		}
		insert = "insert into tb_usuario_groups (usuario_id, group_id) values (?|tmp.obj.id_usu|, "
				+ "(select id from auth_group where name = 'Responsavel'))";
		dh.executeUpdate(insert, wiMap);
	}
	
	private void findAluno(DatabaseHandler dh, WIMap wiMap) throws Exception {
		ConnectionSql con = (ConnectionSql) dh.getDatabaseConnection();
		String query = "select * from tb_aluno_instituicao where ts_matricula = ?|tmp.obj.mat| "
				+ "and fk_instituicao = " + ID_INSTITUICAO_PROD;
		ResultSet rs = dh.execute(query, wiMap);
		if (rs.next() > 0) {
			wiMap.put("tmp.obj.id_aluno", rs.column("fk_aluno"));
		} else {
			String insert = "insert into tb_aluno (ts_nome, ts_caminho_foto) "
					+ "values (?|tmp.obj.aluno|, '')";
			con.returnGeneratedKeys();
			dh.executeUpdate(insert, wiMap);
			ResultSet rsKey = con.getGeneratedKeys();
			if (rsKey.next() > 0) {
				wiMap.put("tmp.obj.id_aluno", rsKey.column(1));
			}
		}
		updateFoto(dh, wiMap);
		String insert = "insert ignore into tb_responsavel_aluno (st_principal, fk_aluno, fk_responsavel) values"
				+ "(1,?|tmp.obj.id_aluno|,?|tmp.obj.id_resp|)";
		dh.executeUpdate(insert, wiMap);		
		String delete = "delete from tb_aluno_instituicao "
				+ "where fk_aluno = ?|tmp.obj.id_aluno| and fk_instituicao = ?|tmp.obj.id_inst|";
		dh.executeUpdate(delete, wiMap);
	}
	
	private void updateFoto(DatabaseHandler dh, WIMap wiMap) throws Exception {
		String pasta = getIdInstituicaoSTR(ID_INSTITUICAO_PROD);
		String tsMat = wiMap.get("tmp.obj.mat");
		File file = new File(wiMap.get("wi.proj.path")+"/WEB-INF/importar/alunos-" + pasta + "/" + tsMat + ".jpg");
		if (file.isFile()) {
			resizeImage(file);
			String update = "update tb_aluno set ts_caminho_foto = 'alunos/" + pasta + "/" + tsMat +  ".jpg' "
					+ "where id_aluno = ?|tmp.obj.id_aluno|";
			dh.executeUpdate(update, wiMap);
		}
	}
	
	private void resizeImage(File file) throws Exception {
		BufferedImage orig = ImageIO.read(file);
		boolean write = false;
		if (orig.getWidth() > orig.getHeight()) {
			orig = Scalr.rotate(orig, Rotation.CW_90);
			write = true;
		}
		if (orig.getWidth() > 500 && orig.getHeight() > 500) {
			orig = Scalr.resize(orig, Scalr.Mode.FIT_TO_WIDTH, 500, 0);
			write = true;
		}
		if (orig.getHeight() > orig.getWidth()) {
			orig = Scalr.crop(orig, orig.getWidth(), orig.getWidth());
			write = true;
		}
		if (write) ImageIO.write(orig, "jpg", file);
		orig.flush();
	}
	
	private void updatePassword(DatabaseHandler dh, WIMap wiMap) throws Exception {
		Map<String, String> passMap = new LinkedHashMap<String, String>();
		String query = "select usuario_id, ts_cpf, ts_nome, ts_password from tb_responsavel r "
						+ "inner join tb_usuario u on (u.usuario_id = r. fk_usuario) "
						+ "where id_responsavel = ?|tmp.obj.id_resp|";
		ResultSet rs = dh.execute(query, wiMap);
		while (rs.next() > 0) {
			String uid = rs.column("usuario_id");
			String iniCpf = rs.column("ts_cpf").substring(0,3);
			String iniNome = rs.column("ts_nome").substring(0,3).toLowerCase();
			String pass = rs.column("ts_password");
			String hash = StringA.piece(pass, "$", 3);
			if (hash.equals("")) hash = Function.randomKey(12);
			String newpass = getDjangoHash(iniCpf + iniNome, hash, 30000);
			if (!pass.equals(newpass)) {
				passMap.put(uid, newpass);
			}
		}
		for (Map.Entry<String, String> entry : passMap.entrySet()) {
			wiMap.put("tmp.pass", entry.getValue());
			String update = "update tb_usuario set ts_password = ?|tmp.pass| "
							+ "where usuario_id = " + entry.getKey();
			dh.executeUpdate(update, wiMap);
		}
	}
	
	private String getIdInstituicaoSTR(int idprod) {
		if (idprod == 2) return "jardins";
		if (idprod == 3) return "santanna";
		if (idprod == 4) return "modulo";
		return null;
	}
	
	public String getDjangoHash(String password, String salt, int iterations) {
        PKCS5S2ParametersGenerator gen = new PKCS5S2ParametersGenerator(new SHA256Digest());
        gen.init(password.getBytes(), salt.getBytes(), iterations);
        byte[] dk = ((KeyParameter) gen.generateDerivedParameters(256)).getKey();
        byte[] hashBase64 = Base64.encodeBase64(dk);
        return "pbkdf2_sha256$30000$" + salt + "$" + new String(hashBase64);
    }	
	
	public static void main(String[] args) throws Exception {
		// O SALT do django tem 12 de tamanho
		System.out.println("pbkdf2_sha256$30000$FAxEhpuErXic$gWoAID7UZbNQNYSwb9b1JkfpI3KQgbeaMU5ABqaIf0s=");
		String pass = new ImportCSV().getDjangoHash("932fla", "FAxEhpuErXic", 30000);
		System.out.println(pass);
		String pass2 = new ImportCSV().getDjangoHash("789luc", "UT6VF4FV8UFY", 30000);
		System.out.println(pass2);
		
	}	
	
	public JavaParameter[] getInputParameters() {
		return new JavaParameter[0];
	}

	public JavaParameter[] getOutputParameters() {
		return new JavaParameter[0];
	}
	
}
