package br.com.webinside.runtime.lw.func.diariolw;

import java.io.File;
import java.math.BigInteger;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Date;

import org.json.simple.JSONObject;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.util.WIMap;

public class JsonGetPdf extends AbstractConnector {

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) 
			throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			getParams().getHttpResponse().setContentType("application/json; charset=iso-8859-1");
			String chave = wiMap.get("tmp.chave");
			if (chave.trim().equals("")) {
				sendError("Chave n�o informada");
				return;
			}
			String query = "SELECT * FROM tb_edicao e "
					+ "INNER JOIN tb_assinatura a ON (a.id_assinatura = e.fk_assinatura) "
					+ "WHERE st_removido = 0 and ts_chave = ?|tmp.chave|";
			ResultSet rs = dh.execute(query, wiMap);
			String idAss = rs.columnNext("id_assinatura");
			if (idAss.trim().equals("")) {
				sendError("Chave n�o encontrada");
				return;
			}
			String dtAss = rs.column("dt_assinatura");
			if (!dtAss.trim().equals("")) {
				sendError("Edi��o j� assinada anteriormente");
				return;
			}
			String path = wiMap.get("pvt.lwpath.priv");
			String keyEdicao = rs.column("nr_edicao") + rs.column("tp_edicao");
			File pdf = new File(path,"/diario/concluido/" + keyEdicao + ".pdf");
			if (!pdf.isFile()) {
				sendError("Pdf da edi��o n�o localizado");
				return;
			}
			JSONObject json = new JSONObject();
			json.put("status", "OK");
			json.put("date", new Date().getTime());
			json.put("nr_edicao", rs.column("nr_edicao"));
			json.put("dd_edicao", rs.column("dd_edicao"));
			json.put("tp_edicao", rs.column("tp_edicao"));
			byte[] pdfBytes = Files.readAllBytes(pdf.toPath());
			String b64 = Base64.getEncoder().encodeToString(pdfBytes);
			json.put("pdf", b64);
			byte[] sha1 = MessageDigest.getInstance("sha1").digest(pdfBytes);
			json.put("pdf_sha1", new BigInteger(1, sha1).toString(16));
			getParams().getWriter().println(json.toJSONString());
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}

	private void sendError(String msg) {
		JSONObject json = new JSONObject();
		json.put("status", "ERROR");
		json.put("msg", msg);
		getParams().getWriter().println(json.toJSONString());
	}
	
	@Override
	public boolean exit() {
		return true;
	}	

}
