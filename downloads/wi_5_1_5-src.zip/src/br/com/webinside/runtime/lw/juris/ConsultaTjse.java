package br.com.webinside.runtime.lw.juris;

import java.io.FileInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;
import java.util.concurrent.Semaphore;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.jsoup.Jsoup;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.WIMap;

public class ConsultaTjse extends AbstractConnector implements InterfaceParameters {
	
	public static final int MAX_THREADS = 10;
	public static final int START_SLEEP = 3;
	public static final int RETRY_SLEEP = 5;
	
	private static boolean JOB_RUNNING = false;
	private static Properties tjseProps = null;
	
	private Semaphore semaphore = new Semaphore(MAX_THREADS);
    private DatabaseHandler dh = null;
	private String twocaptcha_key = null;
	
    public Semaphore getSemaphore() {
		return semaphore;
	}

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers)
			throws UserException {
		String className = getClass().getName();
		try {
			dh = databases.get("principal");
			if (dh == null) {
				String msg = "Get database error (principal)";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
	    	String sql = "select ts_parametro from tb_parametro "
	    			+ "where id_parametro = 'twocaptcha_api_key'";
	    	ResultSet rs = dh.execute(sql, wiMap);
	    	twocaptcha_key = rs.columnNext(1);
			String type = wiMap.get("tmp.consulta_type");
			if (type.equalsIgnoreCase("all")) {
				String token = wiMap.get("tmp.token");
				boolean local = wiMap.get("wi.server.host").equals("localhost") && token.equals("lw1234");
				if (!local || JOB_RUNNING) {
					String msg = "url is not localhost or token not found";
					if (JOB_RUNNING) {
						SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
				    	System.out.println("JOB TJSE-Thread (ConsultaTodos) Already Running = " + sdf.format(new Date()));
						msg = "job already running";
					}
					wiMap.put("tmp.quantidade", "0");
					wiMap.put("tmp.duracao", "0 (" + msg+ ")");
					return;
				}			
				try {
					JOB_RUNNING = true;
					consultaTodos(wiMap);
				} catch (Throwable e) {
					throw e;
				} finally {
					JOB_RUNNING = false;
				}
			} else if (type.equalsIgnoreCase("balance")) {
    			ConsultaTjseThread.balance(twocaptcha_key, wiMap);
			} else {
				consultaSimples(wiMap);
			}
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}

    private void consultaTodos(WIMap wiMap) throws Exception {
    	long iniTime = new Date().getTime();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    	System.out.println("Iniciada TJSE-Thread (ConsultaTodos) = " + sdf.format(new Date()));
    	List<String> procList = new ArrayList<>();
		String sql = "SELECT ts_nr_inst, id_instancia FROM tb_processo p "
				+ "INNER JOIN vw_instancia i ON (i.fk_inst_proc = p.id_processo) "
				+ "LEFT JOIN tb_inst_info ii ON (ii.fk_instancia = i.id_instancia) "
				+ "WHERE (ii.st_finalizado = 0 OR ii.st_finalizado IS null) "
				+ "and (DATE_ADD(dt_registro, INTERVAL 12 HOUR) < now() or dt_registro IS null)"
				+ "and tp_processo = 'J' AND i.ts_trib_sigla = 'TJSE' "
				+ "order by 1";
		ResultSet rs = dh.execute(sql, wiMap);
		while (rs.next() > 0) {
			String key = rs.column(1) + "=" + rs.column(2);
			procList.add(key);
		}
		wiMap.put("tmp.quantidade", procList.size());
		for (String key : procList) {
			String numProc = key.split("=")[0];
			String idInst = key.split("=")[1];
			semaphore.acquire();
        	ConsultaTjseThread consultaThread = 
        			new ConsultaTjseThread(this, twocaptcha_key, numProc, idInst);
    		consultaThread.start();
    		Thread.sleep(START_SLEEP * 1000);
			getParams().getWriter().print(" ");
		}
		// Espera que todas as threads estejam finalizadas
		semaphore.acquire(MAX_THREADS); 
        long segTotal = (new Date().getTime() - iniTime) / 1000;
        long horas = segTotal / 3600;
        long minutos = (segTotal % 3600) / 60;
        long segundos = segTotal % 60;
        String duracao = String.format("%02d:%02d:%02d", horas, minutos, segundos);
		wiMap.put("tmp.duracao", duracao);
    	System.out.println("Finalizada TJSE-Thread (ConsultaTodos) com tempo " + duracao);
    }

    private void consultaSimples(WIMap wiMap) throws Exception {
    	String sql = "select id_instancia, fk_inst_proc from vw_instancia "
    			+ "where ts_trib_sigla = 'TJSE' AND ts_nr_inst = ?|tmp.consulta_npro|";
    	ResultSet rs = dh.execute(sql, wiMap);
    	rs.next();
    	String idInst = rs.column(1);
    	String idProc = rs.column(2);
    	wiMap.put("tmp.consulta_inst", idInst);
		wiMap.put("tmp.obj.id_processo", idProc);
    	if (!wiMap.get("tmp.consulta_type").equalsIgnoreCase("update")) {
    		sql = "SELECT tx_informacao FROM tb_inst_info "
    				+ "where fk_instancia = ?|tmp.consulta_inst| "
    				+ "and DATE_ADD(dt_registro, INTERVAL 12 HOUR) > now()";
    		rs = dh.execute(sql, wiMap);
    		if (rs.next() > 0) {
    			String resp = rs.column(1);
    			JSONObject json = (JSONObject) new JSONParser().parse(resp);
    			wiMap.put("tmp.json_div", jsonDiv(wiMap, json, "json_div"));
    			return;
    		}
    	}
    	String numProc = wiMap.get("tmp.consulta_npro");
    	JSONObject json = ConsultaTjseThread.execute(twocaptcha_key, numProc);
    	if (json == null) {
    		json = new JSONObject();
    		json.put("msg", "Falha de comunica��o");
    	}
    	databaseUpdate(idInst, json);
    	String text = jsonDiv(wiMap, json, "json_div");
    	// text = ElasticUtil.prettyJson(json);
    	if (json.get("msg") != null) text += "<br/>";
		wiMap.put("tmp.json_div", text);
    }
    	   
    public synchronized void databaseUpdate(String idInst, JSONObject json) throws Exception {
    	WIMap wiMap = new WIMap();
		if (!idInst.equals("") && json != null) {
			processaJson(wiMap, json);
			dh.executeUpdate("delete from tb_inst_info where fk_instancia = " + idInst, wiMap);
			String ddMov = !wiMap.get("tmp.save_dd_mov").equals("") ? "?|tmp.save_dd_mov|" : "null";
			String txMov = !wiMap.get("tmp.save_tx_mov").equals("") ? "?|tmp.save_tx_mov|" : "null";
			String insert = "insert into tb_inst_info (fk_instancia, dt_registro, tx_informacao, dd_movimento, tx_movimento, st_finalizado)"
					+ "values (" + idInst + ",now(),?|tmp.tx_informacao|," + ddMov + "," + txMov + ",|tmp.save_final|)";
			wiMap.put("tmp.tx_informacao", json.toJSONString());
			dh.executeUpdate(insert, wiMap);
		}
    }

    private void processaJson(WIMap wiMap, JSONObject json) {
    	if (json.containsKey("movimentos")) {
    		JSONArray arr = (JSONArray)json.get("movimentos");
    		JSONObject obj = (JSONObject)arr.get(0); 
    		if (obj.containsKey("dataMovimento")) {
    			String[] dd = obj.get("dataMovimento").toString().split("/"); 
    	    	wiMap.put("tmp.save_dd_mov", dd[2] + "-" + dd[1] + "-" + dd[0]);
    		}
    		if (obj.containsKey("descricao")) {
    			String value = obj.get("descricao").toString();
    			value = Jsoup.parse((String)value).text().trim();
    	    	wiMap.put("tmp.save_tx_mov", value);
    		} else if (obj.containsKey("movimento")) {
    			wiMap.put("tmp.save_tx_mov", obj.get("movimento").toString());
    		}
    	}
    	wiMap.put("tmp.save_final", "0");
    	if (json.containsKey("fase")) {
    		if (json.get("fase").equals("ARQUIVADO")) {
    			wiMap.put("tmp.save_final", "1");
    		}
    	}
    }
    
    private String jsonDiv(WIMap wiMap, JSONObject json, String id) throws Exception {
		if (json == null) return "";
		StringBuilder resp = new StringBuilder();
		if (!id.equals("")) {
			resp.append("<div id='" + id  + "'>\n");
		} else {
			resp.append("<div>\n");
		}
    	Map<String, Object> labelMap = new TreeMap();
    	for (Object obj : json.keySet()) {
    		String key = (String)obj;
    		if (key.equals("link") 
    				|| key.equals("token") 
    				|| key.equals("rotuloMovimento")) {
    			continue;
    		}
    		Object value = json.get(key);
    		String label = getPropValue(wiMap, key);
    		if (label.equals("") || (value instanceof JSONArray)) label = key;
    		if (key.equals("processosDependentes")) label = "array_1";
    		if (key.equals("assuntos")) label = "array_2";
    		if (key.equals("partes")) label = "array_3";
    		if (key.equals("composicao")) label = "array_4";
    		if (key.equals("movimentos")) label = "array_5";
    		labelMap.put(label, key);
		}
    	for (Map.Entry<String, Object> entry : labelMap.entrySet()) {
			String jsonKey = entry.getValue().toString();
			Object value = json.get(jsonKey); 
			if (!(value instanceof JSONArray)) {
				if (jsonKey.equals("nmDesembargador")) {
					value =  ((String)value).replace("<br>", " - ");
				}
				if (jsonKey.equals("diarioJustica") 
						|| jsonKey.equals("descricao")
						|| jsonKey.equals("filiacao")) {
					value =  Jsoup.parse((String)value).text().trim();
				}
				if (value instanceof Boolean) {
					value = (boolean)value ? "S" : "N";
				}
				resp.append("<p><b>" + entry.getKey() + ":</b> " + value + "</p>\n");
			}
		}
    	for (Map.Entry<String, Object> entry : labelMap.entrySet()) {
			String jsonKey = entry.getValue().toString();
			Object value = json.get(jsonKey); 
			if (value instanceof JSONArray) {
				JSONArray array = (JSONArray) value;
				resp.append("<div id='" + jsonKey  + "'>\n");
				resp.append("<h1>" + getPropValue(wiMap, jsonKey)  + "</h1>\n");
				for (int i = 0; i < array.size(); i++) {
					if (array.get(i) instanceof JSONObject) {
						JSONObject jsonAux = (JSONObject) array.get(i);
						resp.append(jsonDiv(wiMap, jsonAux, ""));
						if (i < array.size() -1) {
							resp.append("<hr/>\n");
						}
					} else {
						resp.append("<p>" + array.get(i) + "</p>\n");
					}
				}
				resp.append("</div>\n");
			}
		}
		resp.append("</div>\n");
    	return resp.toString();
    }
       
	private String getPropValue(WIMap wiMap, String key) throws Exception {
		if (tjseProps == null) {
			String projPath = wiMap.get("wi.proj.path");
			tjseProps = new Properties();
	    	InputStream is = new FileInputStream(projPath + "/WEB-INF/tjse.properties");
	    	tjseProps.load(is);
	        is.close();
		}
		String value = tjseProps.getProperty(key);
		if (value == null) value = "";
		return value;
	}
    
	@Override
	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[2];
		in[0] = new JavaParameter("tmp.consulta_type", "Tipo (vazio/update/balance/all)");
		in[1] = new JavaParameter("tmp.consulta_npro", "Numero Processo");
		return in;
	}

	@Override
	public JavaParameter[] getOutputParameters() {
		return null;
	}
	
}
