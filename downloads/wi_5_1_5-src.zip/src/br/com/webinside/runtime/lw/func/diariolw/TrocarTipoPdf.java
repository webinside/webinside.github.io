package br.com.webinside.runtime.lw.func.diariolw;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class TrocarTipoPdf extends AbstractConnector {
		
	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			String query = "select ts_cont_key, nr_pag_pdf, st_pdf_grande from tb_conteudo "
					+ " where id_conteudo = ?|tmp.obj.id_conteudo| and tp_conteudo = 'P'";
			ResultSet rs = dh.execute(query, wiMap);
			if (rs.next() > 0) {
				String imgCols = "";
				String tamPerc = "";
				String contKey = rs.column(1);
				String qtdPag = rs.column(2);
				String newType = wiMap.get("tmp.obj.st_pdf_grande");
				String oldType = rs.column(3); 
				if (oldType.equals("1") && newType.equals("0")) {
					imgCols = "2";
					tamPerc = "100";
				}
				if (oldType.equals("0") && newType.equals("1")) {
					imgCols = "1";
					tamPerc = "97";
//					if (i == pages) tamPerc = "95";
				}
				if (!imgCols.equals("")) {
					String upd = "update tb_conteudo_img set nr_img_cols = " + imgCols 
							+ " , nr_tam_perc = " + tamPerc + " where id_conteudo = ?|tmp.obj.id_conteudo|";
					dh.executeUpdate(upd, wiMap);
					if (tamPerc.equals("97")) {
						upd = "update tb_conteudo_img set nr_tam_perc = 95 "
								+ "where id_conteudo = ?|tmp.obj.id_conteudo| and id_img_seq = " + qtdPag;
						dh.executeUpdate(upd, wiMap);
					}
					String fldKey = "c" + wiMap.get("tmp.obj.id_conteudo") + "-" + contKey;
					String imgFolder = wiMap.get("pvt.lwpath.pub") + "/diario/doc-img/" + fldKey;
					Function.removeFiles(imgFolder, "*.html");
				}
			}
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
			
}
