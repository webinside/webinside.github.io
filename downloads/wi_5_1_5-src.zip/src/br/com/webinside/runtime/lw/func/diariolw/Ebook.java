package br.com.webinside.runtime.lw.func.diariolw;

import java.io.File;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.util.WIMap;

public class Ebook extends AbstractConnector {

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		try {
			String database = "diariolw";
			DatabaseHandler dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			String root = wiMap.get("pvt.lwpath.priv") + "/diario";
			String sql = "select ts_file from vw_edicao_publicada "
					+ "order by nr_pdf desc, tp_pdf desc limit 1";
			ResultSet rs = dh.execute(sql, wiMap);
			File pdf = new File(root, rs.columnNext(1) + ".pdf");
			new EbookThread(pdf).start();
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}


}
