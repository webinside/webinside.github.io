
package br.com.webinside.runtime.lw.func.ged;

import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfReaderContentParser;
import com.itextpdf.text.pdf.parser.SimpleTextExtractionStrategy;
import com.itextpdf.text.pdf.parser.TextExtractionStrategy;

public class ExtrairTextoArquivo extends AbstractConnector implements InterfaceParameters {

	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "principal";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			int idArq = Function.parseInt(wiMap.get("tmp.ged.id_arquivo").trim());
			String sql = "call sp_base_textual('ged_arquivo'," +
					"?|tmp.ged.id_arquivo|,0,null,null,null)";
			dh.executeUpdate(sql, wiMap);
			String pdfFolder = wiMap.get("pvt.lwpath.priv") + "/ged/arquivo";
			String pdfFile = pdfFolder + "/file-" + idArq + ".pdf";
	        PdfReader pdfReader = new PdfReader(pdfFile);
	        PdfReaderContentParser parser = new PdfReaderContentParser(pdfReader);
	        TextExtractionStrategy strategy;
			sql = "call sp_base_textual('ged_arquivo',?|tmp.ged.id_arquivo|," +
					"0,?|tmp.arq.ts_arquivo|,'','')";
			dh.executeUpdate(sql, wiMap);
	        sql = "call sp_base_textual('ged_arquivo',?|tmp.ged.id_arquivo|," +
	        		"?|tmp.page|,?|tmp.txt|,'','')";
	        for (int i = 1; i <= pdfReader.getNumberOfPages(); i++) {
	            strategy = parser.processContent(i, new SimpleTextExtractionStrategy());
	            String txt = strategy.getResultantText();
	            wiMap.put("tmp.page", i + "");
	            wiMap.put("tmp.txt", txt);
	            dh.executeUpdate(sql, wiMap);
	        }
			pdfReader.close();
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
		
	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[1];
		in[0] = new JavaParameter("tmp.ged.id_arquivo", "ID do Arquivo");
		return in;
	}

	public JavaParameter[] getOutputParameters() {
		return new JavaParameter[0];
	}
	
}
