package br.com.webinside.runtime.lw.juris;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.function.HtmlToPdfCore;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class PageToPdf extends AbstractConnector implements InterfaceParameters {

	private static Map<String, WIMap> keyMap = new HashMap<String, WIMap>();
	
	private boolean exit = true;
	
	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) throws UserException {
		boolean win = (System.getProperty("os.name").toLowerCase().indexOf("win") >= 0);
		String isPdfPage = wiMap.get("tmp.is_pdf_page");
		if (!isPdfPage.trim().equalsIgnoreCase("true")) {
			String key = Function.randomKey(20);
			WIMap auxMap = new WIMap();
			auxMap.putObj("pvt.login.", wiMap.getObj("pvt.login."));
			auxMap.putObj("tmp.rpt.", wiMap.getObj("tmp.rpt."));
			keyMap.put(key, auxMap);
			String exe = win ? "windows/phantomjs.exe" : "linux-x86_64/phantomjs";
			String projPath = wiMap.get("wi.proj.path");
			String cmd = new File(projPath + "/WEB-INF/phantomjs-2.1.1/" + exe).getAbsolutePath();
			try {
				File tmpPdf = new File(Function.rndTmpFile("jurislw", "pdf"));
				String page = "http://localhost:8080/" + wiMap.get("wi.proj.id") + "/" + wiMap.get("tmp.pdf_page_id") + ".wsp";
				String url = page + "?tmp.pdfkey=" + key;
				String pdf = tmpPdf.getAbsolutePath();
				String lay = wiMap.get("tmp.pdf_layout").trim(); 
				if (lay.equals("")) lay = "landscape";
				String fsize = win ? "9pt" : "6pt";
				ProcessBuilder pb = new ProcessBuilder(cmd, "script.js", url, pdf, lay, fsize);
				pb.directory(new File(projPath + "/WEB-INF/phantomjs-2.1.1/"));
				pb.start().waitFor();
				afterPdfGenerated(wiMap, databases, tmpPdf);
				HtmlToPdfCore.exportPdf(getParams(), tmpPdf, wiMap.get("tmp.pdf_title") + ".pdf");
				tmpPdf.delete();
			} catch (Exception e) {
				e.printStackTrace();
			}
			keyMap.remove(key);
		} else {
			WIMap auxMap = keyMap.get(wiMap.get("tmp.pdfkey"));
			if (auxMap != null) {
				wiMap.putAll(auxMap.getAsMap());
				String zoom = win ? "win":"lin";
				wiMap.put("tmp.html_zoom", zoom);
				exit = false;
			}
			if (wiMap.getObj("tmp.rpt.") != null) exit = false;
			wiMap.put("wi.session.id", "invalidate");
		}
	}
	
	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[4];
		in[0] = new JavaParameter("tmp.is_pdf_page", "P�gina Pdf (true/false)");
		in[1] = new JavaParameter("tmp.pdf_page_id", "ID da P�gina Pdf");
		in[2] = new JavaParameter("tmp.pdf_title", "Titulo do Pdf");
		in[3] = new JavaParameter("tmp.pdf_layout", "Layout do Pdf");
		return in;
	}

	public JavaParameter[] getOutputParameters() {
		return new JavaParameter[0];
	}

	public void afterPdfGenerated(WIMap wiMap, DatabaseAliases databases, File tmpPdf) {
		// override to append content
	}
	
	@Override
	public boolean exit() {
		return exit;
	}
	
}
