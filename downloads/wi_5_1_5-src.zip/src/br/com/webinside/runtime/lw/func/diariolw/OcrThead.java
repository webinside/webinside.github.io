package br.com.webinside.runtime.lw.func.diariolw;

import java.io.File;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class OcrThead extends Thread {
	
	private static final String TMP_DIR = System.getProperty("java.io.tmpdir");
	private static final Map<String, Thread> threadMap = new HashMap();
	
	private WebDriver driver;
	
	private ServletContext sc = null;
	private DatabaseHandler dh = null;
	private String key = null;
	private File pdf = null;
	
	public OcrThead(ServletContext sc, DatabaseHandler dh, String key, File pdf) {
		threadMap.put(key, this);
		this.sc = sc;
		this.dh = dh;
		this.key = key;
		this.pdf = pdf;
	}

	@Override
	public void run() {
		try {
			initDriver();
			executeScript();
		} catch (Exception err) {
			if (!err.getMessage().equals("ABORTED")) {
				err.printStackTrace(System.out);
//				String cname = this.getClass().getName();
//				ExecuteParams.get().getErrorLog().write(cname, "RUN", err);
			}
		} finally {
			closeDriver();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) { }
 			out("END");
		}
	}
	
	private void initDriver() throws Exception {
		out("Iniciando integra��o com OCR");

		File wdFile = new File("/temp/webdriver/chromedriver.exe");
		if (!wdFile.isFile()) wdFile = new File("/tmp/webdriver/chromedriver");
		if (wdFile.isFile()) {
	        System.setProperty("webdriver.chrome.driver", wdFile.getAbsolutePath());
		} else {
			System.clearProperty("webdriver.chrome.driver");
		}
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("start-maximized");
		options.addArguments("--headless");
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-gpu");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--disable-crash-reporter");
        options.addArguments("--ignore-certificate-errors");				
        options.addArguments("--disable-in-process-stack-traces");
        options.addArguments("--disable-notifications");
        options.addArguments("--disable-extensions");
        options.addArguments("--disable-logging");
        options.addArguments("--lang=pt-BR");
        
        HashMap chromePrefs = new HashMap();
        chromePrefs.put("profile.default_content_settings.popups", 0);
        chromePrefs.put("download.default_directory", TMP_DIR);
        options.setExperimentalOption("prefs", chromePrefs);
        
		driver = new ChromeDriver(options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
	}

	private void executeScript() throws Exception { 
		new File(TMP_DIR, pdf.getName()).delete();
		new File(TMP_DIR, pdf.getName() + ".crdownload").delete();
		out("Carregando url do OCR");
		driver.get("https://tools.pdf24.org/pt/ocr-pdf");
//		out("Abrindo caixa para envio do pdf para OCR");
//		driver.findElement(By.id("fileZone")).click();
//		Thread.sleep(1000);
		String sendMsg = "Enviando arquivo para processar OCR";
		out(sendMsg);
		upload(pdf.getAbsolutePath());
		LocalDateTime endTime = LocalDateTime.now().plusMinutes(60);		
		String endMask = "//div[contains(@class, 'dz-complete')]";
		WebElement endEle = findElement(By.xpath(endMask), 2);		
		while (endEle == null && LocalDateTime.now().isBefore(endTime)) {
			WebElement pgEle = driver.findElement(By.className("dz-upload-text"));
			if (pgEle != null && !pgEle.getText().trim().equals("")) {
				out(sendMsg + " - " + pgEle.getText().trim());
			}
			endEle = findElement(By.xpath(endMask), 2);
		}
		saveScreen();
		WebElement errEle = driver.findElement(By.className("dz-error-message"));
		if (endEle == null || (errEle != null && !errEle.getText().trim().equals(""))) {
			String errMsg = errEle.getText().trim();
			if (errMsg.equals("")) errMsg = "Problema ao enviar arquivo para OCR";
			out("ERRO - " + errMsg);
			return;
		}
		out("Configurando par�metros para processar OCR");
		WebElement lang = driver.findElement(By.id("ms-list-1"));
		lang.click();
		Thread.sleep(1000);
		WebElement ptBR = lang.findElement(By.cssSelector("[data-search-term='portuguese']"));
		scroll(ptBR);
		ptBR.click();
		scroll(lang);
		lang.click();
		Thread.sleep(1000);
		driver.findElement(By.id("forceParamElem")).click();
		driver.findElement(By.id("actionButtons")).click();
		Thread.sleep(1000);
		out("Iniciando processamento do OCR");
		WebElement iframe = findElement(By.className("workerFrame"), 10);
		driver.switchTo().frame(iframe);
		WebElement pview = findElement(By.id("processingView"), 3);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1));
		WebElement btn = null;
		while (btn == null) {
			Thread.sleep(1000);
			// String text = pview.findElement(By.className("text")).getText();
			String status = pview.findElement(By.className("status")).getText();
			if (status.trim().equals("")) status = "Processamento OCR remoto finalizado";
			out(status);
			try {
				btn = wait.until(ExpectedConditions.elementToBeClickable(By.id("downloadTool")));
			} catch (TimeoutException e) { }
		}
		btn.click();
		out("Recebendo arquivo com OCR processado");
		Thread.sleep(1000);
		if (dh == null) out("Diretorio: " + TMP_DIR);
		File partPdf = new File(TMP_DIR, pdf.getName() + ".crdownload");
		while (partPdf.isFile()) Thread.sleep(1000);
		File ocrPdf = new File(TMP_DIR, pdf.getName());
		if (ocrPdf.isFile()) {
			if (dh != null && setSucesso()) {
				Function.copyFile(ocrPdf.getAbsolutePath(), pdf.getAbsolutePath());
			}
			ocrPdf.delete();
			out(OcrMonitor.MSG_S);
		} else {
			out(OcrMonitor.MSG_E);
		}
 	}
	
	private void upload(String filename) throws Exception {
		WebElement fileInput = driver.findElement(By.cssSelector("input[type=file]"));
	    fileInput.sendKeys(filename);
		/*
		Robot rb = new Robot();
	    StringSelection str = new StringSelection(filename);
	    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
	    // press Contol+V for pasting
	    rb.keyPress(KeyEvent.VK_CONTROL);
	    rb.keyPress(KeyEvent.VK_V);
	    // release Contol+V for pasting
	    rb.keyRelease(KeyEvent.VK_CONTROL);
	    rb.keyRelease(KeyEvent.VK_V);
	    // for pressing and releasing Enter
	    rb.keyPress(KeyEvent.VK_ENTER);
	    rb.keyRelease(KeyEvent.VK_ENTER);
	    */
	}

	private void saveScreen() throws Exception {
		File folder = new File("/temp");
		if (!folder.isDirectory()) folder = new File("/tmp");
		if (new File(folder, "ocr_screen.save").isFile()) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
			String strDate = sdf.format(new Date());
			TakesScreenshot screenshot = ((TakesScreenshot) driver);
			File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
			File destFile = new File(folder, "ocr_screen_" + strDate + ".png");
			FileUtils.copyFile(srcFile, destFile);
		}
	}
	
    private WebElement findElement(By by, int seconds) {
        try {
        	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(seconds));
            wait.until(ExpectedConditions.presenceOfElementLocated(by));
		    return driver.findElement(by);
        } catch (Exception error) {
            return null;
        }
	}

    private void scroll(WebElement ele) throws Exception {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
		Thread.sleep(1000); 
    }
    
	private void closeDriver() {
		if (driver != null) driver.quit();
		driver = null;
	}
	
	private boolean setSucesso() {
		boolean ok = false;
		dh.connect();
		try {
			String query = "SELECT nr_edicao FROM tb_edicao "
					+ " WHERE fn_tb_hash(ts_edi_key, 0) = '" + key + "'"
					+ " and st_finalizada = 1 and st_publicada = 0 ";
			ResultSet rs = dh.execute(query, new WIMap());
			ok = (rs.next() > 0);
 			if (ok) {
				String update = "update tb_edicao set tp_ocr_status = 'S' "
						+ "where fn_tb_hash(ts_edi_key, 0) = '" + key + "'";
				dh.executeUpdate(update, new WIMap());
			}
		} catch (Exception e) { }
		dh.close();
		return ok;
	}
	
	private void out(String text) {
		if (text.equals("END")) {
			if (sc != null && threadMap.get(key) == this) {
				getContextMap().remove(key);
			}
			return;
		}
		if (!text.startsWith("SUCESSO") && !text.startsWith("ERRO")) {
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
			text = sdf.format(new Date()) + " - " + text; 
		}
		if (sc != null) {
			if (threadMap.get(key) != this) throw new RuntimeException("ABORTED");
			getContextMap().put(key, text);
		} else {
			System.out.println(text);
		}
	}
	
	private Map<String, String> getContextMap() {
		Map<String, String> map = (Map)sc.getAttribute("ocrMap"); 
		if (map == null) {
			map = new HashMap<>();
			sc.setAttribute("ocrMap", map);
		}
		return map;
	}
	
	public static void main(String[] args) throws Exception {
		File pdf = new File("/temp/meu_arquivo_do_diario.pdf");
		new OcrThead(null, null, "1", pdf).start();
	}
	
}
