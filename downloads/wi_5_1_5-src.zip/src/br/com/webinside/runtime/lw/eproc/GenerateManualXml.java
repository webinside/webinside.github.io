package br.com.webinside.runtime.lw.eproc;

import java.io.File;
import java.io.StringWriter;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import com.itextpdf.text.pdf.PdfReader;

import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.StringA;
import br.com.webinside.runtime.util.WIMap;

public class GenerateManualXml extends GenerateXml {
	
	String caminho = null;

	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers) 
	throws UserException {
		try {
			init();
		} catch (ServletException se) { }	
		String prjPath = wiMap.get("wi.proj.path");
		try {
			String docId = wiMap.get("tmp.docid");
			if (Function.parseInt(docId) < 1) return;
			cleanOldGenerated(new File (prjPath, "/WEB-INF/generated"));			
			File docDir = new File (prjPath, "/WEB-INF/generated/man_d" + docId);
			docDir.mkdirs();
			// Inicializando XML
			
			Element rootEle = new Element("EprocReader");
			Element docsEle = new Element("docs");
			rootEle.addContent(docsEle);
			Element docEle = new Element("doc");
			docEle.setAttribute("id", "doc-" + docId);
			docsEle.addContent(docEle);
			Element docTitleEle = new Element("title");
			docEle.addContent(docTitleEle);
			Element pages = new Element("pages");
			docEle.addContent(pages);

			String pdf = "";
			String name = "";
			File[] list = new File(caminho).listFiles();
			for (File file : list) {
				String p1 = StringA.piece(file.getName(), "-", 1).trim();
				if (Integer.parseInt(p1) == Integer.parseInt(docId)) {
					name = StringA.piece(file.getName(),"-",2).trim();
					File destPdf = new File (docDir, "/bin/manual.pdf");
					if (!destPdf.isFile()) {
						destPdf.getParentFile().mkdirs();
						Function.copyFile(file.getAbsolutePath(), destPdf.getAbsolutePath());
					}
					pdf = destPdf.getAbsolutePath();
					break;
				}
			}
			docTitleEle.setText(StringA.piece(name, ".", 1).trim());
	        PdfReader pdfReader = new PdfReader(pdf);
	        int pgN = pdfReader.getNumberOfPages();
	        for (int i = 1; i <= pgN; i++) {
				Element pageEle = new Element("page");
				int pgW = Math.round(pdfReader.getCropBox(i).getWidth());
				int pgH = Math.round(pdfReader.getCropBox(i).getHeight());
				Element sizeEle = new Element("size");
				sizeEle.setText(pgW + "x" + pgH);
				pageEle.addContent(sizeEle);
				pages.addContent(pageEle);
				for (int s = 1; s <= 3; s++) {
					Element imgEle = new Element("img" + s);
					String params = "man_d=" + docId + "&p=" + i +"&s=" + s;
					imgEle.setText("/lwreader/EprocServlet?" + params);
					pageEle.addContent(imgEle);
				}
			}
			pdfReader.close();

			// Gravar o XML
			Document doc = new Document(rootEle);
			XMLOutputter out = new XMLOutputter();
			out.setFormat(defineXmlFormat(out.getFormat()));
			StringWriter sw = new StringWriter();
			out.output(doc, sw);
			wiMap.put("tmp.xml", sw.toString());
			new File(docDir, "lwreader.time").createNewFile();
			new File(docDir, "lwreader.time").setLastModified(new Date().getTime());
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(getClass().getName(), "Page: " + pageId, err);
		}
	}
	
	private void init() throws ServletException {
		if (caminho == null) {
	        ServletContext eprocSC = getParams().getServletContext().getContext("/eproc");
	        if (eprocSC != null) {
	        	String img = eprocSC.getInitParameter("localizacao.das.imagens"); 
	        	if (img != null) {
	        		caminho = new File(img).getParentFile().getParent() + "/manuais";
	        	}	
	        }
	        if (caminho == null) {
	        	caminho = "/home/tomcat7/eproc/manuais";
	        }
		}
    }
				
}
