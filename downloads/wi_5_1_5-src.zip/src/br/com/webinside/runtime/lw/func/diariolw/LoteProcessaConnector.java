package br.com.webinside.runtime.lw.func.diariolw;

import java.io.File;

import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.function.HasRole;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.lw.sql.Persist;
import br.com.webinside.runtime.util.ErrorLog;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class LoteProcessaConnector extends AbstractConnector {
	
	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers)
			throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";     
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			ShowMessage.addMessage(wiMap, "cont_lote", "Processando Lote");
	    	String priv = wiMap.get("pvt.lwpath.priv");
			String key = wiMap.get("tmp.obj.id_cont_lote");
	    	File loteDir = new File(priv, "/diario/lote/" + key);
	    	File docDir = new File(priv, "/diario/documento");
    		String fkEdicao = wiMap.get("tmp.obj.fk_edicao");
    		String sequence = wiMap.get("tmp.sequence");   
    		String[] seqs = sequence.split(",");
	    	for (int i = 0; i < seqs.length; i++) {
	    		int seq = Function.parseInt(seqs[i].trim());
	    		if (seq == 0) continue;
	    		wiMap.remove("tmp.obj.id_conteudo");
	    		boolean trim = wiMap.get("tmp.row[" + seq + "].st_autocrop").equals("1");
	    		String tsConteudo = wiMap.get("tmp.row[" + seq + "].ts_conteudo");
	    		String nrConteudo = wiMap.get("tmp.row[" + seq + "].nr_conteudo");
	    		String nrContAno = wiMap.get("tmp.row[" + seq + "].nr_cont_ano");
	    		String ddConteudo = wiMap.get("tmp.row[" + seq + "].dd_conteudo");
	    		if (tsConteudo.trim().equals("")) continue;
	    		String sqlExtensao = "select ts_extensao from tb_cont_lote "
	    				+ "where id_cont_lote = ?|tmp.obj.id_cont_lote| "
	    				+ "and id_cont_seq = 0" + seq;
	    		String extensao = dh.execute(sqlExtensao, wiMap).columnNext(1);
	    		wiMap.put("tmp.obj.tp_conteudo", extensao.equals("pdf") ? "P" : "D");
	    		wiMap.put("tmp.obj.tp_extensao", extensao);
	    		wiMap.put("tmp.obj.ts_cont_key", Function.randomKey(20, false).toLowerCase());
	    		if (!nrConteudo.equals("")) wiMap.put("tmp.obj.nr_conteudo", nrConteudo);
	    		if (!nrContAno.equals("")) wiMap.put("tmp.obj.nr_cont_ano", nrContAno);
	    		if (!ddConteudo.equals("")) wiMap.put("tmp.obj.dd_conteudo", ddConteudo);
	    		wiMap.put("tmp.obj.ts_conteudo", tsConteudo);
	    		wiMap.put("tmp.obj.nr_cont_cols", "2");
	    		wiMap.put("tmp.obj.nr_tam_perc", "100");
	    		if (!extensao.equals("pdf")) {
		    		wiMap.put("tmp.obj.nr_cont_cols", "0");
		    		wiMap.put("tmp.obj.nr_tam_perc", "0");
	    		}
	    		wiMap.put("tmp.obj.tx_conteudo", "");
	    		wiMap.put("tmp.obj.tx_cont_obs", "");
    			String situacao = "DIA";
	    		if (fkEdicao.equals("")) {
	    			situacao = "EMA";
		    		String[] autRole = {"cont-aut"};
		    		HasRole hasRole = new HasRole();
		    		hasRole.setWiMap(wiMap);
		    		if (hasRole.execute(autRole).equals("true")) {
		    			situacao = "AUT";
		    		}
	    		}
	    		wiMap.put("tmp.obj.fk_situacao", situacao);
	    		if (!fkEdicao.equals("")) {
	    			String nrOrdem = "1";
		    		if (nrConteudo.equals("")) {
		    			String sqlOrder = "select ifnull(max(nr_ordem),0)+1 as nr_ordem "
		    					+ "from tb_conteudo "
		    					+ "where fk_edicao = ?|tmp.obj.fk_edicao| "
		    					+ "and fk_caderno = ?|tmp.obj.fk_caderno| "
		    					+ "and st_removido = 0";
		    			nrOrdem = dh.execute(sqlOrder, wiMap).columnNext(1);
		    		}
		    		wiMap.put("tmp.obj.nr_ordem", nrOrdem);
	    		}
	    		wiMap.put("tmp.persist.database", "diariolw");
	    		wiMap.put("tmp.persist.table", "tb_conteudo");
	    		wiMap.put("tmp.persist.object", "tmp.obj");
	    		wiMap.put("tmp.persist.resp", "tmp.message");
	    		new Persist().execute(getParams());
	    		String insert = "insert into tb_evento (fk_tipo_evt, fk_conteudo, fk_usuario, dt_evento, tx_detalhe) "
	    				+ "values ('CREATED', ?|tmp.obj.id_conteudo|, ?|pvt.login.id_usuario|, now(), '')";
	    		dh.executeUpdate(insert, wiMap);
				wiMap.put("tmp.cont_lote_seq", seq);
				ShowMessage.addMessage(wiMap, "cont_lote", "Processando Lote Lote Seq. " + seq);
	    		File src = new File(loteDir, seq + "." + extensao);
	    		File dest = new File(docDir, "doc-" + wiMap.get("tmp.obj.id_conteudo") + "." + extensao);
	    		Function.copyFile(src.getAbsolutePath(), dest.getAbsolutePath());
	    		if (extensao.equals("pdf")) {
	    			wiMap.put("tmp.diario.id_conteudo", wiMap.get("tmp.obj.id_conteudo"));
	    			wiMap.put("tmp.autocrop", (trim ? "1" : "") );
	    			new ConteudoPdf().execute(getParams());
	    		} else {
	    			wiMap.put("tmp.doc_filter", "padrao");
	    			new DocToHtml().execute(getParams());
	    		}
			} 
    		Function.removeDir(loteDir.getAbsolutePath());
    		String delete = "delete from tb_cont_lote where id_cont_lote = ?|tmp.obj.id_cont_lote|";
    		dh.executeUpdate(delete, wiMap);
    		wiMap.remove("tmp.obj.id_cont_lote");
    		wiMap.put("tmp.obj.id_edicao", fkEdicao);
    		wiMap.put("tmp.message", "Lote Processado com Sucesso");
			ShowMessage.addMessage(wiMap, "cont_lote", "Processamento do Lote Finalizado");
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			ErrorLog errorLog = getParams().getErrorLog();
			if (errorLog != null) {
				errorLog.write(className, "Page: " + pageId, err);
			}
		}
	}
	
}
