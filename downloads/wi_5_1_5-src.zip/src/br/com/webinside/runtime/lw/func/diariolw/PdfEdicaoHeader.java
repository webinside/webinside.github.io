package br.com.webinside.runtime.lw.func.diariolw;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.itextpdf.awt.PdfGraphics2D;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfWriter;

import br.com.webinside.runtime.function.DateFormat;

public class PdfEdicaoHeader extends PdfPageEventHelper {

	private String type = null;
	private String lTitle = null;
	private String cTitle = null;
	private String rTitle = null;
	private boolean finalizar = false;
	private boolean frame = false;
	private BufferedImage imgLogo = null;
	private int numberOfPages = 0;
	
	public PdfEdicaoHeader(String type, File imgFile, 
			String lTitle, String cTitle, String rTitle, 
			boolean finalizar, boolean frame) {
		super();
		this.type = type;
		this.lTitle = lTitle;
		this.cTitle = cTitle;
		this.rTitle = rTitle;
		this.rTitle = rTitle;
		this.finalizar = finalizar;
		this.frame = frame;
		try {
			if (imgFile != null) {
				this.imgLogo = ImageIO.read(imgFile);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void onEndPage(PdfWriter writer, Document doc) {
		PdfContentByte cb = writer.getDirectContent();
		int page = writer.getPageNumber();
	    float w = doc.getPageSize().getWidth();
		float h = doc.getPageSize().getHeight();
		if (page > 1) {
			addHeader(page, cb, w, h);
		} else {
			int top = 158;
		    cb.moveTo(15, h - top);
		    cb.lineTo(15, 32);
		    cb.moveTo(w - 15, h - top);
		    cb.lineTo(w - 15, 32);
			cb.stroke();
		}
		addFooter(page, cb, w, h);				    
	}

	private void addHeader(int page, PdfContentByte cb, float w, float h) {
		// fundo branco
		cb.saveState();
		cb.setColorFill(BaseColor.WHITE);
		cb.rectangle(0, h-32, w, h);
		cb.rectangle(0, 0, w, 32);
		cb.fill();
		cb.restoreState();
		// gerando header
		int xlogo = 15;
		int x = (int)w - 20;
		Phrase pg = new Phrase(page + "", FontFactory.getFont("Arial", 14, Font.BOLD));
		ColumnText.showTextAligned(cb, Element.ALIGN_RIGHT, pg, x , h - 28, 0);
		Phrase p1 = new Phrase(lTitle, FontFactory.getFont("Arial", 8));
		ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, p1, 20 , h - 26, 0);
		Phrase p2 = new Phrase("Edi��o N� " + rTitle, FontFactory.getFont("Arial", 8));
		ColumnText.showTextAligned(cb, Element.ALIGN_RIGHT, p2, x - 26, h - 26, 0);
		/*
		if (page % 2 == 0) {
			xlogo = (int)w - 28;
			Phrase p1 = new Phrase(page + "", FontFactory.getFont("Arial", 12, Font.BOLD));
			ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, p1, 12 , h - 22, 0);
			Phrase p2 = new Phrase("Edi��o N� " + rTitle, FontFactory.getFont("Arial", 8));
			ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, p2, 60 , h - 22, 0);
			Phrase p3 = new Phrase(lTitle, FontFactory.getFont("Arial", 8));
			ColumnText.showTextAligned(cb, Element.ALIGN_RIGHT, p3, w - 32, h - 22, 0);
		} else {
		}
		*/
		Phrase pc1 = new Phrase(cTitle, FontFactory.getFont("Times New Roman", 14, Font.BOLD));
		ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, pc1, w/2 , h - 29, 0);
		if (type.equalsIgnoreCase("S")) {
			Phrase pc2 = new Phrase("SUPLEMENTO", FontFactory.getFont("Times New Roman", 9, Font.NORMAL));
			ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, pc2, w/2 - 100 , h - 27, 0);
			ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, pc2, w/2 + 100 , h - 27, 0);
		}
		if (type.equalsIgnoreCase("E")) {
			Phrase pc2 = new Phrase("EDI��O EXTRA", FontFactory.getFont("Times New Roman", 9, Font.NORMAL));
			ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, pc2, w/2 - 100 , h - 27, 0);
			ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, pc2, w/2 + 100 , h - 27, 0);
		}
		if (imgLogo != null) {
			PdfGraphics2D g2d = new PdfGraphics2D(cb, w, h);
			g2d.drawImage(imgLogo, xlogo, 9, null);
			g2d.dispose(); 			
		}
	    cb.moveTo(15, h - 15);
	    cb.lineTo(w - 15, h - 15);
	    cb.moveTo(15, h - 32);
	    cb.lineTo(w - 15, h - 32);
	    cb.moveTo(15, h - 32);
	    cb.lineTo(15, 32);
	    cb.moveTo(w - 15, h - 32);
	    cb.lineTo(w - 15, 32);
		cb.stroke();
	}

	private void addFooter(int page, PdfContentByte cb, float w, float h) {
		if (frame) {
		    cb.lineTo(w - 15, 25);
		    cb.lineTo(15, 25);
		    cb.lineTo(15, h - 28);
		} else {
		    cb.moveTo(15, 32);
		    cb.lineTo(w-15, 32);
		    cb.moveTo(15, 15);
		    cb.lineTo(w-15, 15);
		}
		cb.stroke();
		if (!finalizar) {
			Phrase p2 = new Phrase("Informa��es da assinatura eletr�nica", FontFactory.getFont("Arial", 10));
			ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, p2, w/2 - 20, 20, 0);
		}
	}
	
	public void execute(File pdfIn, File pdfOut) throws Exception {
		FileOutputStream fout = new FileOutputStream(pdfOut);
		FileInputStream fin = new FileInputStream(pdfIn);
	    PdfReader reader = new PdfReader(fin);
	    Document doc = new Document(PageSize.A4, 0, 0, 0, 0);
		PdfWriter writer = PdfWriter.getInstance(doc, fout);
		writer.setPageEvent(this);
		doc.open();
	    PdfContentByte cb = writer.getDirectContent();
	    numberOfPages = reader.getNumberOfPages();
	    for (int i = 1; i <= numberOfPages; i++) {
	        PdfImportedPage page = writer.getImportedPage(reader, i);
	        doc.setPageSize(new Rectangle(page.getWidth(),page.getHeight(),page.getRotation()));
			doc.newPage();
		    cb.addTemplate(page, 0, 0);
	    }
		doc.close();
		reader.close();
		fin.close();
		fout.close();
	}
	
	public static void main(String[] args) throws Exception {
		File pdfIn = new File("/temp/diario_parcial.pdf");
		File pdfOut = new File(pdfIn.getAbsolutePath().replace(".pdf", "_full.pdf"));
		File img = new File("/Tomcats/Tomcat9-wi5/webapps/diariolw/images/diario/brasao_aracaju_mini.png");
		String[] df_args = {"2023-04-28", "ext4"};
		String ltitle = "Aracaju(SE), " + new DateFormat().execute(df_args);
		String ctitle = "DI�RIO OFICIAL";
		String rtitle = "5115";		
		PdfEdicaoHeader header = new PdfEdicaoHeader("S",img,ltitle,ctitle,rtitle,true,true);
		header.execute(pdfIn, pdfOut);
	}
	
}
