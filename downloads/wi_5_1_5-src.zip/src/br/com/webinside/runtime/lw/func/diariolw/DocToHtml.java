package br.com.webinside.runtime.lw.func.diariolw;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Base64;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.w3c.css.sac.InputSource;
import org.w3c.dom.css.CSSStyleDeclaration;

import com.steadystate.css.parser.CSSOMParser;
import com.steadystate.css.parser.SACParserCSS3;

import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.function.TextFormat;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.CmdUtil;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class DocToHtml extends AbstractConnector implements InterfaceParameters {
		
    Map<String,String> imgMap = new HashMap();
	
	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			boolean useGS = false;
			String ext = "";
			String uplFolder = wiMap.get("pvt.lwpath.priv") + "/diario/documento";
			FileFilter fileFilter = new WildcardFileFilter("doc-" + wiMap.get("tmp.obj.id_conteudo") + ".*");
			File[] docFiles = new File(uplFolder).listFiles(fileFilter);
			Arrays.sort(docFiles, Comparator.comparingLong(File::lastModified).reversed());
			String doc = docFiles[0].getName();
			if (!doc.equals("")) {
				if (doc.toLowerCase().endsWith(".pdf")) {
					useGS = wiMap.get("tmp.pdf_converter").equals("GS");
					ext = "pdf";
				}
				if (doc.toLowerCase().endsWith(".docx")) ext = "docx";
				if (doc.toLowerCase().endsWith(".doc")) ext = "doc";
				if (doc.toLowerCase().endsWith(".odt")) ext = "odt";
				if (doc.toLowerCase().endsWith(".rtf")) ext = "rtf";
			}
			if (!ext.equals("")) {
				String tmpFolder = Function.rndTmpFolder("doc");
				new File(tmpFolder).mkdirs();
		        String mytemp =  tmpFolder + "/file." + ext;
            	FileUtils.copyFile(new File(uplFolder, doc), new File(mytemp));
		        File mytempFile = new File(mytemp); 
		        File mytempHtml = new File(mytemp.replace("." + ext, ".html"));
		        if (useGS) {
		        	List<String> cmd = CmdUtil.cmdGsPdfToTxt(mytempFile.getName());
					CmdUtil.execute(mytempFile.getParent(), cmd);
			        new File(mytemp.replace(".pdf", ".txt")).renameTo(mytempHtml);					
		        } else {
					List<String> cmd = CmdUtil.cmdConvertFile(mytempFile.getName(),"html");
					CmdUtil.execute(mytempFile.getParent(), cmd);
					File[] files = mytempFile.getParentFile().listFiles();
					for (File file : files) {
						String name = file.getName();
						if (!name.endsWith(".png") && !name.endsWith(".jpg")) continue;
						byte[] bytes = Files.readAllBytes(file.toPath()); 
						imgMap.put(file.getName(), Base64.getEncoder().encodeToString(bytes));
					}
		        }
				String html = "";
				if (useGS) {
			        List<String> text = Files.readAllLines(mytempHtml.toPath(), StandardCharsets.UTF_8);
			        for (String line : text) {
			        	line = "<p>"+line.trim()+"</p>";
			        	html += line.trim();
					}
				} else {
					Document jdoc = Jsoup.parse(mytempHtml, "UTF-8");	
					Element body = jdoc.getElementsByTag("body").first();
					String filter = wiMap.get("tmp.doc_filter").toLowerCase().trim();
					if (filter.trim().equals("")) filter = "preservar";
					filtroPadrao(body, filter);		
					if (filter.equals("segov")) {
						filtroSEGOV(body);
					}
					if (wiMap.get("tmp.doc_tb_compact").equals("1")) {
						tableCompact(body);
					}
					html = body.html();
					html = TextFormat.wordFilter(html);
				}
				wiMap.put("tmp.obj.tx_conteudo", html);
				String update = "update tb_conteudo ";
				update += "set tx_conteudo = ?|tmp.obj.tx_conteudo| ";
				update += "where id_conteudo = ?|tmp.obj.id_conteudo|";
				dh.executeUpdate(update, wiMap);
		        Function.removeDir(tmpFolder);
			}
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}

	private void filtroPadrao(Element body, String filter) {
		boolean normalize = filter.equals("normalizar") || filter.equals("segov");
		Elements eleList = body.getAllElements();
		List<String> tagDel = Arrays.asList("meta", "title", "style", "sdfield", "colgroup");
		for (Element ele : eleList) {
			if (tagDel.contains(ele.tagName().toLowerCase())) remove(ele);
			ele.removeAttr("title");
			ele.removeAttr("lang");
			ele.removeAttr("class");
			ele.removeAttr("width");
		}
		eleList = body.getAllElements();
		for (Element ele : eleList) {
			if (ele.hasAttr("style")) {
				String[] props = ele.attr("style").split(";");
				ele.removeAttr("style");
				for (String aux : props) {
					if (aux.trim().equals("")) continue;
					List<String> cssDel = Arrays.asList("so-language", "direction",
							"line-height", "orphans", "widows");					
					String[] prop = aux.split(":");
					if (prop[1].trim().startsWith("-")) continue; // negativo
					if (cssDel.contains(prop[0].trim().toLowerCase())) continue;
					if (prop[0].trim().startsWith("page-break")) continue;
					if (prop[0].trim().equals("font-family")) continue;
					if (prop[0].trim().startsWith("padding")) continue;
					if (prop[0].trim().equals("margin-left")) {
						prop[1] = "50%"; 
					} else if (prop[0].trim().startsWith("margin")) continue;
					if (normalize) {
						if (prop[0].trim().startsWith("font")) continue;
					} else {
						if (prop[0].trim().equals("font-size") 
								&& prop[1].trim().endsWith("pt")) {
							prop[1] = prop[1].replace("pt", "px");
						}
					}
					addStyle(ele, prop[0], prop[1]);
				}
			}
			if (ele.tagName().equals("p")) {
				if (ele.hasAttr("align")) {
					addStyle(ele, "text-align", ele.attr("align"));
					ele.removeAttr("align");
				}
				String content = ele.html();
				if (content.trim().equals("")) remove(ele);
			}
			if (ele.tagName().equals("font")) {
				if (ele.text().trim().equals("")) remove(ele);
				if (normalize) {
					if (!hasParent(ele, "table") || filter.equals("segov")) {
						ele.removeAttr("face");
					}
				}
				ele.removeAttr("size");
			}
			if (ele.tagName().equals("img")) {
				String key = ele.attr("src");
				String type = key.substring(key.lastIndexOf(".") + 1,key.length()); 
				String b64 = imgMap.get(key);
				ele.attr("src", "data:image/" + type + ";base64," + b64);
			}
			if (ele.tagName().equals("table")) {
				if (!ele.hasAttr("align")) ele.attr("align", "center");
				ele.attr("cellpadding", "2");
				addStyle(ele, "border-collapse", "collapse");
			}
			if (ele.tagName().equals("td")) {
				if (ele.html().trim().equals("")) ele.text("&nbsp;");
			}
			List<String> emptyTagDel = Arrays.asList("a", "div");
			if (emptyTagDel.contains(ele.tagName())) {
				if (ele.html().trim().equals("")) remove(ele);
			}	
			if (ele.attr("style").trim().equals("")) ele.removeAttr("style");
		}
	}
		
	private void filtroSEGOV(Element body) {
		Elements eleList = body.getElementsByTag("img");
		if (eleList != null && eleList.size() > 0) {
			Element img = eleList.get(0);
			img.attr("style","height:60px");
			img.removeAttr("align");
			Element p = new Element("p");
			p.attr("style","text-align:center");
			p.appendChild(img);
			body.prependChild(p);
		}
		Elements tdList = body.getElementsByTag("td");
		for (Element td : tdList) {
			Element ele = td.children().first();
			if (!ele.html().trim().equals("<br>")) {
				ele.getElementsByTag("br").remove();
				body.appendChild(ele);
				Element pEle = new Element("p");
				pEle.html("&nbsp;");
				body.appendChild(pEle);
			}
		}
		body.getElementsByTag("table").remove();
		Elements pList = body.getElementsByTag("p");
		if (pList.size() < 12) return;
		Element ele5 = pList.get(5);
		if (ele5.text().toLowerCase().indexOf("portaria") > -1) {
			String text = ele5.text() + " " + pList.get(7).text() + " / " + pList.get(11).text();
			ele5.getElementsByTag("b").first().text(text);
			for (int i = 6; i <= 11; i++) {
				pList.get(i).remove();
			}
			pList.get(15).attr("style", "margin-left:50%");
		}
		Element ele11 = pList.get(11);
		if (ele11.text().toLowerCase().indexOf("portaria") > -1) {
			String text = ele11.text() + " " + pList.get(5).text() + " / " + pList.get(9).text();
			ele11.getElementsByTag("b").first().text(text);
			for (int i = 5; i <= 10; i++) {
				pList.get(i).remove();
			}
			pList.get(15).attr("style", "margin-left:50%");
		}
		if (pList.get(3).text().toLowerCase().indexOf("decreto") > -1) {
			pList.get(7).attr("style", "margin-left:50%");
		}
	}
	
	private void tableCompact(Element body) {
		Elements eleList = body.getElementsByTag("table");
		for (Element ele : eleList) {
			ele.addClass("compacto");
		}
	}

	private boolean hasParent(Element ele, String tag) {
		Element parent = ele.parent();
		if (parent != null) {
			if (parent.tagName().equalsIgnoreCase(tag)) return true;
			return hasParent(parent, tag);
		}
		return false;
	}

	@SuppressWarnings("unused")
	private CSSStyleDeclaration parseStyle(String style) throws IOException {
		InputSource source = new InputSource(new StringReader(style));
		CSSOMParser parser = new CSSOMParser(new SACParserCSS3());
		return parser.parseStyleDeclaration(source);
	}
	
	private void addStyle(Element ele, String key, String value) {
		String style = ele.attr("style");
		if (!style.trim().equals("") && !style.trim().endsWith(";")) {
			style += "; ";
		}
		style += key + ": " + value;
		ele.attr("style", style);
	}
	
	private void remove(Element ele) {
		Element parent = ele.parent();
		ele.remove();
		if (parent != null && parent.html().trim().equals("")) {
			remove(parent);
		}
	}
	
	@Override
	public JavaParameter[] getInputParameters() {
		JavaParameter[] params = new JavaParameter[2];
		params[0] = new JavaParameter("tmp.doc_filter","Filtro (padrao/preservar,normalizar,segov)");
		params[1] = new JavaParameter("tmp.doc_tb_compact","Compactar tabelas (usar 1)");
		return params;
	}

	@Override
	public JavaParameter[] getOutputParameters() {
		return null;
	}

	@Override
	public boolean exit() {
		return false;
	}

}
