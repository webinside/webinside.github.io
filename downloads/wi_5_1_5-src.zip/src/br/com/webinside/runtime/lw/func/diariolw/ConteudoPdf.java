/*
 * WEBINSIDE - Ferramenta de produtividade Java
 * Copyright (c) 2011-2012 LINEWEB Solu��es Tecnol�gicas Ltda.
 * Copyright (c) 2009-2010 Inc�gnita Intelig�ncia Digital Ltda.
 *
 * Este programa � software livre; voc� pode redistribu�-lo e/ou modific�-lo 
 * sob os termos da GNU LESSER GENERAL PUBLIC LICENSE (LGPL) conforme publicada 
 * pela Free Software Foundation; vers�o 2.1 da Licen�a.
 * Este programa � distribu�do na expectativa de que seja �til, por�m, SEM 
 * NENHUMA GARANTIA; nem mesmo a garantia impl�cita de COMERCIABILIDADE OU 
 * ADEQUA��O A UMA FINALIDADE ESPEC�FICA.
 * 
 * Consulte a GNU LGPL para mais detalhes.
 * Voc� deve ter recebido uma c�pia da GNU LGPL junto com este programa; se n�o, 
 * veja em http://www.gnu.org/licenses/ 
 */

package br.com.webinside.runtime.lw.func.diariolw;

import java.io.File;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.Splitter;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.lw.img.ImgEnum;
import br.com.webinside.runtime.lw.img.ImgUtil;
import br.com.webinside.runtime.lw.img.TrimType;
import br.com.webinside.runtime.lw.sql.Persist;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;

public class ConteudoPdf extends AbstractConnector implements InterfaceParameters {

	private static final int SIZE_PDF_GRANDE = 50;
	
	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String tmpFolder = Function.rndTmpFolder("pdf");
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			String idCont = wiMap.get("tmp.diario.id_conteudo").trim();
			String pdfFolder = wiMap.get("pvt.lwpath.priv") + "/diario/documento";
			String pdfFile = pdfFolder + "/doc-" + idCont + ".pdf";
			ShowMessage.addMessage(wiMap, "conteudo", "Particionando PDF");
			int pages = splitPdf(pdfFile, tmpFolder);
			wiMap.put("tmp.obj.nr_pag_pdf", pages + "");
			wiMap.put("tmp.obj.st_pdf_grande", (pages >= SIZE_PDF_GRANDE) ? "1" : "0");
			String query = "select ts_cont_key from tb_conteudo";
			query += " where id_conteudo = ?|tmp.diario.id_conteudo|";
			ResultSet rsKey = dh.execute(query, wiMap);
			String contKey = rsKey.columnNext(1);
			boolean trim = wiMap.get("tmp.autocrop").equals("1");
			extrairImages(wiMap, tmpFolder, idCont, contKey, trim);
			String update = "update tb_conteudo ";
			update += "set nr_pag_pdf = ?|tmp.obj.nr_pag_pdf|, st_pdf_grande = |tmp.obj.st_pdf_grande| ";
			update += "where id_conteudo = ?|tmp.diario.id_conteudo|";
			dh.executeUpdate(update, wiMap);
			dh.executeUpdate("delete from tb_conteudo_img "
					+ "where id_conteudo = ?|tmp.diario.id_conteudo|", wiMap);
			for (int i=1;i<=pages;i++) {
				wiMap.put("tmp.persist.database", "diariolw");
				wiMap.put("tmp.persist.table", "tb_conteudo_img");
				wiMap.put("tmp.persist.object", "tmp.obj");
				wiMap.put("tmp.obj.id_img_seq", i + "");
				String imgCols = "2";
				String tamPerc = "100";
				if (wiMap.get("tmp.obj.st_pdf_grande").equals("1")) {
					imgCols = "1";
					tamPerc = "97";
					if (i == pages) tamPerc = "95";
				}
				wiMap.put("tmp.obj.nr_img_cols", imgCols);
				wiMap.put("tmp.obj.nr_tam_perc", tamPerc);
				wiMap.put("tmp.obj.st_quebra_pag", "0");
				new Persist().execute(getParams());
			}
			ShowMessage.addMessage(wiMap, "conteudo", "Processamento Finalizado");
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		} finally {
			Function.removeDir(tmpFolder);
		}
	}
	
	private int splitPdf(String pdfFile, String tmpFolder) throws Exception {
		int pages = 0, index  = 0;
		new File(tmpFolder).mkdirs();
		PDDocument doc = PDDocument.load(new File(pdfFile));
		pages = doc.getNumberOfPages();
		Splitter splitter = new Splitter();
		splitter.setStartPage(1);
		splitter.setEndPage(pages);
		splitter.setSplitAtPage(10);
		List<PDDocument> list = splitter.split(doc);
		for (PDDocument part : list) {
			File f = new File(tmpFolder, "file-" + index + ".pdf");
			part.save(f);
			part.close();
			index++;
		}
		doc.close();
		return pages;
	}
	
	public void extrairImages(WIMap wiMap, String tmpFolder, String idCont, String contKey, boolean trim)
			throws Exception {
		String fldKey = "c" + idCont + "-" + contKey;
		String imgFolder = wiMap.get("pvt.lwpath.pub") + "/diario/doc-img/" + fldKey;
		new File(imgFolder).mkdirs();
		Function.removeFiles(imgFolder, "*.png");
		int pages = Integer.parseInt(wiMap.get("tmp.obj.nr_pag_pdf"));
		for (int index = 0; index < 9999; index++) {
			File file = new File(tmpFolder, "file-" + index + ".pdf");
			if (!file.isFile()) break;
			int max = (10 + index*10);
			int min = (max - 10 + 1);
			if (max > pages) max = pages;
			String msg =  min + " a " + max + " de " + pages + " p�ginas";
			ShowMessage.addMessage(wiMap, "conteudo", "Processando de " + msg);
			String contLoteSeq = wiMap.get("tmp.cont_lote_seq");
			if (!contLoteSeq.equals("")) {
				ShowMessage.addMessage(wiMap, "cont_lote", "Processando Lote Seq. " + contLoteSeq + " - " + msg);
			}
			TrimType trimType = trim ? TrimType.BORDER10 : null;
			List<String> cmd = ImgUtil.cmdPdfToImg("", ImgEnum.PNG_COLOR, 125, "", trimType);
			ImgUtil.execute(cmd, tmpFolder, "file-" + index, "pg", false);
			File single = new File(tmpFolder, "pg.png");
			if (single.isFile()) single.renameTo(new File(tmpFolder, "pg-0.png"));
	        String[] files = Function.listDir(tmpFolder, "*.png", false, false);
			for (int i = 0; i < files.length; i++) {
				String seq = files[i];
				seq = seq.substring(seq.indexOf("-") + 1);
				seq = seq.substring(0, seq.indexOf("."));
				int seq2 = Integer.parseInt(seq) + index*10;
	        	File srcFile = new File(tmpFolder, files[i]);
	        	File destFile = new File(imgFolder, "pg-" + seq2 + ".png");
	        	srcFile.renameTo(destFile);
	        }
		}
	}
				
	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[1];
		in[0] = new JavaParameter("tmp.diario.id_conteudo", "ID do Conte�do");
		return in;
	}

	public JavaParameter[] getOutputParameters() {
		return new JavaParameter[0];
	}

}
