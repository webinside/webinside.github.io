package br.com.webinside.runtime.lw.func.diariolw;

import java.io.File;

import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.net.FileUpload;
import br.com.webinside.runtime.util.ErrorLog;
import br.com.webinside.runtime.util.WIMap;

public class UpdateEdicaoConnector extends AbstractConnector {
	
	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers)
			throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";     
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
	    	String priv = wiMap.get("pvt.lwpath.priv");
    		String idEdicao = wiMap.get("tmp.obj.id_edicao");
    		String nrEdicao = wiMap.get("tmp.obj.nr_edicao");
    		String tpEdicao = wiMap.get("tmp.obj.tp_edicao");
	    	File destFile = new File(priv, "/diario/concluido/" + nrEdicao + tpEdicao + ".pdf");
	    	if (destFile.isFile()) {
	    		FileUpload fileUpload = getParams().getFileUpload();
		        boolean ok = fileUpload.saveFile("tmp.upd_pdf", destFile.getAbsolutePath());
		        if (ok) {
		        	File pdfFile = new PdfEdicao().createHeader(wiMap, destFile, true);
		        	pdfFile = new PdfEdicao().createSumario(dh, wiMap, pdfFile);
			        if (pdfFile.isFile()) {
			        	destFile.delete();
			        	pdfFile.renameTo(destFile);
			        }
			        getParams().getWIMap().put("tmp.id_edicao", idEdicao);
			        new LocalizaConteudo().execute(getParams());
			        String update = "update tb_edicao set tp_ocr_status = '' "
			        		+ "where id_edicao = ?|tmp.obj.id_edicao|";			        
			        dh.executeUpdate(update, wiMap);
		        	wiMap.put("tmp.msg_success", "PDF da Edi��o atualizado com sucesso");
		        }
	    	}
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			ErrorLog errorLog = getParams().getErrorLog();
			if (errorLog != null) {
				errorLog.write(className, "Page: " + pageId, err);
			}
		}
	}
	
}
