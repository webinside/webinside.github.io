package br.com.webinside.runtime.lw.func.diariolw;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfAction;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfDestination;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.draw.DottedLineSeparator;

import br.com.webinside.runtime.core.RtmExport;
import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.function.DateFormat;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.CmdUtil;
import br.com.webinside.runtime.util.ErrorLog;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.StringA;
import br.com.webinside.runtime.util.WIMap;

public class PdfEdicao extends AbstractConnector implements InterfaceParameters {
	
	private boolean exit = true;
		
	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				ErrorLog errorLog = getParams().getErrorLog();
				errorLog.write(getClass().getName(), "Page: " + pageId, msg);
				return;
			}
			String tmpFolder = Function.rndTmpFolder("pdf");
			new File(tmpFolder).mkdirs();
			ShowMessage.addMessage(wiMap, "pdf", "Gerando HTML");
			File htmlFile = new File(tmpFolder + "/lwdiario.html");
	        PrintWriter pw = new PrintWriter(htmlFile);
	        new HtmlEdicao().makeHtml(pw, dh, wiMap);
			pw.close();
			boolean finalizar = wiMap.get("tmp.pdf_type").trim().equalsIgnoreCase("finalizar");
			boolean incompleta = wiMap.get("tmp.obj.st_incompleta").equals("1");
			ShowMessage.addMessage(wiMap, "pdf", "Processando PDF (Chrome)", true);
			File pdfFile = new File(htmlFile.getAbsolutePath().replace(".html", ".pdf"));
			String url = "file://" + htmlFile.getAbsolutePath();
			try {
				CmdUtil.execute(tmpFolder, CmdUtil.cmdChromeToPdf(url, pdfFile.getAbsolutePath()));
				if (!(finalizar && incompleta)) {
			    	pdfFile = createHeader(wiMap, pdfFile, finalizar);
					pdfFile = createSumario(dh, wiMap, pdfFile);
				}
				ShowMessage.addMessage(wiMap, "pdf", "PDF gerado com sucesso");
			} catch (Exception err) {
				erroGerar(err, wiMap);
				String errorType = incompleta ? "msg_alert" : "msg_error";
				wiMap.put("tmp." + errorType, "Erro ao gerar o pdf da edi��o fechada");
				Function.removeDir(tmpFolder);
				exit = false;
				return;
			}
	    	if (finalizar) {
	    		String nrEdicao = wiMap.get("tmp.obj.nr_edicao");
	    		String tpEdicao = wiMap.get("tmp.obj.tp_edicao");
		    	String priv = wiMap.get("pvt.lwpath.priv");
		    	File destFile = new File(priv, "/diario/concluido/" + nrEdicao + tpEdicao + ".pdf");
		    	destFile.getParentFile().mkdirs();
    			FileUtils.copyFile(pdfFile, destFile);
				Function.removeDir(tmpFolder);
				exit = false;
				return;
	    	}
			HttpServletResponse response = getParams().getHttpResponse();
			response.setContentType("application/pdf");
			response.setHeader("Content-disposition", "inline; filename=\"diario.pdf\"");
			response.setContentLength((int) pdfFile.length());
			try {
				response.flushBuffer();
			} catch (IOException err) {}  
			new RtmExport(getParams()).sendFile(wiMap, pdfFile.getAbsolutePath(), false);
			Function.removeDir(tmpFolder);
		} catch (Exception err) {
			erroGerar(err, wiMap);
		}
	}
	
	private void erroGerar(Exception err, WIMap wiMap) {
		String pageId = wiMap.get("wi.page.id");
		getParams().getErrorLog().write(getClass().getName(), "Page: " + pageId, err);
		ShowMessage.addMessage(wiMap, "pdf", "Erro ao gerar PDF");
	}
			
	public File createSumario(DatabaseHandler dh, WIMap wiMap, File pdfIn) throws Exception  {
		File pdfOut = new File(pdfIn.getAbsolutePath().replace(".pdf", "_sumario.pdf"));
		ContPosCore contPosCore = new ContPosCore(); 
    	contPosCore.makeList(dh, wiMap.get("tmp.obj.id_edicao"), pdfIn);
		FileOutputStream fout = new FileOutputStream(pdfOut);
		FileInputStream fin = new FileInputStream(pdfIn);
	    PdfReader reader = new PdfReader(fin);
        PdfStamper stamper = new PdfStamper(reader, fout);
        createSumarioPdf(dh, wiMap, stamper, contPosCore);
        createSumarioCapa(dh, wiMap, stamper, contPosCore);
        stamper.close();
        reader.close();
		fin.close();
		fout.close();
		return pdfOut;
	}

	private void createSumarioPdf(DatabaseHandler dh, WIMap wiMap, PdfStamper stamper, ContPosCore contPosCore)
			throws Exception {
        ArrayList<HashMap<String, Object>> bookmarks = new ArrayList<>();
        HashMap<String, Object> compObj = new HashMap<>();
        compObj.put("Title", "Capa - Composi��o");
        compObj.put("Action", "GoTo");
        compObj.put("Page", "1");
        compObj.put("Style", "bold");
        //compObj.put("Color", "1 0 0");
        bookmarks.add(compObj);
		String mainUnid = "";
        ArrayList<HashMap<String, Object>> contList = new ArrayList<>();
		String query = "select * from vw_conteudo where fk_edicao = ?|tmp.obj.id_edicao|";
		ResultSet rs = dh.execute(query, wiMap);
		while (rs.next() > 0) {
			String id = rs.column("id_conteudo"); 
			String unid = rs.column("ts_unidade"); 
			ContPosBean bean = contPosCore.findById(id);
			if (!mainUnid.equals(unid)) {
				contList = new ArrayList<>();
				HashMap<String, Object> unidObj = new HashMap<>();
		        unidObj.put("Title", unid);
		        unidObj.put("Action", "GoTo");
		        if (bean != null) {
			        unidObj.put("Page", bean.getPgIni() + "");
		        }
		        unidObj.put("Style", "bold");
		        unidObj.put("Kids", contList);
		        bookmarks.add(unidObj);
				mainUnid = unid;
			}
			String cont = rs.column("ts_conteudo");
			String cad = rs.column("ts_caderno").trim();
			String cadAux = StringA.piece(cad, " ", 1); 
			if (cadAux.toUpperCase().endsWith("S")) {
				cad = cad.replace(cadAux, cadAux.substring(0, cadAux.length() - 1));
			}
			String dat = rs.column("dd_conteudo");
			String ano = rs.column("nr_cont_ano");
			String num = rs.column("nr_conteudo");
			if (!dat.equals("")) {
				cont = cad + " - " + dat;
			} else if (!ano.equals("")) {
				cont = cad + " - " + num + " / " + ano;
			} else if (!num.equals("")) {
				cont = cad + " - " + num;
			}
	        HashMap<String, Object> contObj = new HashMap<>();
	        contObj.put("Title", cont);
	        contObj.put("Action", "GoTo");
	        if (bean != null) {
	        	contObj.put("Page", bean.getPgIni() + "");
	        }
	        contList.add(contObj);
		}
		stamper.setOutlines(bookmarks);
	}

	private void createSumarioCapa(DatabaseHandler dh, WIMap wiMap, PdfStamper stamper, ContPosCore contPosCore)
			throws Exception {
		float top = 0; 
		float gap = 10;
		float bx = 305;
		float by = 200;
		float tx = 573;
		float ty = 650;
		BaseFont bf = BaseFont.createFont(BaseFont.TIMES_BOLD, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
		Font font = new Font(bf, 8);
		String mainUnid = "";
		String query = "select * from vw_conteudo where fk_edicao = ?|tmp.obj.id_edicao|";
		ResultSet rs = dh.execute(query, wiMap);
		while (rs.next() > 0) {
			float h = 10;
			String unid = rs.column("ts_unidade");
			if (unid.length() > 70) h = h * 2;
			if (!mainUnid.equals(unid)) {
				if (top > 0) top = top + gap;
				String id = rs.column("id_conteudo");
				ContPosBean bean = contPosCore.findById(id);
				if ((ty - h) > by) { 
					Rectangle rect = new Rectangle(bx + 5, ty - top - h, tx - 5, ty - top);
					if (false) {
						rect.setBackgroundColor(BaseColor.YELLOW);
						rect.setBorderColor(BaseColor.RED);
						rect.setBorder(Rectangle.BOX);
						rect.setBorderWidth(1);
						PdfContentByte canvas = stamper.getOverContent(1);
						canvas.saveState();
						canvas.setColorFill(BaseColor.YELLOW);
						canvas.rectangle(rect);
						canvas.fill();
						canvas.restoreState();
					}
					Paragraph p = new Paragraph(unid);
					p.setFont(font);
					p.setLeading(8);
				    Chunk tab = new Chunk(new DottedLineSeparator());
				    p.add(tab);
				    DecimalFormat df = new DecimalFormat("000");
					Chunk chunk = new Chunk(df.format(bean.getPgIni()));
					chunk.getFont().setColor(BaseColor.BLUE);
					int pgIni = bean.getPgIni();
					if (pgIni == 0) pgIni = 1;
					PdfAction action = PdfAction.gotoLocalPage(pgIni, new PdfDestination(0), stamper.getWriter());
					chunk.setAction(action);
					p.add(chunk);
					ColumnText ct = new ColumnText(stamper.getOverContent(1));
					ct.setLeading(0);
					ct.setSimpleColumn(rect);
					ct.addElement(p);
					ct.go();
					top = top + h;
				}
				mainUnid = unid;
			}
		}
	}
	
	public File createHeader(WIMap wiMap, File pdfIn, boolean finalizar) throws Exception  {
		File pdfOut = new File(pdfIn.getAbsolutePath().replace(".pdf", "_header.pdf"));
		String[] df_args = {wiMap.get("tmp.obj.dd_edicao"), "ext4"};
		String ltitle = "Aracaju(SE), " + new DateFormat().execute(df_args);
		String ctitle = "DI�RIO OFICIAL";
		String rtitle = wiMap.get("tmp.obj.nr_edicao");		
		String type = wiMap.get("tmp.obj.tp_edicao");
		PdfEdicaoHeader header = new PdfEdicaoHeader(type,null,ltitle,ctitle,rtitle,finalizar,false);
		header.execute(pdfIn, pdfOut);
		return pdfOut;
	}
	
	@Override
	public JavaParameter[] getInputParameters() {
		JavaParameter[] params = new JavaParameter[1];
		params[0] = new JavaParameter("tmp.pdf_type", "Tipo (Finalizar)");
		return params;
	}

	@Override
	public JavaParameter[] getOutputParameters() {
		return null;
	}

	@Override
	public boolean exit() {
		return exit;
	}
	
}
