package br.com.webinside.runtime.lw.func.ged;

import java.util.HashMap;
import java.util.Map;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRXmlDataSource;

public class NFeToPdf {
	
	public static void main(String[] args) throws Exception {
		System.out.println("Iniciado");
		String dir = "/temp/nfe-jasper";
		String report = "retrato";
        JasperCompileManager.compileReportToFile(dir + "/" + report + ".jrxml", dir + "/" + report + ".jasper");
		new NFeToPdf().execute(dir, report);
		System.out.println("Terminado");
	}
	
	public void execute(String dir, String report) throws Exception {
        JRXmlDataSource xml = new JRXmlDataSource(dir + "/nfe.xml", "/nfeProc/NFe/infNFe/det");  
		Map param = new HashMap();
		param.put("Logo", dir + "/logo.png");
        JasperPrint jp = JasperFillManager.fillReport(dir + "/" + report + ".jasper", param, xml);
        JasperExportManager.exportReportToPdfFile(jp, dir + "/nfe.pdf");  
//      chave = /nfeProc/protNFe/infProt/chNFe        
// 		protocolo = /nfeProc/protNFe/infProt/nProt        
	}

}
