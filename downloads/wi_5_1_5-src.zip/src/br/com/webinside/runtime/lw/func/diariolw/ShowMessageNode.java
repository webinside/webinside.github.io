package br.com.webinside.runtime.lw.func.diariolw;

import java.io.Serializable;
import java.util.Date;

public class ShowMessageNode implements Serializable {

	private static final long serialVersionUID = 1L;

	private String message = "";	
	private long initTime = 0;

	public ShowMessageNode(String message, boolean useTime) {
		this.message = message;
		if (useTime) initTime = new Date().getTime();
	}

	public String getMessage() {
		String msg = message;
		if (initTime > 0) msg += " - " + getDuration();
		return msg;
	}
	
	public String getDuration() {
		if (initTime == 0) return "";
		long diff = new Date().getTime() - initTime;
		String p1 = String.format("%02d", diff / 1000 % 60);
		String p2 = String.format("%02d", diff / (60 * 1000) % 60);
		String p3 = String.format("%02d", diff / (60 * 60 * 1000) % 60);
		return p3 + ":" + p2 + ":" + p1;
	}
	
}
