package br.com.webinside.runtime.lw.func.diariolw;

import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;

import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.util.WIMap;

public class ShowMessage extends AbstractConnector {

	private static Map<String, MessageMap> sessionMessage = new HashMap<>(); 
	
	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		try {
			JSONObject json = new JSONObject();
			String sessionId = wiMap.get("wi.session.id");
			String key = wiMap.get("tmp.key");
			MessageMap message = sessionMessage.get(sessionId);
			if (message != null) {
				String msg = "Mensagem Vazia";
				if (key.equals("")) {
					msg = "Key not informed";
				} else if (message.containsKey(key)) {
					msg = message.get(key).getMessage();
				}
				json.put("message", msg);
			} else {
				json.put("message", "SessionId not found");
			}
			getParams().getWriter().print(json.toJSONString());
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}

	public static void addMessage(WIMap wiMap, String key, String text) {
		addMessage(wiMap, key, text, false);
	}
	
	public static void addMessage(WIMap wiMap, String key, String text, boolean time) {
		String sessionId = wiMap.get("wi.session.id");
		MessageMap message = sessionMessage.get(sessionId);
		if (message == null) {
			message = (new ShowMessage()).new MessageMap();
			sessionMessage.put(sessionId, message);
		}
		if (text != null && !text.trim().equals("")) {
			ShowMessageNode node = new ShowMessageNode(text, time);
			message.put(key, node);
		} else message.remove(key);
	}
	
	private class MessageMap extends HashMap<String, ShowMessageNode> {

		private static final long serialVersionUID = 1L;
		
	}

}
