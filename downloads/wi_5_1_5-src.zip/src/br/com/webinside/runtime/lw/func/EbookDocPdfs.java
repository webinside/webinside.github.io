/*
 * WEBINSIDE - Ferramenta de produtividade Java
 * Copyright (c) 2011-2012 LINEWEB Solu��es Tecnol�gicas Ltda.
 * Copyright (c) 2009-2010 Inc�gnita Intelig�ncia Digital Ltda.
 *
 * Este programa � software livre; voc� pode redistribu�-lo e/ou modific�-lo 
 * sob os termos da GNU LESSER GENERAL PUBLIC LICENSE (LGPL) conforme publicada 
 * pela Free Software Foundation; vers�o 2.1 da Licen�a.
 * Este programa � distribu�do na expectativa de que seja �til, por�m, SEM 
 * NENHUMA GARANTIA; nem mesmo a garantia impl�cita de COMERCIABILIDADE OU 
 * ADEQUA��O A UMA FINALIDADE ESPEC�FICA.
 * 
 * Consulte a GNU LGPL para mais detalhes.
 * Voc� deve ter recebido uma c�pia da GNU LGPL junto com este programa; se n�o, 
 * veja em http://www.gnu.org/licenses/ 
 */

package br.com.webinside.runtime.lw.func;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.FileIO;
import br.com.webinside.runtime.util.Function;
import br.com.webinside.runtime.util.WIMap;
import br.com.webinside.runtime.xml.Inputter;

import com.itextpdf.text.pdf.PdfReader;

public class EbookDocPdfs extends AbstractConnector implements InterfaceParameters {

	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "principal";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			String destFolder = wiMap.get("tmp.lwr.dest_folder");
			if (false) {
				new File(destFolder, "lwreader.xml").delete();
				Function.removeDir(destFolder + "/texts");
				Function.removeDir(destFolder + "/images");
			}
			if (new File(destFolder,"lwreader.xml").exists()) {
				return;
			}
			String query = "select a.id_arquivo from tb_ged_arquivo a " +
			"inner join tb_ged_versao_arquivo v on (v.id_arquivo = a.id_arquivo)" +
			"where id_versao = ?|tmp.lwr.id_versao| and ts_arq_ext = 'pdf'";
			ResultSet rs = dh.execute(query, wiMap);
			while (rs.next() > 0) {
				String idPdf = rs.column(1);
				wiMap.put("tmp.id_arquivo", idPdf);
				String pdfFolder = wiMap.get("pvt.lwpath.priv") + "/ged/arquivo";
				String pdfFile = pdfFolder + "/file-" + idPdf + ".pdf";
				doPdf(wiMap, destFolder, pdfFile);
			}
			joinXml(wiMap, destFolder);
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
	
	private void doPdf(WIMap wiMap, String destFolder, String pdfFile) throws Exception {
        PdfReader pdfReader = new PdfReader(pdfFile);
        int pages = pdfReader.getNumberOfPages();
		int pgW = Math.round(pdfReader.getCropBox(1).getWidth());
		int pgH = Math.round(pdfReader.getCropBox(1).getHeight());
		pdfReader.close();
		generateXml(wiMap, destFolder, pages, pgW, pgH);
		new File(destFolder + "/texts").mkdirs();
		new FileIO(destFolder + "/texts/index.txt", FileIO.WRITE).writeText("");
		new FileIO(destFolder + "/texts/empty.txt", FileIO.WRITE).writeText("");
/*		
		String rndKey = Function.randomKey().toLowerCase();
		String tmpFolder = Function.tmpDir() + "/pdf-" + rndKey;
        String tmpFile = tmpFolder + "/file.pdf";
        Function.copyFile(pdfFile, tmpFile, true);
        int arq = Integer.parseInt(wiMap.get("tmp.id_arquivo"));
        // img1
		List<String> cmd = ImgUtil.cmdPdfToImg("", ImgEnum.PNG_COLOR, "x150");
		ImgUtil.execute(cmd, tmpFolder, "file", "pg", false);
		copyImages(tmpFolder, destFolder, arq, 1);
        // img2
		cmd = ImgUtil.cmdPdfToImg("", ImgEnum.PNG_COLOR, "x900");
		ImgUtil.execute(cmd, tmpFolder, "file", "pg", false);
		copyImages(tmpFolder, destFolder, arq, 2);
        // img3
		cmd = ImgUtil.cmdPdfToImg("", ImgEnum.PNG_COLOR, "x1600");
		ImgUtil.execute(cmd, tmpFolder, "file", "pg", false);
		copyImages(tmpFolder, destFolder, arq, 3);
		Function.removeDir(tmpFolder);
*/		
	}
	
/*	
	private void copyImages(String tmpFolder, String destFolder, int arq, int index) {
		File single = new File(tmpFolder, "pg.png");
		if (single.isFile()) single.renameTo(new File(tmpFolder, "pg-0.png"));
        String[] files = Function.listDir(tmpFolder, "*.png", false, false);
		for (int i = 0; i < files.length; i++) {
        	String srcFile = tmpFolder + "/" + files[i];
        	String destFile = destFolder + "/images-" + arq + "/img" + index + "/" + files[i];
        	Function.copyFile(srcFile, destFile, true);
        }
		Function.removeFiles(tmpFolder, "*.png");
	}
*/
	
	public void generateXml(WIMap wiMap, String destFolder, int pgQtd, int pgW, int pgH) 
	throws IOException {
		String idDoc = wiMap.get("tmp.lwr.id_documento");
		String idPdf = wiMap.get("tmp.id_arquivo");
		Element rootEle = new Element("LWReader");
		Element docsEle = new Element("docs");
		rootEle.addContent(docsEle);
		Element docEle = new Element("doc");
		docEle.setAttribute("id", "doc01");
		docsEle.addContent(docEle);
		Element docTitleEle = new Element("title");
		docTitleEle.setText(wiMap.get("tmp.lwr.ebook_title"));
		docEle.addContent(docTitleEle);
		Element indexEle = new Element("index");
		indexEle.setText(wiMap.get("tmp.lwr.dest_url") + "/texts/index.txt");
		docEle.addContent(indexEle);
		Element pages = new Element("pages");
		docEle.addContent(pages);
		for (int c = 0; c < pgQtd; c++) {
			Element pageEle = new Element("page");
/*			
			if (pageData.getTitle() != null) {
				Element pageTitleEle = new Element("title");
				pageTitleEle.setText(pageData.getTitle());
				pageEle.addContent(pageTitleEle);
			}
*/			
			Element sizeEle = new Element("size");
			sizeEle.setText(pgW + "x" + pgH);
			pageEle.addContent(sizeEle);
			Element txtEle = new Element("text");
			txtEle.setText(wiMap.get("tmp.lwr.dest_url") + "/texts/empty.txt");
			pageEle.addContent(txtEle);
			pages.addContent(pageEle);
			for (int i = 1; i <= 3; i++) {
				Element imgEle = new Element("img" + i);
//				String imgName = "images-" + idPdf + "/img" + i + "/pg-" + c + ".png";
//				imgEle.setText(wiMap.get("tmp.lwr.dest_url") + "/" + imgName);
				String imgUrl = "/lwsolution/EbookServlet?tmp.doc=" + idDoc + "&tmp.arq=" + idPdf + "&tmp.tam=" + i + "&tmp.pag=" + c;
				imgEle.setText(imgUrl);
				pageEle.addContent(imgEle);
			}
		}
		new File(destFolder).mkdirs();
//		File jsFile = new File(wiMap.get("tmp.lwr.dest_folder"), "lwreader.js");
//		new FileIO(jsFile.getAbsolutePath(), 'W').writeText("var ebookPages = " + pgQtd);
		Document doc = new Document(rootEle);
		XMLOutputter out = new XMLOutputter();
		out.setFormat(defineXmlFormat(out.getFormat()));
		File xmlFile = new File(wiMap.get("tmp.lwr.dest_folder"), "lwreader-" + idPdf + ".xml");
		FileWriter fw = new FileWriter(xmlFile);
		out.output(doc, fw);
		fw.close();
	}

	public void joinXml(WIMap wiMap, String destFolder) throws IOException {
		Element rootEle = null;
		File folder = new File(destFolder);
		for (File file : folder.listFiles()) {
			if (file.getName().endsWith(".xml")) {
				Document doc = new Inputter().input(file);
				if (rootEle == null) {
					rootEle = doc.getRootElement();
					rootEle.detach();
				} else {
					Element srcPages = doc.getRootElement().getChild("docs").getChild("doc").getChild("pages");
					Element destPages = rootEle.getChild("docs").getChild("doc").getChild("pages");
					destPages.addContent(srcPages.removeContent());
				}
			}
		}
		Document doc = new Document(rootEle);
		XMLOutputter out = new XMLOutputter();
		out.setFormat(defineXmlFormat(out.getFormat()));
		File xmlFile = new File(destFolder, "lwreader.xml");
		FileWriter fw = new FileWriter(xmlFile);
		out.output(doc, fw);
		fw.close();
	}
	
	private Format defineXmlFormat(Format format) {
		format.setOmitDeclaration(false);
		format.setExpandEmptyElements(false);
		format.setEncoding("ISO-8859-1");
		format.setIndent("    ");
		format.setTextMode(Format.TextMode.TRIM_FULL_WHITE);
		return format;
	}
		
	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[5];
		in[0] = new JavaParameter("tmp.lwr.id_documento", "Id do Documento");
		in[1] = new JavaParameter("tmp.lwr.id_versao", "Id da Vers�o");
		in[2] = new JavaParameter("tmp.lwr.dest_folder", "Pasta Destino");
		in[3] = new JavaParameter("tmp.lwr.dest_url", "Url Destino");
		in[4] = new JavaParameter("tmp.lwr.ebook_title", "T�tulo do Ebook");
		return in;
	}

	public JavaParameter[] getOutputParameters() {
		return new JavaParameter[0];
	}
	
}
