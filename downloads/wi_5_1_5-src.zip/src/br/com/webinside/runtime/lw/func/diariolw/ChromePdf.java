package br.com.webinside.runtime.lw.func.diariolw;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import br.com.webinside.runtime.core.RtmExport;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.integration.InterfaceParameters;
import br.com.webinside.runtime.integration.JavaParameter;
import br.com.webinside.runtime.util.CmdUtil;
import br.com.webinside.runtime.util.WIMap;

public class ChromePdf extends AbstractConnector implements InterfaceParameters {
		
	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "principal";
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			String url = "http://localhost:8080/diariolw/publicar/criar_html.wsp";
//			String tmpPdf = Function.rndTmpFile("e", "pdf");
			String tmpPdf = "/temp/teste.pdf"; 
			File pdfFile = new File(tmpPdf);
			String folder = pdfFile.getParentFile().getAbsolutePath();
			CmdUtil.execute(folder, CmdUtil.cmdChromeToPdf(url, tmpPdf));
			HttpServletResponse response = getParams().getHttpResponse();
			response.setContentType("application/pdf");
			String dispname = "inline; filename=\"DiarioLW.pdf\"";
			response.setHeader("Content-disposition", dispname);
			response.setContentLength((int) pdfFile.length());
			try {
				response.flushBuffer();
			} catch (IOException err) {}  
			new RtmExport(getParams()).sendFile(wiMap, pdfFile.getAbsolutePath(), false);
			pdfFile.delete();
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
	
	@Override
	public boolean exit() {
		return true;
	}

	public JavaParameter[] getInputParameters() {
		JavaParameter[] in = new JavaParameter[1];
		in[0] = new JavaParameter("tmp.id_edicao", "ID Edicao");
		return in;
	}

	public JavaParameter[] getOutputParameters() {
		return new JavaParameter[0];
	}
	
}
