package br.com.webinside.runtime.lw.func.diariolw;

import java.io.File;

import javax.servlet.ServletContext;

import br.com.webinside.runtime.database.ResultSet;
import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.DatabaseHandler;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.util.ErrorLog;
import br.com.webinside.runtime.util.WIMap;

public class OcrConnector extends AbstractConnector {
	
	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, InterfaceHeaders headers)
			throws UserException {
		String className = getClass().getName();
		DatabaseHandler dh = null;
		try {
			String database = "diariolw";     
			dh = databases.get(database);
			if (dh == null) {
				String msg = "Get database error (" + database + ")";
				String pageId = wiMap.get("wi.page.id");
				getParams().getErrorLog().write(className, "Page: " + pageId, msg);
				return;
			}
			String query = "SELECT nr_edicao, tp_edicao, fn_tb_hash(ts_edi_key, 0) as hash"
					+ " FROM tb_edicao WHERE id_edicao = ?|tmp.obj.id_edicao|";
			ResultSet rs = dh.execute(query, wiMap);
			if (rs.next() > 0) {
		    	String priv = wiMap.get("pvt.lwpath.priv");
				String nrEdicao = rs.column("nr_edicao");
				String tpEdicao = rs.column("tp_edicao");
				String key = rs.column("hash");
		    	File pdfFile = new File(priv, "/diario/concluido/" + nrEdicao + tpEdicao + ".pdf");
		    	if (!pdfFile.isFile()) return;
		    	String update = "update tb_edicao set tp_ocr_status = 'E' "
						+ "where id_edicao = ?|tmp.obj.id_edicao| and tp_ocr_status <> 'S'";
				dh.executeUpdate(update, wiMap);
		    	ServletContext sc = getParams().getServletContext();
		    	new OcrThead(sc, dh.cloneMe(), key, pdfFile).start();
 			}
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			ErrorLog errorLog = getParams().getErrorLog();
			if (errorLog != null) {
				errorLog.write(className, "Page: " + pageId, err);
			}
		}
	}
	
}
