package br.com.webinside.runtime.lw.func.diariolw;

import java.util.Map;

import javax.servlet.ServletContext;

import org.json.simple.JSONObject;

import br.com.webinside.runtime.exception.UserException;
import br.com.webinside.runtime.integration.AbstractConnector;
import br.com.webinside.runtime.integration.DatabaseAliases;
import br.com.webinside.runtime.integration.InterfaceHeaders;
import br.com.webinside.runtime.util.WIMap;

public class OcrMessage extends AbstractConnector {
	
 	@Override
	public void execute(WIMap wiMap, DatabaseAliases databases, 
			InterfaceHeaders headers) throws UserException {
		String className = getClass().getName();
		try {
 	    	String key = wiMap.get("tmp.key");
	    	String value = "";
			ServletContext sc = getParams().getServletContext();
			Map<String, String> map = (Map)sc.getAttribute("ocrMap"); 
			if (map != null) {
 		        value = map.get(key);
		    	if (value == null) value = "";
			}
			JSONObject json = new JSONObject();
 			if (key.equals("")) {
				value = "Key not informed";
 			}
			json.put("message", value);
 			getParams().getWriter().print(json.toJSONString());
		} catch (Exception err) {
			String pageId = wiMap.get("wi.page.id");
			getParams().getErrorLog().write(className, "Page: " + pageId, err);
		}
	}
 
}
