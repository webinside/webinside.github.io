package teste;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.docx4j.XmlUtils;
import org.docx4j.model.datastorage.migration.VariablePrepare;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.WordprocessingML.MainDocumentPart;
import org.docx4j.wml.P;
import org.docx4j.wml.R;

public class DocxReplace {

	private static String FILE = "/temp/documento-template.docx";
	
	public static void main(String[] args) throws Exception {
		Map<String,String> map = new HashMap<String, String>();
		map.put("cliente_nome", "Geraldo Moraes");
		map.put("cliente_celular", "79 98838-2187");
		map.put("cliente_sexo", "");
		map.put("usar_conjuge_ini", "$usar_conjuge_ini$");
		map.put("usar_conjuge_fim", "$usar_conjuge_fim$");
		new DocxReplace().replace(map);
		System.out.println("TERMINEI");
	}
		
   	public void replace(Map<String,String> map) throws Exception {
		WordprocessingMLPackage wordMLPackage = WordprocessingMLPackage.load(new File(FILE));
		MainDocumentPart documentPart = wordMLPackage.getMainDocumentPart();
		String docXml = XmlUtils.marshaltoString(documentPart.getContents(), true, true);
		Files.write(Paths.get(FILE.replace(".docx", ".xml")), docXml.getBytes("UTF-8"));
	
		VariablePrepare.prepare(wordMLPackage);
		wordMLPackage.getMainDocumentPart().variableReplace(map);

		R rObjIni = null;
		R rObjFim = null;
		String key = "$usar_conjuge_ini$";
		String xpath = "//w:r[w:t[contains(text(),'" + key + "')]]";
		List<Object> list = documentPart.getJAXBNodesViaXPath(xpath, false);
		for (Object obj : list) {
			rObjIni = (R)obj;
		}
		key = "$usar_conjuge_fim$";
		xpath = "//w:r[w:t[contains(text(),'" + key + "')]]";
		list = documentPart.getJAXBNodesViaXPath(xpath, false);
		for (Object obj : list) {
			rObjFim = (R)obj;
		}

		boolean delete = false;
		P pObj = (P) rObjIni.getParent();
		for (Object o : new ArrayList(pObj.getContent())) {
			if (o == rObjIni) {
				delete = true;
				pObj.getContent().remove(o);
			} else if (o == rObjFim) {
				delete = false;
				pObj.getContent().remove(o);
			} else if (delete) {
				pObj.getContent().remove(o);
			}
		}
		
//        List<Object> content = rObj.getContent();
//        Text text = (Text)((JAXBElement<?>)content.get(0)).getValue();
//       System.out.println(text.getValue());
//        String newText = text.getValue().replace(key, entry.getValue());
//        text.setValue(newText);
		
		wordMLPackage.save(new File("/temp/documento-processado.docx"));		
	}
   	
}
