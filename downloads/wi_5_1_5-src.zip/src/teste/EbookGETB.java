package teste;

import java.io.File;
import java.util.List;

import com.itextpdf.text.pdf.PdfReader;

import br.com.webinside.runtime.lw.img.ImgEnum;
import br.com.webinside.runtime.lw.img.ImgUtil;

public class EbookGETB {
	
	private final String LWSTORAGE = "/Tomcats/Tomcat70-wi5/webapps/lwstorage";
	private File pdf = new File(LWSTORAGE + "/publico/getb/conteudo/c00213/informativo.pdf");
	
	public static void main(String[] args) throws Exception {
		new EbookGETB().execute();
	}

	private void execute() throws Exception {
        PdfReader pdfReader = new PdfReader(pdf.getAbsolutePath());
        int pages = pdfReader.getNumberOfPages();
		pdfReader.close();
		execute("x150", "0", "f00");
		execute("x900", "0-" + pages, "small");
		execute("x1600", "0-" + pages, "large");
		System.out.println("IMAGENS GERADAS");
	}
	
	private void execute(String tamanho, String pages, String name) {
		List<String> cmd = ImgUtil.cmdPdfToImg("[" + pages + "]" , ImgEnum.JPG_COLOR, tamanho);
		ImgUtil.execute(cmd, pdf.getParent(), "informativo", name, false);
	}
	
}
