package teste;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;

import org.w3c.dom.Document;
import org.w3c.tidy.Tidy;
import org.xhtmlrenderer.pdf.ITextRenderer;

public class DiarioPdf {

	public static void main(String[] args) throws Exception {
		FileOutputStream fos = new FileOutputStream("/temp/diario.pdf");
		Document doc = getDocument();
	    ITextRenderer renderer = new ITextRenderer();
		renderer.setDocument(doc, "");
		renderer.layout();
		renderer.createPDF(fos);
		fos.close();
	}

	public static Document getDocument() throws Exception {
		Tidy tidy = new Tidy();
		tidy.setQuiet(true);
		tidy.setShowWarnings(false);
		tidy.setBreakBeforeBR(true);
		InputStream in = new FileInputStream("/temp/diario.html");
	    Reader reader = new InputStreamReader(in); 
		Document document = tidy.parseDOM(reader, null);
		return generalizeDoc(document);
	}
	
	private static Document generalizeDoc(Document tidyDoc) throws Exception {
		TransformerFactory tfactory = TransformerFactory.newInstance();
		Transformer tx = tfactory.newTransformer();
		DOMSource source = new DOMSource(tidyDoc);
		DOMResult result = new DOMResult();
		tx.transform(source, result);
		return (Document) result.getNode();
	}	
}
