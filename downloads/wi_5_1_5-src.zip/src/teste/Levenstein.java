package teste;

import br.com.webinside.runtime.util.StringA;

public class Levenstein {

	public static void main(String[] args) {
		String s1 = "Gerald Leite Moraes";
		String s2 = "eralx";
		System.out.println(StringA.compareLevRatio(s2, s1));
		
		
	}

}
