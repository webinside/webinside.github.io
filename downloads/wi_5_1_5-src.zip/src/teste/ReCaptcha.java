package teste;

import java.io.ByteArrayOutputStream;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.io.IOUtils;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

public class ReCaptcha {
	
	public void verify(String response) throws Exception {
		
		HttpClient httpclient = new HttpClient();
		GetMethod httpget = new GetMethod("https://www.google.com/recaptcha/api/siteverify"); 
		httpget.setQueryString(new NameValuePair[] { 
		    new NameValuePair("secret", "6LebIxEUAAAAAFoyxq3cFSSzfQeB9zdgk-FvPVqY"),
		    new NameValuePair("response", response)
		}); 		
		int statusCode = httpclient.executeMethod(httpget);
		System.out.println("Return:" + statusCode);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		IOUtils.copy(httpget.getResponseBodyAsStream(), baos);
		String message = new String(baos.toByteArray());
		System.out.println(message);
		httpget.releaseConnection();
		JSONObject json = (JSONObject) JSONValue.parse(message);
		System.out.println(json.get("success"));
		
	}

}
