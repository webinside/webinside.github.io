package teste;

import java.io.File;
import java.util.List;

import br.com.webinside.runtime.lw.img.ImgEnum;
import br.com.webinside.runtime.lw.img.ImgUtil;

public class EbookAAG {
	
	private String pdfName = "AGA_EBOOK_4_IMPOSTOS";
	private File pdf = new File("/temp/aag/" + pdfName + ".pdf");
	
	public static void main(String[] args) throws Exception {
		new EbookAAG().execute();
	}

	private void execute() throws Exception {
		execute("x900", "0", "small");
		System.out.println("IMAGENS GERADAS");
	}
	
	private void execute(String tamanho, String pages, String name) {
		List<String> cmd = ImgUtil.cmdPdfToImg("[" + pages + "]" , ImgEnum.JPG_COLOR, tamanho);
		ImgUtil.execute(cmd, pdf.getParent(), pdfName, name, false);
	}
	
}
