package teste;

import java.io.File;

public class FotosGETB {

	public static void main(String[] args) {
		File folder = new File("/temp/fotos-getb");
		int pos = 1;
		for (File file : folder.listFiles()) {
			if (!file.getName().toLowerCase().endsWith(".jpg")) continue;
			String spos = String.format ("%02d", pos);
			File file2 = new File(file.getParentFile(), "f" + spos + ".jpg");
			file.renameTo(file2);
			pos++;
		}
	}

}
